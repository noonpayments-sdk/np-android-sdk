package com.noonpayments.npmobilesdk.core.designsystem

internal actual fun readResourceText(name: String): String =
    object {}.javaClass.classLoader!!
        .getResourceAsStream(name)!!
        .bufferedReader()
        .readText()

