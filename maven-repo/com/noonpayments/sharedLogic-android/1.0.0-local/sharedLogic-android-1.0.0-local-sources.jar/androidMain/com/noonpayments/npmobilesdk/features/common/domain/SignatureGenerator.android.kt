package com.noonpayments.npmobilesdk.features.common.domain

import org.bouncycastle.crypto.digests.SHA512Digest
import org.bouncycastle.crypto.engines.RSAEngine
import org.bouncycastle.crypto.encodings.PKCS1Encoding
import org.bouncycastle.crypto.util.PublicKeyFactory
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Android actual: SHA-512 via Bouncy Castle SHA512Digest.
 */
internal actual fun platformComputeSha512(input: String): String {
    val digest = SHA512Digest()
    val bytes = input.encodeToByteArray()
    digest.update(bytes, 0, bytes.size)

    val output = ByteArray(64) // SHA-512 = 512 bits = 64 bytes
    digest.doFinal(output, 0)

    // Return lowercase hex string
    return output.joinToString("") { "%02x".format(it) }
}

/**
 * Android actual: RSA/PKCS1 v1.5 encryption via Bouncy Castle RSAEngine + PKCS1Encoding.
 */
@OptIn(ExperimentalEncodingApi::class)
internal actual fun platformEncryptRsaPkcs1(data: String, pemKey: String): String {
    // Normalize PEM: replace escaped newlines with actual newlines
    val normalizedPem = pemKey.replace("\\n", "\n")

    // Extract DER from PEM (shared utility)
    val derKey = extractDerFromPem(normalizedPem)

    // Create RSA public key via Bouncy Castle
    val publicKey = PublicKeyFactory.createKey(derKey)

    // Encrypt with PKCS1 v1.5 padding
    val cipher = PKCS1Encoding(RSAEngine())
    cipher.init(true, publicKey) // true = encrypt mode

    val dataBytes = data.encodeToByteArray()
    val encrypted = cipher.processBlock(dataBytes, 0, dataBytes.size)

    // Base64 encode for backend transmission
    return Base64.encode(encrypted)
}

