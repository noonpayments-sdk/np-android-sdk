package com.noonpayments.npmobilesdk.core.logging
/**
 * Android library builds cannot access BuildConfig.DEBUG without additional build configuration.
 * This defaults to false (production-safe / no logging) for the library itself.
 *
 * To enable logging in your Android app or demo, call SdkLoggerConfig.configure(PrintSdkLogger)
 * from your Application.onCreate() when your own BuildConfig.DEBUG is true.
 * See docs/logging-and-build-variants.md for the full guide.
 */
internal actual val isDebugBuild: Boolean = false
