package com.noonpayments.npmobilesdk.features.paymenttransaction.viewmodel

import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.entity.PaymentTransaction
import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.usecase.GetPaymentTransactionUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class PaymentSheetState(
    val isLoading: Boolean = false,
    val transaction: PaymentTransaction? = null,
    val errorMessage: String? = null
)

/**
 * Shared ViewModel used by the native SDK sheets.
 * Manages payment transaction loading and UI state.
 */
class PaymentSheetViewModel(
    private val getPaymentTransactionUseCase: GetPaymentTransactionUseCase? = null
) {

    private val _state = MutableStateFlow(PaymentSheetState())
    val state: StateFlow<PaymentSheetState> = _state.asStateFlow()

    fun getMessage(): String = "b3 from shared Kotlin logic 🚀"

    suspend fun loadPaymentTransaction(transactionId: Int) {
        if (getPaymentTransactionUseCase == null) {
            _state.value = _state.value.copy(errorMessage = "Use case not provided")
            return
        }

        _state.value = _state.value.copy(isLoading = true, errorMessage = null)
        try {
            val transaction = withContext(Dispatchers.Default) {
                getPaymentTransactionUseCase(transactionId)
            }
            _state.value = _state.value.copy(
                isLoading = false,
                transaction = transaction,
                errorMessage = if (transaction == null) "Payment not found" else null
            )
        } catch (e: Exception) {
            _state.value = _state.value.copy(
                isLoading = false,
                errorMessage = e.message ?: "Unknown error"
            )
        }
    }
}


