package com.noonpayments.npmobilesdk.features.cancelpayment.viewmodel
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.cancelpayment.domain.usecase.CancelPaymentUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CancelPaymentDemoState(
    val isLoading: Boolean = false,
    val isCancelled: Boolean = false,
    val usedReason: String? = null,
    val errorMessage: String? = null,
)

class CancelPaymentDemoViewModel(
    private val apiConfig: PaymentApiConfig,
    private val cancelPaymentUseCase: CancelPaymentUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(CancelPaymentDemoState())
    val state: StateFlow<CancelPaymentDemoState> = _state.asStateFlow()

    suspend fun cancel(reason: String) {
        val resolvedReason = reason.trim().ifEmpty { "Cancelled from checkout header." }
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (val result = cancelPaymentUseCase(apiConfig, CancelPaymentInput(reason = resolvedReason))) {
            is PaymentOperationResult.Success -> {
                _state.value = CancelPaymentDemoState(
                    isLoading = false,
                    isCancelled = true,
                    usedReason = resolvedReason,
                )
            }

            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    usedReason = resolvedReason,
                    errorMessage = message,
                )
            }
        }
    }
}

