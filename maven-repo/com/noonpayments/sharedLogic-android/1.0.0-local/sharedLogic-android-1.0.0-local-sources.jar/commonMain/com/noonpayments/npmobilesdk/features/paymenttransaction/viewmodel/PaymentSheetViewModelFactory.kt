package com.noonpayments.npmobilesdk.features.paymenttransaction.viewmodel

import com.noonpayments.npmobilesdk.core.network.HttpClientFactory
import com.noonpayments.npmobilesdk.core.network.KtorNetworkTransport
import com.noonpayments.npmobilesdk.core.network.NetworkClient
import com.noonpayments.npmobilesdk.features.paymenttransaction.data.repository.PaymentSheetRepository
import com.noonpayments.npmobilesdk.features.paymenttransaction.data.service.PaymentSheetService
import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.usecase.GetPaymentTransactionUseCase

/**
 * Factory for creating a fully-wired PaymentSheetViewModel.
 */
object PaymentSheetViewModelFactory {

	fun create(): PaymentSheetViewModel {
		val httpClient = HttpClientFactory.create()
		val transport = KtorNetworkTransport(httpClient)
		val networkClient = NetworkClient(transport)

		val service = PaymentSheetService(networkClient)
		val repository = PaymentSheetRepository(service)
		val useCase = GetPaymentTransactionUseCase(repository)

		return PaymentSheetViewModel(useCase)
	}
}

