package com.noonpayments.npmobilesdk.features.common.data.service

import com.noonpayments.npmobilesdk.core.network.Endpoint
import com.noonpayments.npmobilesdk.core.network.HttpMethod
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject

/**
 * Noon payment endpoints aligned with docs/API_CALLS.md.
 */
internal object NoonPaymentEndpoints {

    data class GetOrderConfiguration(
        private val config: PaymentApiConfig
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "order"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = commonHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("apiOperation", "SDK_ORDER_CONFIGURATION")
            putJsonObject("order") {
                put("id", config.orderId)
            }
        }
    }

    data class AddCardPaymentInfo(
        private val config: PaymentApiConfig,
        private val input: CardPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "order"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = commonHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("apiOperation", "ADD_PAYMENT_INFO")
            putJsonObject("order") {
                put("id", config.orderId)
            }
            putJsonObject("paymentData") {
                put("type", "CARD")
                putJsonObject("data") {
                    if (!input.tokenIdentifier.isNullOrBlank()) {
                        put("tokenIdentifier", input.tokenIdentifier)
                        put("cvv", input.cvv)
                        put("sdkSignature", input.sdkSignature)
                    } else {
                        if (!input.nameOnCard.isNullOrBlank()) {
                            put("nameOnCard", input.nameOnCard)
                        }
                        put("numberEncrypted", input.numberEncrypted.orEmpty())
                        put("cvv", input.cvv)
                        put("expiryMonth", input.expiryMonth.orEmpty())
                        put("expiryYear", input.expiryYear.orEmpty())
                        put("sdkSignature", input.sdkSignature)
                    }
                }
            }

            if (input.payerConsentForToken != null) {
                putJsonObject("configuration") {
                    put("payerConsentForToken", input.payerConsentForToken)
                }
            }
        }
    }

    data class TokenizeApplePay(
        private val config: PaymentApiConfig,
        private val input: ApplePayPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "order"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = commonHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("apiOperation", "ADD_PAYMENT_INFO")
            putJsonObject("order") {
                put("id", config.orderId)
            }
            putJsonObject("paymentData") {
                put("type", "ApplePay")
                putJsonObject("data") {
                    put("paymentToken", input.paymentToken)
                }
            }
        }
    }

    data class TokenizeGooglePay(
        private val config: PaymentApiConfig,
        private val input: GooglePayPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "order"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = commonHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("apiOperation", "ADD_PAYMENT_INFO")
            putJsonObject("order") {
                put("id", config.orderId)
            }
            putJsonObject("paymentData") {
                put("type", "GooglePay")
                putJsonObject("data") {
                    put("apiVersion", input.apiVersion)
                    put("apiVersionMinor", input.apiVersionMinor)
                    put("paymentMethodData", input.paymentMethodDataJson.toJsonObjectOrPrimitive())
                }
            }
            putJsonObject("configuration") {
                put("payerConsentForToken", input.payerConsentForToken)
            }
        }
    }

    data class CancelPayment(
        private val config: PaymentApiConfig,
        private val input: CancelPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "order"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = commonHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("apiOperation", "CANCEL")
            putJsonObject("order") {
                put("id", config.orderId)
                put("cancellationReason", input.reason)
            }
        }
    }

    data class FetchOrderStatus(
        private val config: PaymentApiConfig,
        private val orderId: String
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "order/$orderId"
        override val method: HttpMethod = HttpMethod.GET
        override val commonHeaders: Map<String, String> = commonHeaders(config)
    }
}

internal fun sanitizeBaseUrl(url: String): String {
    val trimmed = url.trim().trimEnd('/')
    return if (trimmed.endsWith("/order")) {
        trimmed.removeSuffix("/order")
    } else {
        trimmed
    }
}

private fun commonHeaders(config: PaymentApiConfig): Map<String, String> = mapOf(
    "Content-Type" to "application/json",
    "Authorization" to config.authHeader,
    "User-Agent" to "ios-sdk/v${config.sdkVersion}"
)

private fun String.toJsonObjectOrPrimitive(): JsonElement {
    return runCatching { Json.parseToJsonElement(this) }
        .getOrNull()
        ?.let { parsed -> if (parsed is JsonObject) parsed else JsonPrimitive(this) }
        ?: JsonPrimitive(this)
}

