package com.noonpayments.npmobilesdk.core.network

import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.LogSanitizer
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import kotlinx.serialization.SerializationException
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

@PublishedApi
internal const val TAG = "NetworkClient"

class NetworkClient(
    @PublishedApi internal val transport: NetworkTransport,
    @PublishedApi internal val json: Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    },
    @PublishedApi internal val logger: SdkLogger = SdkLogger.default()
) {
    /**
     * Executes [endpoint] and returns a typed [NetworkResult].
     *
     * @param orderId Optional order identifier attached to every log line for traceability.
     *                Pass [PaymentApiConfig.orderId] at every call site.
     *                Defaults to "unknown" when not yet resolved (e.g. pre-3DS step).
     */
    suspend inline fun <reified T> request(
        endpoint: Endpoint,
        orderId: String? = null
    ): NetworkResult<T> {
        val resolvedOrderId = orderId ?: "unknown"

        val request = NetworkRequest(
            url = endpoint.resolvedUrl(),
            method = endpoint.method,
            headers = endpoint.resolvedHeaders(),
            body = endpoint.body?.toString()
        )

        logger.log(
            level = LogLevel.DEBUG,
            tag = TAG,
            message = "→ ${request.method.name} ${request.url} | " +
                "headers=${LogSanitizer.sanitizeHeaders(request.headers)} | " +
                "body=${LogSanitizer.sanitizeBody(request.body)}",
            orderId = resolvedOrderId
        )

        val response = try {
            transport.execute(request)
        } catch (throwable: Throwable) {
            logger.log(
                level = LogLevel.ERROR,
                tag = TAG,
                message = "✗ Transport error: ${throwable::class.simpleName} — ${throwable.message}",
                orderId = resolvedOrderId
            )
            return NetworkResult.Failure(NetworkError.Transport(throwable))
        }

        if (response.statusCode !in 200..299) {
            logger.log(
                level = LogLevel.WARN,
                tag = TAG,
                message = "← HTTP ${response.statusCode} (failure)",
                orderId = resolvedOrderId
            )
            return NetworkResult.Failure(
                NetworkError.Http(statusCode = response.statusCode, body = response.body)
            )
        }

        logger.log(
            level = LogLevel.DEBUG,
            tag = TAG,
            message = "← HTTP ${response.statusCode} OK",
            orderId = resolvedOrderId
        )

        if (T::class == Unit::class) {
            @Suppress("UNCHECKED_CAST")
            return NetworkResult.Success(Unit as T, response.statusCode, response.headers)
        }

        if (response.body.isBlank()) {
            return NetworkResult.Failure(
                NetworkError.Serialization("Response body is empty for expected type ${T::class.simpleName}")
            )
        }

        return try {
            val parsed = json.decodeFromString<T>(response.body)
            NetworkResult.Success(parsed, response.statusCode, response.headers)
        } catch (exception: SerializationException) {
            NetworkResult.Failure(NetworkError.Serialization(exception.message ?: "Unable to parse response"))
        }
    }
}


