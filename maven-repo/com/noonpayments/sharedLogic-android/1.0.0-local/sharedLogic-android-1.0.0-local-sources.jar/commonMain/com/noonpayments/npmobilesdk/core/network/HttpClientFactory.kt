package com.noonpayments.npmobilesdk.core.network

import io.ktor.client.HttpClient
import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

internal expect fun platformEngineFactory(): HttpClientEngineFactory<*>

object HttpClientFactory {
    fun create(
        json: Json = Json {
            ignoreUnknownKeys = true
            explicitNulls = false
            isLenient = true
        }
    ): HttpClient = HttpClient(platformEngineFactory()) {
        install(ContentNegotiation) {
            json(json)
        }
    }
}

