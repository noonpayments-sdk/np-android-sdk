package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

interface CardBrandDetector {
    val cardType: CardType
    fun matches(cardNumber: String): Boolean
}
