package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Shared API configuration used by all payment operations.
 */
data class PaymentApiConfig(
    val baseUrl: String,
    val orderId: String,
    val authHeader: String,
    val sdkVersion: String
)
