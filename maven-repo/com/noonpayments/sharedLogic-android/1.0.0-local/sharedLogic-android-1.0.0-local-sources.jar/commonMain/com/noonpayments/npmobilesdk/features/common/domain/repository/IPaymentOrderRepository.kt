package com.noonpayments.npmobilesdk.features.common.domain.repository

import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult

interface IPaymentOrderRepository {
    suspend fun getOrderConfiguration(config: PaymentApiConfig): PaymentOperationResult<OrderConfiguration>

    suspend fun addCardPaymentInfo(
        config: PaymentApiConfig,
        input: CardPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult>

    suspend fun tokenizeApplePay(
        config: PaymentApiConfig,
        input: ApplePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult>

    suspend fun tokenizeGooglePay(
        config: PaymentApiConfig,
        input: GooglePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult>

    suspend fun cancelPayment(
        config: PaymentApiConfig,
        input: CancelPaymentInput = CancelPaymentInput()
    ): PaymentOperationResult<Unit>

    suspend fun fetchOrderStatus(
        config: PaymentApiConfig,
        orderId: String
    ): PaymentOperationResult<OrderStatusResult>
}
