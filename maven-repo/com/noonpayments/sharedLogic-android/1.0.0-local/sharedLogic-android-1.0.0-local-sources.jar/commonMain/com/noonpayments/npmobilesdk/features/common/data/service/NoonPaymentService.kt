package com.noonpayments.npmobilesdk.features.common.data.service

import com.noonpayments.npmobilesdk.core.network.NetworkClient
import com.noonpayments.npmobilesdk.core.network.NetworkResult
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import kotlinx.serialization.json.JsonObject

class NoonPaymentService(
    private val networkClient: NetworkClient
) {
    suspend fun getOrderConfiguration(config: PaymentApiConfig): NetworkResult<JsonObject> {
        return networkClient.request(NoonPaymentEndpoints.GetOrderConfiguration(config), orderId = config.orderId)
    }

    suspend fun addCardPaymentInfo(
        config: PaymentApiConfig,
        input: CardPaymentInput
    ): NetworkResult<JsonObject> {
        return networkClient.request(NoonPaymentEndpoints.AddCardPaymentInfo(config, input), orderId = config.orderId)
    }

    suspend fun tokenizeApplePay(
        config: PaymentApiConfig,
        input: ApplePayPaymentInput
    ): NetworkResult<JsonObject> {
        return networkClient.request(NoonPaymentEndpoints.TokenizeApplePay(config, input), orderId = config.orderId)
    }

    suspend fun tokenizeGooglePay(
        config: PaymentApiConfig,
        input: GooglePayPaymentInput
    ): NetworkResult<JsonObject> {
        return networkClient.request(NoonPaymentEndpoints.TokenizeGooglePay(config, input), orderId = config.orderId)
    }

    suspend fun cancelPayment(
        config: PaymentApiConfig,
        input: CancelPaymentInput
    ): NetworkResult<Unit> {
        return networkClient.request(NoonPaymentEndpoints.CancelPayment(config, input), orderId = config.orderId)
    }

    suspend fun fetchOrderStatus(
        config: PaymentApiConfig,
        orderId: String
    ): NetworkResult<JsonObject> {
        return networkClient.request(NoonPaymentEndpoints.FetchOrderStatus(config, orderId), orderId = orderId)
    }
}
