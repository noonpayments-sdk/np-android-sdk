package com.noonpayments.npmobilesdk.core.network

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod as KtorHttpMethod
import io.ktor.http.contentType

class KtorNetworkTransport(
	private val httpClient: HttpClient
) : NetworkTransport {
	override suspend fun execute(request: NetworkRequest): NetworkRawResponse {
		val response = httpClient.request(request.url) {
			method = request.method.toKtorMethod()
			request.headers.forEach { (key, value) ->
				headers.append(name = key, value = value)
			}
			request.body?.let { body ->
				contentType(ContentType.Application.Json)
				setBody(body)
			}
		}

		val responseHeaders = response.headers.entries().associate { (key, value) ->
			key to value.joinToString(",")
		}

		return NetworkRawResponse(
			statusCode = response.status.value,
			body = response.body<String>(),
			headers = responseHeaders
		)
	}
}

private fun HttpMethod.toKtorMethod(): KtorHttpMethod = when (this) {
	HttpMethod.GET -> KtorHttpMethod.Get
	HttpMethod.POST -> KtorHttpMethod.Post
}