package com.noonpayments.npmobilesdk.features.common.domain

sealed interface PaymentFailure {
    data class Http(val statusCode: Int, val body: String) : PaymentFailure
    data class Serialization(val message: String) : PaymentFailure
    data class Transport(val message: String) : PaymentFailure
}

sealed interface PaymentOperationResult<out T> {
    data class Success<T>(val value: T) : PaymentOperationResult<T>
    data class Failure(val failure: PaymentFailure) : PaymentOperationResult<Nothing>
}
