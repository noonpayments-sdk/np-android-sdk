package com.noonpayments.npmobilesdk.features.common.presentation.component

import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.presentation.PaymentUseCasesFactory
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import com.noonpayments.npmobilesdk.features.applepay.viewmodel.ApplePayDemoViewModel
import com.noonpayments.npmobilesdk.features.cancelpayment.viewmodel.CancelPaymentDemoViewModel
import com.noonpayments.npmobilesdk.features.cardpayment.viewmodel.CardPaymentDemoViewModel
import com.noonpayments.npmobilesdk.features.orderstatus.viewmodel.FetchOrderStatusDemoViewModel
import com.noonpayments.npmobilesdk.features.googlepay.viewmodel.GooglePayDemoViewModel
import com.noonpayments.npmobilesdk.features.orderconfiguration.viewmodel.OrderConfigurationDemoViewModel

class PaymentSheetDemoComponent internal constructor(
    val sessionStore: PaymentSheetSessionStore,
    val orderConfigurationViewModel: OrderConfigurationDemoViewModel,
    val cardPaymentViewModel: CardPaymentDemoViewModel,
    val applePayViewModel: ApplePayDemoViewModel,
    val googlePayViewModel: GooglePayDemoViewModel,
    val fetchOrderStatusViewModel: FetchOrderStatusDemoViewModel,
    val cancelPaymentViewModel: CancelPaymentDemoViewModel,
)

object PaymentSheetDemoComponentFactory {
    fun create(apiConfig: PaymentApiConfig): PaymentSheetDemoComponent {
        val useCases = PaymentUseCasesFactory.default().createDefault()
        val sessionStore = PaymentSheetSessionStore()

        return PaymentSheetDemoComponent(
            sessionStore = sessionStore,
            orderConfigurationViewModel = OrderConfigurationDemoViewModel(
                apiConfig = apiConfig,
                getOrderConfigurationUseCase = useCases.getOrderConfiguration,
                sessionStore = sessionStore,
            ),
            cardPaymentViewModel = CardPaymentDemoViewModel(
                apiConfig = apiConfig,
                addCardPaymentInfoUseCase = useCases.addCardPaymentInfo,
                detectCardBrandUseCase = useCases.detectCardBrand,
                sessionStore = sessionStore,
            ),
            applePayViewModel = ApplePayDemoViewModel(
                apiConfig = apiConfig,
                tokenizeApplePayUseCase = useCases.tokenizeApplePay,
                sessionStore = sessionStore,
            ),
            googlePayViewModel = GooglePayDemoViewModel(
                apiConfig = apiConfig,
                tokenizeGooglePayUseCase = useCases.tokenizeGooglePay,
                sessionStore = sessionStore,
            ),
            fetchOrderStatusViewModel = FetchOrderStatusDemoViewModel(
                apiConfig = apiConfig,
                fetchOrderStatusUseCase = useCases.fetchOrderStatus,
                sessionStore = sessionStore,
            ),
            cancelPaymentViewModel = CancelPaymentDemoViewModel(
                apiConfig = apiConfig,
                cancelPaymentUseCase = useCases.cancelPayment,
                sessionStore = sessionStore,
            ),
        )
    }
}

