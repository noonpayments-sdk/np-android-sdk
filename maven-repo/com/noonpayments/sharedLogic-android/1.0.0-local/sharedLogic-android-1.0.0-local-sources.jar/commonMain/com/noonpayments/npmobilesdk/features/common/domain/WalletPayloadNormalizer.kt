package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Lightweight wallet token normalization before transport.
 */
fun normalizeApplePayTokenForTransport(token: String): String {
	return normalizeWalletPayloadForTransport(token)
}

/**
 * Lightweight wallet payload normalization before transport.
 */
fun normalizeGooglePayPaymentMethodDataForTransport(paymentMethodDataJson: String): String {
	return normalizeWalletPayloadForTransport(paymentMethodDataJson)
}

private fun normalizeWalletPayloadForTransport(payload: String): String {
	return payload.trim().replace("\u0000", "")
}

