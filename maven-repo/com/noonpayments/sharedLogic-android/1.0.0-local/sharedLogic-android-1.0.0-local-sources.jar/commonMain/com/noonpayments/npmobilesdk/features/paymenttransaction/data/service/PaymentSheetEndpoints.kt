package com.noonpayments.npmobilesdk.features.paymenttransaction.data.service

import com.noonpayments.npmobilesdk.core.network.Endpoint
import com.noonpayments.npmobilesdk.core.network.HttpMethod

/**
 * PaymentSheet feature endpoints live here.
 * Each feature/screen should follow the same pattern in its own package.
 */
object PaymentSheetEndpoints {
    /**
     * Real endpoint using DummyJSON /posts as a mock payment transaction API.
     */
    data class GetPaymentTransaction(
        private val transactionId: Int
    ) : Endpoint {
        override val baseUrl: String = "https://dummyjson.com"
        override val path: String = "posts/$transactionId"
        override val method: HttpMethod = HttpMethod.GET

        override val commonHeaders: Map<String, String> = mapOf(
            "Accept" to "application/json"
        )
    }

    /**
     * Legacy placeholder for real Noon Payments API (when implemented).
     */
    data class GetPaymentStatus(
        private val paymentId: String,
        private val authToken: String
    ) : Endpoint {
        override val baseUrl: String = "https://api.noonpayments.com"
        override val path: String = "v1/payments/$paymentId/status"
        override val method: HttpMethod = HttpMethod.GET

        override val commonHeaders: Map<String, String> = mapOf(
            "Accept" to "application/json"
        )

        override val headers: Map<String, String> = mapOf(
            "Authorization" to "Bearer $authToken"
        )
    }
}

