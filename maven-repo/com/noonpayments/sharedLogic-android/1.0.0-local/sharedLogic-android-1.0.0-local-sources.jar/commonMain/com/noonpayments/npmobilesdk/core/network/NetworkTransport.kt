package com.noonpayments.npmobilesdk.core.network

interface NetworkTransport {
	suspend fun execute(request: NetworkRequest): NetworkRawResponse
}

