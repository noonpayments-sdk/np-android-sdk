package com.noonpayments.npmobilesdk.features.common.domain

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull

data class GooglePayConfiguration(
    val apiVersion: Int,
    val apiVersionMinor: Int,
    val environment: String,
    val requestJson: String,
)

fun OrderConfiguration.googlePayConfigurationOrNull(): GooglePayConfiguration? {
    val paymentOptionsArray = paymentOptions as? JsonArray ?: return null
    val googlePayOption = paymentOptionsArray
        .firstNotNullOfOrNull { it as? JsonObject }
        ?.takeIf { option -> option.isGooglePayOption() }
        ?: paymentOptionsArray
            .mapNotNull { it as? JsonObject }
            .firstOrNull { option -> option.isGooglePayOption() }
        ?: return null

    val dataObject = googlePayOption["data"] as? JsonObject ?: return null
    val apiVersion = dataObject["apiVersion"].asIntOrNull() ?: return null
    val apiVersionMinor = dataObject["apiVersionMinor"].asIntOrNull() ?: 0
    val environment = dataObject["environment"].asStringOrNull() ?: "PRODUCTION"

    return GooglePayConfiguration(
        apiVersion = apiVersion,
        apiVersionMinor = apiVersionMinor,
        environment = environment,
        requestJson = dataObject.toString(),
    )
}

private fun JsonObject.isGooglePayOption(): Boolean {
    return listOf("action", "type", "method")
        .mapNotNull { key -> this[key].asStringOrNull() }
        .any { value -> value.equals("GooglePay", ignoreCase = true) }
}

private fun JsonElement?.asStringOrNull(): String? = (this as? JsonPrimitive)?.contentOrNull

private fun JsonElement?.asIntOrNull(): Int? = (this as? JsonPrimitive)?.intOrNull

