package com.noonpayments.npmobilesdk.features.common.domain

import kotlinx.serialization.json.JsonElement

data class OrderConfiguration(
	val resultCode: String?,
	val order: JsonElement?,
	val paymentOptions: JsonElement?,
	val orderCategory: String? = null,
	val currency: String? = null,
	val orderChannel: String? = null,
	val encryptionKey: String? = null
)

data class AddPaymentInfoResult(
    val resultCode: String?,
    val postUrl: String?,
    val orderId: String?
)

data class OrderStatusResult(
    val resultCode: String?,
    val orderStatus: String?,
    val transactionStatus: String?,
    val paymentDetails: JsonElement?
)
