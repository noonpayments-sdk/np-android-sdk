package com.noonpayments.npmobilesdk.features.paymenttransaction.domain.repository

import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.entity.PaymentTransaction

/**
 * Repository contract for payment operations.
 * Domain layer — no dependency on network or platform specifics.
 */
interface IPaymentSheetRepository {
    suspend fun getPaymentById(id: Int): PaymentTransaction?
}

