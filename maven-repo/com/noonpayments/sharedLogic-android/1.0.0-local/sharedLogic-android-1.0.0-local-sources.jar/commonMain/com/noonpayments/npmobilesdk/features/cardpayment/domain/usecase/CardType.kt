package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

enum class CardType {
    VISA,
    MASTERCARD,
    AMEX,
    MADA,
    JCB,
    UNIONPAY,
    DINERSCLUB,
    DISCOVER,
    MAESTRO,
    MEEZA,
    CUSTOM
}
