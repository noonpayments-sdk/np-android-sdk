package com.noonpayments.npmobilesdk.features.paymenttransaction.data.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * DTO for payment transaction response from the API.
 * Uses DummyJSON's Post model as a stand-in for a real payment response.
 */
@Serializable
data class PaymentTransactionDto(
    @SerialName("id")
    val id: Int,
    @SerialName("userId")
    val userId: Int,
    @SerialName("title")
    val title: String,
    @SerialName("body")
    val body: String
)

