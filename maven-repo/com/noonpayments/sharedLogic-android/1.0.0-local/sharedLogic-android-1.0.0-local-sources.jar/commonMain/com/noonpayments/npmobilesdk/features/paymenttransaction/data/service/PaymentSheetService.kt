package com.noonpayments.npmobilesdk.features.paymenttransaction.data.service

import com.noonpayments.npmobilesdk.core.network.NetworkClient
import com.noonpayments.npmobilesdk.core.network.NetworkResult
import com.noonpayments.npmobilesdk.features.paymenttransaction.data.dto.PaymentTransactionDto

/**
 * PaymentSheetService handles all network calls for payment data.
 * Uses the generic NetworkClient for typed, error-safe requests.
 */
class PaymentSheetService(
    private val networkClient: NetworkClient
) {
    suspend fun fetchPaymentTransaction(transactionId: Int): NetworkResult<PaymentTransactionDto> {
        return networkClient.request<PaymentTransactionDto>(
            PaymentSheetEndpoints.GetPaymentTransaction(transactionId)
        )
    }
}

