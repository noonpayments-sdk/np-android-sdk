package com.noonpayments.npmobilesdk.features.applepay.viewmodel
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.normalizeApplePayTokenForTransport
import com.noonpayments.npmobilesdk.features.applepay.domain.usecase.TokenizeApplePayUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ApplePayDemoState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val postUrl: String? = null,
    val resolvedOrderId: String? = null,
    val errorMessage: String? = null,
)

class ApplePayDemoViewModel(
    private val apiConfig: PaymentApiConfig,
    private val tokenizeApplePayUseCase: TokenizeApplePayUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(ApplePayDemoState())
    val state: StateFlow<ApplePayDemoState> = _state.asStateFlow()

    suspend fun submit(paymentToken: String) {
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (
            val result = tokenizeApplePayUseCase(
                apiConfig,
                ApplePayPaymentInput(paymentToken = normalizeApplePayTokenForTransport(paymentToken))
            )
        ) {
            is PaymentOperationResult.Success -> {
                sessionStore.saveAddPaymentInfoResult(result.value)
                _state.value = ApplePayDemoState(
                    isLoading = false,
                    resultCode = result.value.resultCode,
                    postUrl = result.value.postUrl,
                    resolvedOrderId = result.value.orderId,
                )
            }

            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                )
            }
        }
    }
}

