package com.noonpayments.npmobilesdk.features.common.presentation

import com.noonpayments.npmobilesdk.core.network.HttpClientFactory
import com.noonpayments.npmobilesdk.core.network.KtorNetworkTransport
import com.noonpayments.npmobilesdk.core.network.NetworkClient
import com.noonpayments.npmobilesdk.features.common.data.repository.PaymentOrderRepository
import com.noonpayments.npmobilesdk.features.common.data.service.NoonPaymentService
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.AddCardPaymentInfoUseCase
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.DetectCardBrandUseCase
import com.noonpayments.npmobilesdk.features.cancelpayment.domain.usecase.CancelPaymentUseCase
import com.noonpayments.npmobilesdk.features.orderstatus.domain.usecase.FetchOrderStatusUseCase
import com.noonpayments.npmobilesdk.features.orderconfiguration.domain.usecase.GetOrderConfigurationUseCase
import com.noonpayments.npmobilesdk.features.applepay.domain.usecase.TokenizeApplePayUseCase
import com.noonpayments.npmobilesdk.features.googlepay.domain.usecase.TokenizeGooglePayUseCase

data class PaymentUseCases(
	val getOrderConfiguration: GetOrderConfigurationUseCase,
	val addCardPaymentInfo: AddCardPaymentInfoUseCase,
	val tokenizeApplePay: TokenizeApplePayUseCase,
	val tokenizeGooglePay: TokenizeGooglePayUseCase,
	val cancelPayment: CancelPaymentUseCase,
	val fetchOrderStatus: FetchOrderStatusUseCase,
	val detectCardBrand: DetectCardBrandUseCase,
)

class PaymentUseCasesFactory(
    private val networkClientProvider: () -> NetworkClient,
) {

    fun create(networkClient: NetworkClient): PaymentUseCases {
        val service = NoonPaymentService(networkClient)
        val repository = PaymentOrderRepository(service)

        return PaymentUseCases(
            getOrderConfiguration = GetOrderConfigurationUseCase(repository),
            addCardPaymentInfo = AddCardPaymentInfoUseCase(repository),
            tokenizeApplePay = TokenizeApplePayUseCase(repository),
            tokenizeGooglePay = TokenizeGooglePayUseCase(repository),
            cancelPayment = CancelPaymentUseCase(repository),
            fetchOrderStatus = FetchOrderStatusUseCase(repository),
            detectCardBrand = DetectCardBrandUseCase(
                supportedBrands = listOf("AMEX", "MADA", "MEEZA", "MASTERCARD", "DINERS_CLUB", "DISCOVER", "JCB", "MAESTRO", "UNIONPAY", "VISA")
            )
        )
    }

    fun createDefault(): PaymentUseCases {
        return create(networkClientProvider())
    }

    companion object {
        fun default(): PaymentUseCasesFactory {
            return PaymentUseCasesFactory(
                networkClientProvider = {
                    val httpClient = HttpClientFactory.create()
                    val transport = KtorNetworkTransport(httpClient)
                    NetworkClient(transport)
                }
            )
        }
    }
}
