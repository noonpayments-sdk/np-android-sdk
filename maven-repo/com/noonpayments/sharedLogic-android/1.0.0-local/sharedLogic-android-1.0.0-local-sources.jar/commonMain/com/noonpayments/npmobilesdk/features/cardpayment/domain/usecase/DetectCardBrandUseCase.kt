package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

class DetectCardBrandUseCase(supportedBrands: List<String>) {
    private val detectors: List<CardBrandDetector> = supportedBrands.mapNotNull { brand ->
        when (brand.uppercase()) {
            "AMEX" -> AmexDetector()
            "VISA" -> VisaDetector()
            "MASTERCARD" -> MasterCardDetector()
            "DINERS_CLUB" -> DinersDetector()
            "DISCOVER" -> DiscoverDetector()
            "JCB" -> JCBDetector()
            "MEEZA" -> MeezaDetector()
            "MADA" -> MadaDetector()
            "MAESTRO" -> MaestroDetector()
            "UNIONPAY" -> UnionPayDetector()
            else -> null
        }
    }

    fun execute(cardNumber: String): CardType? {
        for (detector in detectors) {
            if (detector.matches(cardNumber)) {
                return detector.cardType
            }
        }
        return null
    }
}
