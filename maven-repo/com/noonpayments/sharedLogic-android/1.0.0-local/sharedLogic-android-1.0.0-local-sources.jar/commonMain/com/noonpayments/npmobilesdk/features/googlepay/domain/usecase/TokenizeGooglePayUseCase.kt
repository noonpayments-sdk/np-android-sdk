package com.noonpayments.npmobilesdk.features.googlepay.domain.usecase

import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository

class TokenizeGooglePayUseCase(
    private val repository: IPaymentOrderRepository
) {
    suspend operator fun invoke(
        config: PaymentApiConfig,
        input: GooglePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        return repository.tokenizeGooglePay(config, input)
    }
}

