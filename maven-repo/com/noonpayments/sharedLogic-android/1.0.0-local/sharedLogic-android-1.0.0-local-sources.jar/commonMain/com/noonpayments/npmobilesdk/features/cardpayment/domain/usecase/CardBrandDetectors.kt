package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

private const val CARD_MASK = "0000 0000 0000 0000"

data class AmexDetector(
    override val cardType: CardType = CardType.AMEX,
    val mask: String = "0000 000000 00000",
    val cvvLength: Int = 4
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return cleaned.startsWith("34") || cleaned.startsWith("37")
    }
}

data class VisaDetector(
    override val cardType: CardType = CardType.VISA,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return cleaned.startsWith("4")
    }
}

data class MasterCardDetector(
    override val cardType: CardType = CardType.MASTERCARD,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        if (cleaned.length < 2) return false

        val firstTwo = cleaned.take(2).toIntOrNull() ?: return false
        if (firstTwo in 51..55) {
            return true
        }

        if (cleaned.length >= 4) {
            val firstFour = cleaned.take(4).toIntOrNull() ?: return false
            return firstFour in 2221..2720
        }

        return false
    }
}

data class DinersDetector(
    override val cardType: CardType = CardType.DINERSCLUB,
    val mask: String = "0000 0000 0000 00",
    val cvvLength: Int = 3
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return cleaned.startsWith("30") || cleaned.startsWith("36") || 
               cleaned.startsWith("38") || cleaned.startsWith("39")
    }
}

data class DiscoverDetector(
    override val cardType: CardType = CardType.DISCOVER,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return cleaned.startsWith("6011") || cleaned.startsWith("65") || 
               cleaned.startsWith("64") || cleaned.startsWith("622")
    }
}

data class JCBDetector(
    override val cardType: CardType = CardType.JCB,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return cleaned.startsWith("35") || cleaned.startsWith("3337") || 
               cleaned.startsWith("3338")
    }
}

data class MeezaDetector(
    override val cardType: CardType = CardType.MEEZA,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3,
    private val bins: List<String> = listOf("507803", "507809", "507810", "507811")
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return bins.any { cleaned.startsWith(it) }
    }
}

data class MadaDetector(
    override val cardType: CardType = CardType.MADA,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3,
    private val bins: List<String> = listOf(
        "506968", "403024", "406136", "406996", "407520",
        "409201", "410621", "410685", "410834", "412565",
        "417633", "419593", "420132", "421141", "422817",
        "422818", "422819", "428331", "428671", "428672",
        "428673", "431361", "432328", "434107", "439954",
        "440533", "440647", "440795", "442429", "442463",
        "445564", "446393", "446404", "446672", "455036",
        "455708", "457865", "457997", "458456", "462220",
        "468540", "468541", "468542", "468543", "474491",
        "483010", "483011", "483012", "484783", "486094",
        "486095", "486096", "489318", "489319", "504300",
        "513213", "515079", "516138", "520058", "521076",
        "524130", "524514", "524940", "529415", "529741",
        "530060", "531196", "535825", "535989", "536023",
        "537767", "543085", "543357", "549760", "554180",
        "555610", "558563", "588845", "588848", "588850",
        "604906", "636120", "968201", "968202", "968203",
        "968204", "968205", "968206", "968207", "968208",
        "968209", "968211", "22337902", "22337986", "22402030",
        "40545400", "40719700", "40739500", "45488707",
        "49098000", "52166100", "53973776"
    )
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return bins.any { cleaned.startsWith(it) }
    }
}

data class MaestroDetector(
    override val cardType: CardType = CardType.MAESTRO,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3,
    private val startInts: List<Int> = listOf(6304, 6759, 6761, 6762, 6763, 6771)
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        if (cleaned.startsWith("50") || cleaned.startsWith("56") || 
            cleaned.startsWith("57") || cleaned.startsWith("58") || 
            cleaned.startsWith("59")) {
            return true
        }
        val firstFour = cleaned.take(4).toIntOrNull()
        return if (firstFour != null) startInts.contains(firstFour) else false
    }
}

data class UnionPayDetector(
    override val cardType: CardType = CardType.UNIONPAY,
    val mask: String = CARD_MASK,
    val cvvLength: Int = 3
) : CardBrandDetector {
    override fun matches(cardNumber: String): Boolean {
        val cleaned = cardNumber.replace(" ", "")
        return cleaned.startsWith("62")
    }
}
