package com.noonpayments.npmobilesdk.core.network

import kotlinx.serialization.json.JsonElement

/**
 * Each screen/feature defines its own endpoints by implementing this contract.
 */
interface Endpoint {
    val baseUrl: String
    val path: String
    val method: HttpMethod
    val commonHeaders: Map<String, String>
        get() = emptyMap()
    val headers: Map<String, String>
        get() = emptyMap()
    val query: Map<String, String?>
        get() = emptyMap()
    val body: JsonElement?
        get() = null

    fun resolvedHeaders(): Map<String, String> = commonHeaders + headers

    fun resolvedUrl(): String {
        val normalizedBase = baseUrl.trimEnd('/')
        val normalizedPath = path.trimStart('/')
        val baseWithPath = if (normalizedPath.isBlank()) {
            normalizedBase
        } else {
            "$normalizedBase/$normalizedPath"
        }

        val queryString = query.entries
            .asSequence()
            .filter { it.value != null }
            .joinToString("&") { "${it.key}=${it.value}" }

        return if (queryString.isBlank()) baseWithPath else "$baseWithPath?$queryString"
    }
}

