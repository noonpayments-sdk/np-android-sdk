package com.noonpayments.npmobilesdk.core.network

data class NetworkRequest(
    val url: String,
    val method: HttpMethod,
    val headers: Map<String, String>,
    val body: String? = null
)

data class NetworkRawResponse(
    val statusCode: Int,
    val body: String,
    val headers: Map<String, String> = emptyMap()
)

sealed interface NetworkResult<out T> {
    data class Success<T>(
        val data: T,
        val statusCode: Int,
        val headers: Map<String, String>
    ) : NetworkResult<T>

    data class Failure(val error: NetworkError) : NetworkResult<Nothing>
}

sealed interface NetworkError {
    data class Http(val statusCode: Int, val body: String) : NetworkError
    data class Serialization(val message: String) : NetworkError
    data class Transport(val throwable: Throwable) : NetworkError
}

