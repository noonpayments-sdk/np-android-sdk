package com.noonpayments.npmobilesdk.features.common.presentation

import com.noonpayments.npmobilesdk.features.common.domain.PaymentFailure

fun PaymentFailure.toDisplayMessage(): String = when (this) {
    // Raw body is intentionally omitted — it may contain sensitive API response data.
    is PaymentFailure.Http -> "HTTP $statusCode"
    is PaymentFailure.Serialization -> message
    is PaymentFailure.Transport -> message
}

