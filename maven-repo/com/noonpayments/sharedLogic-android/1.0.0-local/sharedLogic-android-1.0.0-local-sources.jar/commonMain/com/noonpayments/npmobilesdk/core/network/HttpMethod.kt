package com.noonpayments.npmobilesdk.core.network

/**
 * Minimal HTTP method set used by feature endpoints.
 */
enum class HttpMethod {
    GET,
    POST,
}

