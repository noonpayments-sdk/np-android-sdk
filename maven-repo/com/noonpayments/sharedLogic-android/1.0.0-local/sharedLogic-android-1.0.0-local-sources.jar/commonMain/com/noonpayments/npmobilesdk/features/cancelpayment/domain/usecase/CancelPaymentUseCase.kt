package com.noonpayments.npmobilesdk.features.cancelpayment.domain.usecase

import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository

class CancelPaymentUseCase(
    private val repository: IPaymentOrderRepository
) {
    suspend operator fun invoke(
        config: PaymentApiConfig,
        input: CancelPaymentInput = CancelPaymentInput()
    ): PaymentOperationResult<Unit> {
        return repository.cancelPayment(config, input)
    }
}
