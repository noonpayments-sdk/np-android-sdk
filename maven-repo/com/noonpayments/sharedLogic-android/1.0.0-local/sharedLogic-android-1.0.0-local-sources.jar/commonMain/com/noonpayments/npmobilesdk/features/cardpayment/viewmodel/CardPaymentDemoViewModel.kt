package com.noonpayments.npmobilesdk.features.cardpayment.viewmodel
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.SignatureDebug
import com.noonpayments.npmobilesdk.features.common.domain.SignatureGenerator
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.AddCardPaymentInfoUseCase
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.CardType
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.DetectCardBrandUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CardPaymentDemoState(
	val isLoading: Boolean = false,
	val resultCode: String? = null,
	val postUrl: String? = null,
	val resolvedOrderId: String? = null,
	val errorMessage: String? = null,
	val detectedCardType: CardType? = null,
)

class CardPaymentDemoViewModel(
	private val apiConfig: PaymentApiConfig,
	private val addCardPaymentInfoUseCase: AddCardPaymentInfoUseCase,
	private val detectCardBrandUseCase: DetectCardBrandUseCase,
	private val sessionStore: PaymentSheetSessionStore,
) {
	private val _state = MutableStateFlow(CardPaymentDemoState())
	val state: StateFlow<CardPaymentDemoState> = _state.asStateFlow()

	fun updateCardNumber(cardNumber: String) {
		val detectedCardType = detectCardBrandUseCase.execute(cardNumber)
		_state.value = _state.value.copy(detectedCardType = detectedCardType)
	}

	suspend fun submitSavedCard(
		tokenIdentifier: String,
		cvv: String,
	) {
		val signature = generateSignature()
		if (signature == null) {
			_state.value = _state.value.copy(
				errorMessage = _state.value.errorMessage
					?: (SignatureDebug.lastError ?: "Failed to generate SDK signature. RSA encryption may have failed.")
			)
			return
		}

		submit(
			CardPaymentInput(
				tokenIdentifier = tokenIdentifier,
				cvv = cvv,
				sdkSignature = signature,
			)
		)
	}

	suspend fun submitNewCard(
		cvv: String,
		cardNumber: String,
		expiryMonth: String,
		expiryYear: String,
		nameOnCard: String?,
		payerConsentForToken: Boolean,
	) {
		val signature = generateSignature()
		if (signature == null) {
			_state.value = _state.value.copy(
				errorMessage = _state.value.errorMessage
					?: (SignatureDebug.lastError ?: "Failed to generate SDK signature. RSA encryption may have failed.")
			)
			return
		}

		val orderConfig = sessionStore.state.value.orderConfiguration
		val encryptedNumber = SignatureGenerator.encryptCardNumber(
			cardNumber = cardNumber,
			encryptionKeyPem = orderConfig?.encryptionKey
		)
		if (encryptedNumber == null) {
			_state.value = _state.value.copy(
				errorMessage = "Failed to encrypt card number. Encryption key not available."
			)
			return
		}

		submit(
			CardPaymentInput(
				cvv = cvv,
				sdkSignature = signature,
				numberEncrypted = encryptedNumber,
				expiryMonth = expiryMonth,
				expiryYear = expiryYear,
				nameOnCard = nameOnCard,
				payerConsentForToken = payerConsentForToken,
			)
		)
	}

	private fun generateSignature(): String? {
		val orderConfig = sessionStore.state.value.orderConfiguration
		if (orderConfig == null) {
			_state.value = _state.value.copy(
				errorMessage = "Order configuration not loaded yet. Please wait or go to SDK_ORDER_CONFIGURATION first."
			)
			return null
		}

		val missingFields = mutableListOf<String>()
		if (orderConfig.orderCategory == null) missingFields.add("orderCategory")
		if (orderConfig.currency == null) missingFields.add("currency")
		if (orderConfig.orderChannel == null) missingFields.add("orderChannel")
		//if (orderConfig.encryptionKey == null) missingFields.add("encryptionKey")

        if (missingFields.isNotEmpty()) {
            _state.value = _state.value.copy(
                // Raw orderConfig payloads are intentionally excluded — they may contain sensitive data.
				errorMessage = "Order config loaded but missing fields: ${missingFields.joinToString(", ")}."
            )
            return null
        }

		return SignatureGenerator.generateCardPaymentSignature(
			orderId = apiConfig.orderId,
			orderCategory = orderConfig.orderCategory,
			currency = orderConfig.currency,
			orderChannel = orderConfig.orderChannel,
			encryptionKeyPem = orderConfig.encryptionKey
		)
	}

	private suspend fun submit(input: CardPaymentInput) {
		_state.value = _state.value.copy(isLoading = true, errorMessage = null)

		when (val result = addCardPaymentInfoUseCase(apiConfig, input)) {
			is PaymentOperationResult.Success -> {
				sessionStore.saveAddPaymentInfoResult(result.value)
				_state.value = CardPaymentDemoState(
					isLoading = false,
					resultCode = result.value.resultCode,
					postUrl = result.value.postUrl,
					resolvedOrderId = result.value.orderId,
				)
			}

			is PaymentOperationResult.Failure -> {
				val message = result.failure.toDisplayMessage()
				sessionStore.saveError(message)
				_state.value = _state.value.copy(
					isLoading = false,
					errorMessage = message,
				)
			}
		}
	}
}

