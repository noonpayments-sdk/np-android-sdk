package com.noonpayments.npmobilesdk.features.applepay.domain.usecase

import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository

class TokenizeApplePayUseCase(
    private val repository: IPaymentOrderRepository
) {
    suspend operator fun invoke(
        config: PaymentApiConfig,
        input: ApplePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        return repository.tokenizeApplePay(config, input)
    }
}
