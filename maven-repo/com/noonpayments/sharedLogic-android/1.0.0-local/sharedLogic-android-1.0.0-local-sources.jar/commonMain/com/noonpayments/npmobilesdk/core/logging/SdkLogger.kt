package com.noonpayments.npmobilesdk.core.logging

/**
 * Log severity levels used by SdkLogger.
 */
enum class LogLevel { DEBUG, INFO, WARN, ERROR }

/**
 * Shared logging interface for the NP Mobile SDK.
 *
 * Default implementation is [NoOpSdkLogger] — the SDK is completely silent in release builds.
 * [PrintSdkLogger] is activated automatically in iOS debug XCFramework builds via [isDebugBuild].
 * On Android, call [SdkLoggerConfig.configure] from your Application.onCreate() to enable logging.
 *
 * All log calls must pass through [LogSanitizer] before reaching any implementation.
 */
interface SdkLogger {
    fun log(level: LogLevel, tag: String, message: String, orderId: String = "unknown")

    companion object {
        /**
         * Returns the logger registered via [SdkLoggerConfig].
         * Falls back to [PrintSdkLogger] on iOS debug builds (via [isDebugBuild] expect/actual).
         * Always returns [NoOpSdkLogger] on Android unless [SdkLoggerConfig.configure] is called.
         */
        fun default(): SdkLogger = SdkLoggerConfig.activeLogger
    }
}

/**
 * No-op logger — zero overhead in release builds.
 * This is the production default; never produces any output.
 */
object NoOpSdkLogger : SdkLogger {
    override fun log(level: LogLevel, tag: String, message: String, orderId: String) = Unit
}

/**
 * Debug logger — writes to stdout via println.
 * Only activated in debug builds. Never ship to production.
 *
 * Format: [LEVEL] [tag] [orderId=<id>] message
 */
object PrintSdkLogger : SdkLogger {
    override fun log(level: LogLevel, tag: String, message: String, orderId: String) {
        println("[${level.name}] [$tag] [orderId=$orderId] $message")
    }
}

/**
 * Global logger configuration for the NP Mobile SDK.
 *
 * ### iOS
 * Logger is set automatically: [PrintSdkLogger] for debug XCFramework, [NoOpSdkLogger] for release.
 * No action required from iOS integrators.
 *
 * ### Android
 * The SDK defaults to [NoOpSdkLogger]. To enable logging in your app or demo:
 * ```kotlin
 * // In Application.onCreate() — guarded by your own BuildConfig.DEBUG
 * if (BuildConfig.DEBUG) {
 *     SdkLoggerConfig.configure(PrintSdkLogger)
 * }
 * ```
 */
object SdkLoggerConfig {
    internal var activeLogger: SdkLogger = if (isDebugBuild) PrintSdkLogger else NoOpSdkLogger

    /**
     * Overrides the active logger for the entire SDK session.
     * Call early in the app lifecycle (Application.onCreate / AppDelegate).
     *
     * Passing [NoOpSdkLogger] silences all output regardless of build type.
     */
    fun configure(logger: SdkLogger) {
        activeLogger = logger
    }
}


