package com.noonpayments.npmobilesdk.features.orderconfiguration.domain.usecase

import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository

class GetOrderConfigurationUseCase(
    private val repository: IPaymentOrderRepository
) {
    suspend operator fun invoke(config: PaymentApiConfig): PaymentOperationResult<OrderConfiguration> {
        return repository.getOrderConfiguration(config)
    }
}
