package com.noonpayments.npmobilesdk.core.logging

/**
 * Sanitizes headers and JSON bodies before any log emission.
 *
 * Deny-listed header keys: their values are replaced with "***".
 * Deny-listed JSON field names: matched string values are replaced with "***".
 *
 * This object is the single gate all log content must pass through.
 * Adding a new sensitive field requires only a change here.
 */
object LogSanitizer {

    private val SENSITIVE_HEADER_KEYS = setOf(
        "Authorization",
        "authorization"
    )

    private val SENSITIVE_JSON_KEYS = setOf(
        "cvv",
        "numberEncrypted",
        "paymentToken",
        "sdkSignature"
    )

    /**
     * Returns a copy of [headers] with sensitive values replaced by "***".
     */
    fun sanitizeHeaders(headers: Map<String, String>): Map<String, String> =
        headers.mapValues { (key, value) ->
            if (key in SENSITIVE_HEADER_KEYS) "***" else value
        }

    /**
     * Returns a copy of [body] with sensitive JSON field values replaced by "***".
     * Handles compact and pretty-printed JSON.
     * Returns null unchanged.
     */
    fun sanitizeBody(body: String?): String? {
        var result: String = body ?: return null
        for (key in SENSITIVE_JSON_KEYS) {
            // Matches: "key" : "value"  or  "key":"value"
            result = result.replace(
                Regex("(\"$key\"\\s*:\\s*\")([^\"]*)(\")", RegexOption.IGNORE_CASE),
                "$1***$3"
            )
        }
        return result
    }
}

