package com.noonpayments.npmobilesdk.features.paymenttransaction.domain.entity

/**
 * Domain model for a payment transaction.
 * Independent of the network/DTO layer.
 */
data class PaymentTransaction(
    val id: Int,
    val userId: Int,
    val title: String,
    val details: String  // Renamed from 'description' to avoid Swift keyword conflict
)

