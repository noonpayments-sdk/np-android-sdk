package com.noonpayments.npmobilesdk.features.orderstatus.domain.usecase

import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository

class FetchOrderStatusUseCase(
    private val repository: IPaymentOrderRepository
) {
    suspend operator fun invoke(
        config: PaymentApiConfig,
        orderId: String
    ): PaymentOperationResult<OrderStatusResult> {
        return repository.fetchOrderStatus(config, orderId)
    }
}
