package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Card input supports either encrypted card fields or a saved token identifier.
 * Note: sdkSignature is auto-generated if not provided.
 */
data class CardPaymentInput(
	val cvv: String,
	val tokenIdentifier: String? = null,
	val nameOnCard: String? = null,
	val numberEncrypted: String? = null,
	val expiryMonth: String? = null,
	val expiryYear: String? = null,
	val payerConsentForToken: Boolean? = null,
	val sdkSignature: String? = null
)

data class ApplePayPaymentInput(
    val paymentToken: String
)

data class GooglePayPaymentInput(
	val paymentMethodDataJson: String,
	val apiVersion: Int = 2,
	val apiVersionMinor: Int = 0,
	val payerConsentForToken: Boolean = false,
)

data class CancelPaymentInput(
    val reason: String = "Cancelled from checkout header."
)
