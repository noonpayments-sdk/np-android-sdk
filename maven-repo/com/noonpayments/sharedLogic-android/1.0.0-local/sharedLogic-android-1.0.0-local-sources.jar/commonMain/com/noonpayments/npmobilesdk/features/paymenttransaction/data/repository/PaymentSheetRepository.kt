package com.noonpayments.npmobilesdk.features.paymenttransaction.data.repository

import com.noonpayments.npmobilesdk.core.network.NetworkResult
import com.noonpayments.npmobilesdk.features.paymenttransaction.data.service.PaymentSheetService
import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.entity.PaymentTransaction
import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.repository.IPaymentSheetRepository

/**
 * PaymentSheetRepository implementation.
 * Calls the service, maps DTOs to domain models, handles errors.
 */
class PaymentSheetRepository(
    private val service: PaymentSheetService
) : IPaymentSheetRepository {

    override suspend fun getPaymentById(id: Int): PaymentTransaction? {
        return when (val result = service.fetchPaymentTransaction(id)) {
            is NetworkResult.Success -> result.data.toDomainModel()
            is NetworkResult.Failure -> null
        }
    }
}

private fun com.noonpayments.npmobilesdk.features.paymenttransaction.data.dto.PaymentTransactionDto.toDomainModel(): PaymentTransaction =
    PaymentTransaction(
        id = id,
        userId = userId,
        title = title,
        details = body
    )

