package com.noonpayments.npmobilesdk.features.common.domain

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

data class ApplePayConfiguration(
    val merchantIdentifier: String,
    val countryCode: String,
    val currencyCode: String,
    val summaryLabel: String,
    val summaryAmount: String,
    val supportedNetworks: List<String>,
)

fun OrderConfiguration.applePayConfigurationOrNull(): ApplePayConfiguration? {
    val paymentOptionsArray = paymentOptions as? JsonArray ?: return null
    val applePayOption = paymentOptionsArray
        .mapNotNull { it as? JsonObject }
        .firstOrNull { option -> option.isApplePayOption() }
        ?: return null

    val dataObject = applePayOption["data"] as? JsonObject ?: return null
    val paymentRequestObject = dataObject["paymentRequest"] as? JsonObject

    val merchantIdentifier = dataObject["merchantIdentifier"].asStringOrNull() ?: return null
    val countryCode = paymentRequestObject?.get("countryCode").asStringOrNull() ?: return null
    val currencyCode = paymentRequestObject?.get("currencyCode").asStringOrNull()
        ?: currency
        ?: return null

    val totalObject = paymentRequestObject?.get("total") as? JsonObject
    val summaryLabel = totalObject?.get("label").asStringOrNull() ?: "Noon Payments"
    val summaryAmount = totalObject?.get("amount").asStringOrNull()
        ?: order.asObjectOrNull()?.get("amount").asStringOrNull()
        ?: return null

    val supportedNetworks = paymentRequestObject?.get("supportedNetworks")
        .asArrayOrNull()
        ?.mapNotNull { it.asStringOrNull() }
        .orEmpty()

    return ApplePayConfiguration(
        merchantIdentifier = merchantIdentifier,
        countryCode = countryCode,
        currencyCode = currencyCode,
        summaryLabel = summaryLabel,
        summaryAmount = summaryAmount,
        supportedNetworks = supportedNetworks,
    )
}

private fun JsonObject.isApplePayOption(): Boolean {
    return listOf("action", "type", "method")
        .mapNotNull { key -> this[key].asStringOrNull() }
        .any { value -> value.equals("ApplePay", ignoreCase = true) }
}

private fun JsonElement?.asObjectOrNull(): JsonObject? = this as? JsonObject

private fun JsonElement?.asArrayOrNull(): JsonArray? = this as? JsonArray

private fun JsonElement?.asStringOrNull(): String? = (this as? JsonPrimitive)?.contentOrNull

