package com.noonpayments.npmobilesdk.features.common.domain

import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Stores the last RSA error for debugging purposes.
 */
object SignatureDebug {
    var lastError: String? = null
}

/**
 * Platform-specific SHA-512 hash computation.
 * Returns lowercase hex string of the 64-byte hash.
 */
internal expect fun platformComputeSha512(input: String): String

/**
 * Platform-specific RSA/PKCS1 v1.5 encryption.
 * Takes raw data and a PEM-encoded RSA public key.
 * Returns Base64-encoded encrypted bytes.
 */
internal expect fun platformEncryptRsaPkcs1(data: String, pemKey: String): String

/**
 * Generates SDK signature for card payment requests.
 *
 * Process:
 * 1. Build string: {orderId}|{category}|{currency}|{channel}|ADD_PAYMENT_INFO|noonpayments_sdk
 * 2. Convert to lowercase
 * 3. Hash with SHA-512
 * 4. Encrypt SHA-512 hex with RSA (PKCS1) using public key
 * 5. Base64 encode the result
 *
 * Uses platform-native crypto: Bouncy Castle on Android, Security.framework on iOS.
 */
@OptIn(ExperimentalEncodingApi::class)
object SignatureGenerator {

    /**
     * Generates the SDK signature for a card payment.
     *
     * @param orderId Order ID from the payment request
     * @param orderCategory Order category from order config
     * @param currency Currency from order config
     * @param orderChannel Order channel from order config
     * @param encryptionKeyPem RSA public key in PEM format
     * @return Base64-encoded RSA-encrypted SHA-512 hash, or null if any required parameter is missing
     */
    fun generateCardPaymentSignature(
        orderId: String,
        orderCategory: String?,
        currency: String?,
        orderChannel: String?,
        encryptionKeyPem: String?
    ): String? {
        // Validate required inputs
        if (orderCategory == null || currency == null || orderChannel == null || encryptionKeyPem == null) {
            return null
        }

        return try {
            // Step 1: Build signature string (pipe-delimited)
            val signatureString = buildString {
                append(orderId)
                append("|")
                append(orderCategory)
                append("|")
                append(currency)
                append("|")
                append(orderChannel)
                append("|ADD_PAYMENT_INFO|noonpayments_sdk")
            }

            // Step 2: Convert to lowercase
            val lowercasedSignature = signatureString.lowercase()

            // Step 3: Hash with SHA-512
            val sha512Hash = platformComputeSha512(lowercasedSignature)

            // Step 4 & 5: Encrypt with RSA PKCS1 and base64 encode
            val encryptedAndEncoded = platformEncryptRsaPkcs1(sha512Hash, encryptionKeyPem)

            SignatureDebug.lastError = null
            encryptedAndEncoded
        } catch (e: Exception) {
            SignatureDebug.lastError = "Signature RSA error: ${e::class.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Encrypts a raw card number using RSA (PKCS1) with the backend public key.
     *
     * @param cardNumber Raw card number
     * @param encryptionKeyPem RSA public key in PEM format
     * @return Base64-encoded RSA-encrypted card number, or null on failure
     */
    fun encryptCardNumber(
        cardNumber: String,
        encryptionKeyPem: String?
    ): String? {
        if (encryptionKeyPem == null) return null
        return try {
            val result = platformEncryptRsaPkcs1(cardNumber, encryptionKeyPem)
            SignatureDebug.lastError = null
            result
        } catch (e: Exception) {
            SignatureDebug.lastError = "Card encrypt RSA error: ${e::class.simpleName}: ${e.message}"
            null
        }
    }
}

/**
 * Extracts DER-encoded key bytes from a PEM-formatted string.
 * This is pure Kotlin (no platform dependency) — shared across all platforms.
 */
@OptIn(ExperimentalEncodingApi::class)
internal fun extractDerFromPem(pem: String): ByteArray {
    val lines = pem.split("\n")
    val keyLines = lines.filter { line ->
        line.isNotBlank() &&
        !line.startsWith("-----BEGIN") &&
        !line.startsWith("-----END")
    }
    val base64Key = keyLines.joinToString("")
    return Base64.decode(base64Key)
}
