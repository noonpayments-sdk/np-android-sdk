package com.noonpayments.npmobilesdk.features.orderstatus.viewmodel
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.orderstatus.domain.usecase.FetchOrderStatusUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class FetchOrderStatusDemoState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val orderStatus: String? = null,
    val transactionStatus: String? = null,
    val paymentDetailsJson: String? = null,
    val usedOrderId: String? = null,
    val errorMessage: String? = null,
)

class FetchOrderStatusDemoViewModel(
    private val apiConfig: PaymentApiConfig,
    private val fetchOrderStatusUseCase: FetchOrderStatusUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(FetchOrderStatusDemoState())
    val state: StateFlow<FetchOrderStatusDemoState> = _state.asStateFlow()

    suspend fun fetch(orderIdOverride: String?) {
        val resolvedOrderId = orderIdOverride
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: sessionStore.state.value.addPaymentInfoResult?.orderId
            ?: apiConfig.orderId

        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (val result = fetchOrderStatusUseCase(apiConfig, resolvedOrderId)) {
            is PaymentOperationResult.Success -> onSuccess(result.value, resolvedOrderId)
            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                    usedOrderId = resolvedOrderId,
                )
            }
        }
    }

    private fun onSuccess(value: OrderStatusResult, usedOrderId: String) {
        sessionStore.saveOrderStatusResult(value)
        _state.value = FetchOrderStatusDemoState(
            isLoading = false,
            resultCode = value.resultCode,
            orderStatus = value.orderStatus,
            transactionStatus = value.transactionStatus,
            paymentDetailsJson = value.paymentDetails?.toString(),
            usedOrderId = usedOrderId,
        )
    }
}

