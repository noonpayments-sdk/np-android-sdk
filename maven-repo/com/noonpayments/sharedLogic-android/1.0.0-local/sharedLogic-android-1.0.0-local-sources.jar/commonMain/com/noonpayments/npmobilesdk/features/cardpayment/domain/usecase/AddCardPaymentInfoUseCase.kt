package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository

class AddCardPaymentInfoUseCase(
    private val repository: IPaymentOrderRepository
) {
    suspend operator fun invoke(
        config: PaymentApiConfig,
        input: CardPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        return repository.addCardPaymentInfo(config, input)
    }
}
