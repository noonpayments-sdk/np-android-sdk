package com.noonpayments.npmobilesdk.features.paymenttransaction.domain.usecase

import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.entity.PaymentTransaction
import com.noonpayments.npmobilesdk.features.paymenttransaction.domain.repository.IPaymentSheetRepository

/**
 * GetPaymentTransactionUseCase encapsulates the business logic for retrieving a payment.
 * Delegates to the repository; can add cross-cutting concerns here (auth checks, logging, etc.).
 */
class GetPaymentTransactionUseCase(
    private val repository: IPaymentSheetRepository
) {
    suspend operator fun invoke(transactionId: Int): PaymentTransaction? {
        return repository.getPaymentById(transactionId)
    }
}

