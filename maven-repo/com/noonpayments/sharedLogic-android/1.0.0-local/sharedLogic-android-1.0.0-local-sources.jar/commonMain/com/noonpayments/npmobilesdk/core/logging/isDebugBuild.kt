package com.noonpayments.npmobilesdk.core.logging

/**
 * Platform-specific flag resolved at compile time.
 * - Android: backed by BuildConfig.DEBUG (false in release AAR, true in debug AAR)
 * - iOS:     backed by Platform.isDebugBinary (false in release XCFramework, true in debug XCFramework)
 */
internal expect val isDebugBuild: Boolean
