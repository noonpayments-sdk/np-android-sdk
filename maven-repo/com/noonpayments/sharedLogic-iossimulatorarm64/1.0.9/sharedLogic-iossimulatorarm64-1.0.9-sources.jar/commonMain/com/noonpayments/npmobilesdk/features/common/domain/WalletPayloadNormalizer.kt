package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Lightweight wallet token normalization before transport.
 */
fun normalizeApplePayTokenForTransport(token: String): String {
	return normalizeWalletPayloadForTransport(token)
}

/**
 * Lightweight wallet token normalization before transport.
 */
fun normalizeGooglePayTokenForTransport(token: String): String {
	return normalizeWalletPayloadForTransport(token)
}

private fun normalizeWalletPayloadForTransport(payload: String): String {
	return payload.trim().replace("\u0000", "")
}

