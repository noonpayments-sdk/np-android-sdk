package com.noonpayments.npmobilesdk.core.localization

/**
 * Init-time SDK language selection.
 *
 * The SDK resolves all localized strings and RTL/LTR direction from this single value.
 */
enum class SdkLanguage(
    val tokenId: String,
    val isRtl: Boolean,
) {
    ENGLISH(tokenId = "english", isRtl = false),
    ARABIC(tokenId = "arabic", isRtl = true),
    ;

    companion object {
        fun fromTokenId(tokenId: String): SdkLanguage = when (tokenId.trim().lowercase()) {
            "arabic", "ar" -> ARABIC
            else -> ENGLISH
        }
    }
}

