package com.noonpayments.npmobilesdk.core.localization

import com.noonpayments.npmobilesdk.core.designsystem.readResourceText

internal interface ILocalizationRepository {
    fun resolve(key: StringKey, language: SdkLanguage): String
}

internal class LocalizationRepository : ILocalizationRepository {
    private val english = LocalizationParser.parse(readResourceText("localization/en.json"))
    private val arabic = LocalizationParser.parse(readResourceText("localization/ar.json"))

    override fun resolve(key: StringKey, language: SdkLanguage): String {
        val resourceKey = key.resourceKey
        val selected = when (language) {
            SdkLanguage.ENGLISH -> english
            SdkLanguage.ARABIC -> arabic
        }
        return selected.strings[resourceKey]
            ?: english.strings[resourceKey]
            ?: error("Missing localization key '$resourceKey'.")
    }
}

