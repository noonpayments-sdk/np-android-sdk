package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Card input supports either encrypted card fields or a saved token identifier.
 * Note: sdkSignature is auto-generated if not provided.
 */
data class CardPaymentInput(
	val cvv: String,
	val tokenIdentifier: String? = null,
	val nameOnCard: String? = null,
	val numberEncrypted: String? = null,
	val expiryMonth: String? = null,
	val expiryYear: String? = null,
	val payerConsentForToken: Boolean? = null,
	val sdkSignature: String? = null,
	/**
	 * Set when the active order was configured via the portal-style
	 * `mobile/v1/order` API (see [PaymentApiConfig.entryInfo]/[PaymentApiConfig.entryQuery]).
	 * Non-null here switches [AddCardPaymentInfo] to the portal-style
	 * `mobile/v1/order/addPaymentInfo` request (no auth header, no sdkSignature).
	 */
	val portalOrderReference: String? = null
)

data class ApplePayPaymentInput(
	val paymentToken: String,
	val portalOrderReference: String? = null
)

data class GooglePayPaymentInput(
	val paymentToken: String,
	val portalOrderReference: String? = null,
)

data class CancelPaymentInput(
	val reason: String = "Cancelled from checkout header.",
	val portalOrderReference: String? = null,
)
