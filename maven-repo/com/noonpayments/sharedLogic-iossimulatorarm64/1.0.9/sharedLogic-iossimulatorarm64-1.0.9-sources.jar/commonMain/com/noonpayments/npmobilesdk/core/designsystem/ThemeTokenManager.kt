package com.noonpayments.npmobilesdk.core.designsystem

import com.noonpayments.npmobilesdk.core.localization.LocalizationRuntimeOverrides
import com.noonpayments.npmobilesdk.core.localization.SdkLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ThemeTokenManager(
    private val repository: IThemeTokenRepository,
    initialMode: ThemeMode = ThemeMode.LIGHT,
) {
    // No-arg constructor: creates default repository (local + remote services).
    constructor(initialMode: ThemeMode = ThemeMode.LIGHT) : this(
        repository = ThemeTokenRepository(),
        initialMode = initialMode,
    )

    // Backward-compatible: accepts a pre-built catalog (used by tests / ThemeTokenBootstrap).
    constructor(
        catalog: ThemeTokenCatalog,
        initialMode: ThemeMode = ThemeMode.LIGHT,
    ) : this(
        repository = ThemeTokenRepository(localCatalogOverride = catalog),
        initialMode = initialMode,
    )

    private val _mode = MutableStateFlow(initialMode)
    val mode: StateFlow<ThemeMode> = _mode.asStateFlow()

    /** Whether a remote token override is currently active. */
    val isRemoteActive: Boolean get() = repository.isRemoteActive

    fun setMode(mode: ThemeMode) {
        _mode.value = mode
        // Also push into the global runtime override so every other
        // ThemeTokenManager instance (each native component creates its own)
        // immediately resolves colors using this mode too — see `color()` below.
        ThemeTokenRuntimeOverrides.setThemeMode(mode)
    }

    /**
     * Attempts to apply remote JSON tokens via the repository.
     * Remote service validates (parses) the JSON. If valid → switches to remote.
     * If invalid → falls back to local automatically.
     */
    fun applyRemoteTokens(
        customizableJson: String,
        foundationJson: String,
    ): RemoteTokenResult {
        return repository.applyRemoteTokens(customizableJson, foundationJson)
    }

    /** Resets to the local bundled catalog, discarding any remote override. */
    fun resetToLocal() {
        repository.resetToLocal()
    }

    // --- String-based lookups (delegate to repository.catalog) ---

    // --- Typed foundation/customization/color token access ---
    // Foundation (spacing/borderRadius/borderWidth), customization (padding/radius), and
    // color (content/background/border/button/icon/selection) tokens are all modeled as
    // fixed, named properties rather than dictionaries or generated enums — see
    // FoundationTokens / CustomizationTokens / ColorTokens in ThemeTokenModels.kt.

    /** Customizable color tokens (content/background/border/button/icon/selection), not yet mode-resolved. */
    val colorTokens: ColorTokens
        get() = repository.catalog.colors

    /**
     * Resolves a [ModeAwareColorToken] (e.g. `colorTokens.background.primary`) to the
     * currently active [SdkColor].
     *
     * Resolved from the global runtime override (merchant's `NPAppearance.colorMode`,
     * SYSTEM already resolved to LIGHT/DARK) rather than this instance's local `mode`.
     * Every native component creates its own `ThemeTokenManager()` (often with a
     * hardcoded local `initialMode` default), so per-instance state can never reliably
     * reflect a merchant's runtime dark/light choice — only the shared singleton can.
     */
    fun resolve(token: ModeAwareColorToken): SdkColor =
        when (ThemeTokenRuntimeOverrides.currentThemeMode) {
            ThemeMode.LIGHT -> token.light
            ThemeMode.DARK -> token.dark
        }

    /** Non-customizable structural scale tokens (spacing, borderRadius, borderWidth). */
    val foundation: FoundationTokens
        get() = repository.catalog.foundation

    /** Customizable component-level tokens (padding, radius), with runtime overrides applied. */
    val customization: CustomizationTokens
        get() {
            val base = repository.catalog.customization
            val resolvedPadding = base.padding.copy(
                inputPadding = ThemeTokenRuntimeOverrides.currentPaddingOverride("inputPadding")
                    ?: base.padding.inputPadding,
                ctaPadding = ThemeTokenRuntimeOverrides.currentPaddingOverride("CTAPadding")
                    ?: base.padding.ctaPadding,
                separatorPadding = ThemeTokenRuntimeOverrides.currentPaddingOverride("SeparatorPadding")
                    ?: base.padding.separatorPadding,
                verticalPadding = ThemeTokenRuntimeOverrides.currentPaddingOverride("VerticalPadding")
                    ?: base.padding.verticalPadding,
                floatingSpace = ThemeTokenRuntimeOverrides.currentPaddingOverride("FloatingSpace")
                    ?: base.padding.floatingSpace,
                cardPaddingTop = ThemeTokenRuntimeOverrides.currentPaddingOverride("CardPaddingTop")
                    ?: base.padding.cardPaddingTop,
                cardPaddingBottom = ThemeTokenRuntimeOverrides.currentPaddingOverride("CardPaddingBottom")
                    ?: base.padding.cardPaddingBottom,
                cardPadding = ThemeTokenRuntimeOverrides.currentPaddingOverride("CardPadding")
                    ?: base.padding.cardPadding,
                componentPadding = ThemeTokenRuntimeOverrides.currentPaddingOverride("ComponentPadding")
                    ?: base.padding.componentPadding,
            )
            val resolvedRadius = base.radius.copy(
                bottomSheetCornerRadius = ThemeTokenRuntimeOverrides.currentRadiusOverride("BottomSheetCornerRadius")
                    ?: base.radius.bottomSheetCornerRadius,
                inputCornerRadius = ThemeTokenRuntimeOverrides.currentRadiusOverride("InputCornerRadius")
                    ?: base.radius.inputCornerRadius,
                ctaCornerRadius = ThemeTokenRuntimeOverrides.currentRadiusOverride("CTACornerRadius")
                    ?: base.radius.ctaCornerRadius,
                floatingCardCornerRadius = ThemeTokenRuntimeOverrides.currentRadiusOverride("FloatingCardCornerRadius")
                    ?: base.radius.floatingCardCornerRadius,
            )
            return base.copy(padding = resolvedPadding, radius = resolvedRadius)
        }

    fun fontFamily(tokenId: String): String =
        repository.catalog.typography.fontFamily[tokenId] ?: error("Missing fontFamily token '$tokenId'.")
    fun fontSize(tokenId: String): Float {
        val baseSize = repository.catalog.typography.fontSize[tokenId]
            ?: error("Missing fontSize token '$tokenId'.")
        return baseSize * ThemeTokenRuntimeOverrides.currentFontScaleFactor
    }
    fun fontWeight(tokenId: String): Int =
        repository.catalog.typography.fontWeight[tokenId] ?: error("Missing fontWeight token '$tokenId'.")
    fun lineHeight(tokenId: String): Float =
        repository.catalog.typography.lineHeight[tokenId] ?: error("Missing lineHeight token '$tokenId'.")

    /**
     * Locale-resolved semantic fonts: title/primary/secondary/tertiary.
     *
     * Language is resolved automatically from [LocalizationRuntimeOverrides] (set once from the
     * merchant-provided appearance object at SDK init) — callers never pass a language or token id.
     * Access from native UI via `themeTokenManager.fonts.primary.toNative()` (platform extension).
     */
    val fonts: SemanticLocaleTypographyTokens
        get() = scaledFonts(
            when (LocalizationRuntimeOverrides.currentLanguage) {
                SdkLanguage.ARABIC -> repository.catalog.semanticTypography.arabic
                SdkLanguage.ENGLISH -> repository.catalog.semanticTypography.english
            }
        )

    /**
     * English semantic fonts regardless of the active language. Used for brand names
     * (e.g. "Apple Pay", "Google Pay") that must always render in the English typeface.
     */
    val englishFonts: SemanticLocaleTypographyTokens
        get() = scaledFonts(repository.catalog.semanticTypography.english)

    private fun scaledFonts(locale: SemanticLocaleTypographyTokens): SemanticLocaleTypographyTokens {
        val scale = ThemeTokenRuntimeOverrides.currentFontScaleFactor
        fun scaled(font: SemanticFontTokens) = font.copy(
            fontSize = font.fontSize * scale,
            lineHeight = font.lineHeight * scale,
        )
        return SemanticLocaleTypographyTokens(
            title = scaled(locale.title),
            primary = scaled(locale.primary),
            secondary = scaled(locale.secondary),
            tertiary = scaled(locale.tertiary),
        )
    }
}

object ThemeTokenBootstrap {
    fun fromJson(
        customizableJson: String,
        foundationJson: String,
        initialMode: ThemeMode = ThemeMode.LIGHT,
    ): ThemeTokenManager {
        val catalog = ThemeTokenParser.parse(
            customizableJson = customizableJson,
            foundationJson = foundationJson,
        )
        return ThemeTokenManager(
            catalog = catalog,
            initialMode = initialMode,
        )
    }
}
