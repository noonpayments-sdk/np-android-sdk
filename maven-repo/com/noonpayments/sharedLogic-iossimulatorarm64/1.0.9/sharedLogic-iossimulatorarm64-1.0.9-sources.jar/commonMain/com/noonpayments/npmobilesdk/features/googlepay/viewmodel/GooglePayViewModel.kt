package com.noonpayments.npmobilesdk.features.googlepay.viewmodel
import com.noonpayments.npmobilesdk.core.logging.reportSdkValidationFailure
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.normalizeGooglePayTokenForTransport
import com.noonpayments.npmobilesdk.features.googlepay.domain.usecase.TokenizeGooglePayUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class GooglePayState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val postUrl: String? = null,
    val resolvedOrderId: String? = null,
    val errorMessage: String? = null,
)

class GooglePayViewModel(
    private val apiConfig: PaymentApiConfig,
    private val tokenizeGooglePayUseCase: TokenizeGooglePayUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(GooglePayState())
    val state: StateFlow<GooglePayState> = _state.asStateFlow()

    suspend fun submit(paymentToken: String) {
        if (paymentToken.isBlank()) {
            val reason = "Google Pay payment token is required"
            _state.value = _state.value.copy(errorMessage = reason)
            reportSdkValidationFailure(SCREEN_NAME, reason, apiConfig.requestIdentifier)
            return
        }

        val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
        if (portalOrderReference.isNullOrBlank()) {
            val reason = "Portal order reference is not available yet. Load order configuration first."
            _state.value = _state.value.copy(errorMessage = reason)
            sessionStore.saveError(reason)
            return
        }

        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (
            val result = tokenizeGooglePayUseCase(
                apiConfig,
                GooglePayPaymentInput(
                    paymentToken = normalizeGooglePayTokenForTransport(paymentToken),
                    portalOrderReference = portalOrderReference,
                )
            )
        ) {
            is PaymentOperationResult.Success -> {
                sessionStore.saveAddPaymentInfoResult(result.value)
                _state.value = GooglePayState(
                    isLoading = false,
                    resultCode = result.value.resultCode,
                    postUrl = result.value.postUrl,
                    resolvedOrderId = result.value.orderId,
                )
            }

            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                reportSdkValidationFailure(SCREEN_NAME, message, portalOrderReference)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                )
            }
        }
    }

    private companion object {
        const val SCREEN_NAME = "GooglePayViewModel"
    }
}



