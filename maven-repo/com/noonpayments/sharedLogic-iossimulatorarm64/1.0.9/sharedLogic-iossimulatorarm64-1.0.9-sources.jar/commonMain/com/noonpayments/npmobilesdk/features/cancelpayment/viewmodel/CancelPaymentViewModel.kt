package com.noonpayments.npmobilesdk.features.cancelpayment.viewmodel
import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.cancelpayment.domain.usecase.CancelPaymentUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CancelPaymentState(
    val isLoading: Boolean = false,
    val isCancelled: Boolean = false,
    val usedReason: String? = null,
    val errorMessage: String? = null,
)

class CancelPaymentViewModel(
    private val apiConfig: PaymentApiConfig,
    private val cancelPaymentUseCase: CancelPaymentUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(CancelPaymentState())
    val state: StateFlow<CancelPaymentState> = _state.asStateFlow()

    suspend fun cancel(reason: String) {
        val resolvedReason = reason.trim().ifEmpty { "Cancelled from checkout header." }
        val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
        if (portalOrderReference.isNullOrBlank()) {
            val message = "Portal order reference is not available yet. Load order configuration first."
            sessionStore.saveError(message)
            _state.value = _state.value.copy(
                isLoading = false,
                usedReason = resolvedReason,
                errorMessage = message,
            )
            return
        }
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (
            val result = cancelPaymentUseCase(
                apiConfig,
                CancelPaymentInput(reason = resolvedReason, portalOrderReference = portalOrderReference)
            )
        ) {
            is PaymentOperationResult.Success -> {
                _state.value = CancelPaymentState(
                    isLoading = false,
                    isCancelled = true,
                    usedReason = resolvedReason,
                )
            }

            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, portalOrderReference)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    usedReason = resolvedReason,
                    errorMessage = message,
                )
            }
        }
    }

    private companion object {
        const val SCREEN_NAME = "CancelPaymentViewModel"
    }
}


