package com.noonpayments.npmobilesdk.features.orderstatus.viewmodel
import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.orderstatus.domain.usecase.FetchOrderStatusUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class FetchOrderStatusState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val orderStatus: String? = null,
    val transactionStatus: String? = null,
    val paymentDetailsJson: String? = null,
    val usedPortalOrderReference: String? = null,
    val errorMessage: String? = null,
)

class FetchOrderStatusViewModel(
    private val apiConfig: PaymentApiConfig,
    private val fetchOrderStatusUseCase: FetchOrderStatusUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(FetchOrderStatusState())
    val state: StateFlow<FetchOrderStatusState> = _state.asStateFlow()

    suspend fun fetch(portalOrderReferenceOverride: String?) {
        val resolvedPortalOrderReference = portalOrderReferenceOverride
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: sessionStore.state.value.orderConfiguration?.portalOrderReference

        if (resolvedPortalOrderReference.isNullOrBlank()) {
            val message = "Portal order reference is not available yet. Load order configuration first."
            sessionStore.saveError(message)
            _state.value = _state.value.copy(
                isLoading = false,
                errorMessage = message,
                usedPortalOrderReference = null,
            )
            return
        }

        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (val result = fetchOrderStatusUseCase(apiConfig, resolvedPortalOrderReference)) {
            is PaymentOperationResult.Success -> onSuccess(result.value, resolvedPortalOrderReference)
            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, resolvedPortalOrderReference)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                    usedPortalOrderReference = resolvedPortalOrderReference,
                )
            }
        }
    }

    private fun onSuccess(value: OrderStatusResult, usedPortalOrderReference: String) {
        sessionStore.saveOrderStatusResult(value)
        _state.value = FetchOrderStatusState(
            isLoading = false,
            resultCode = value.resultCode,
            orderStatus = value.orderStatus,
            transactionStatus = value.transactionStatus,
            paymentDetailsJson = value.paymentDetails?.toString(),
            usedPortalOrderReference = usedPortalOrderReference,
        )
    }

    private companion object {
        const val SCREEN_NAME = "FetchOrderStatusViewModel"
    }
}


