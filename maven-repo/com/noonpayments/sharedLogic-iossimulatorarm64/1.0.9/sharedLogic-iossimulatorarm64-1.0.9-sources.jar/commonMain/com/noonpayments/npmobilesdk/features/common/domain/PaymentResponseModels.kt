package com.noonpayments.npmobilesdk.features.common.domain

import kotlinx.serialization.json.JsonElement

data class OrderConfiguration(
	val resultCode: String?,
	val order: JsonElement?,
	val paymentOptions: JsonElement?,
	val paymentTokens: JsonElement? = null,
	val orderCategory: String? = null,
	val currency: String? = null,
	val orderChannel: String? = null,
	val encryptionKey: String? = null,
	/**
	 * Present only when the order-configuration response came from the
	 * portal-style `mobile/v1/order` API (i.e. the SDK was initialized with a
	 * portal entry URL). Required by [AddCardPaymentInfo] requests instead of
	 * an upfront order id.
	 *
	 * This is an **SDK-internal** identifier — do not surface it to the
	 * merchant as "the" order id. See [id] for the merchant-facing identifier.
	 */
	val portalOrderReference: String? = null,
	/**
	 * The merchant-facing order id returned by the order-configuration API's
	 * top-level/`result.order` `"id"` field (portal-style: top-level `id`;
	 * legacy-style: `result.order.id`). This is the identifier the merchant's
	 * own backend/webhooks use to look up the order — it is what the SDK
	 * should surface as `NPMobileSDKPaymentResponse.orderId`, not
	 * [portalOrderReference].
	 */
	val id: String? = null,
	/**
	 * Mirrors the `Card` payment option's `data.cvvRequired` flag from the
	 * order-configuration response (e.g. `"cvvRequired": "True"`). Defaults to
	 * `true` (the pre-existing/legacy behavior — always show + require CVV)
	 * when the `Card` payment option or the flag itself is absent/unparseable,
	 * so orders from backends that don't send this field are unaffected.
	 * `false` means the saved-card CVV field can be hidden and Pay can be
	 * enabled without a CVV being entered.
	 */
	val cvvRequired: Boolean = true,
	/**
	 * Mirrors the order-configuration `requiredCardHolderName` flag. `true` means the
	 * "Name on card" field is shown in the add-card sheet and must be filled in;
	 * `false` means the field is hidden and not sent. Defaults to `false` when the
	 * backend omits the flag.
	 */
	val requiredCardHolderName: Boolean = false,
	/** Top-level order total from the portal-style response (e.g. `100.00`); `null` otherwise. */
	val amount: String? = null
)

data class AddPaymentInfoResult(
    val resultCode: String?,
    val postUrl: String?,
    val orderId: String?,
    /** Backend's authoritative 3DS flag (`isAuthenticationRequired`). */
    val isAuthenticationRequired: Boolean? = null,
    val isPasskeyAuthentication: Boolean? = null,
) {
    /**
     * 3DS must be opened only when the backend says authentication is required.
     * `postUrl` is the location to open, never the decision itself. When the flag
     * is absent (legacy `resultCode` responses), fall back to `postUrl` presence.
     */
    val requiresThreeDs: Boolean
        get() = when (isAuthenticationRequired) {
            true -> !postUrl.isNullOrBlank()
            false -> false
            null -> !postUrl.isNullOrBlank()
        }

    /** Backend requires authentication but returned no `postUrl` — an error, not a success. */
    val isAuthenticationWithoutUrl: Boolean
        get() = isAuthenticationRequired == true && postUrl.isNullOrBlank()
}

data class OrderStatusResult(
    val resultCode: String?,
    val orderStatus: String?,
    val transactionStatus: String?,
    val paymentDetails: JsonElement?
)
