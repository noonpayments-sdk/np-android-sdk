package com.noonpayments.npmobilesdk.features.cardpayment.viewmodel
import com.noonpayments.npmobilesdk.core.logging.reportSdkValidationFailure
import com.noonpayments.npmobilesdk.features.common.presentation.apiErrorOrNull
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.SignatureGenerator
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.AddCardPaymentInfoUseCase
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.CardType
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.DetectCardBrandUseCase
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.ValidateNewCardUseCase
import com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase.cvvLengthFor
import com.noonpayments.npmobilesdk.core.localization.StringKey
import com.noonpayments.npmobilesdk.core.localization.localized
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

data class CardPaymentState(
	val isLoading: Boolean = false,
	val resultCode: String? = null,
	val postUrl: String? = null,
	val resolvedOrderId: String? = null,
	val errorMessage: String? = null,
	val detectedCardType: CardType? = null,
	val newCard: NewCardForm = NewCardForm(),
	/** Mirrors [OrderConfiguration.requiredCardHolderName]: shows + requires the "Name on card" field. */
	val isCardHolderNameRequired: Boolean = false,
	/** Mirrors [OrderConfiguration.cvvRequired]: when `false` no CVV input is shown and none is required. */
	val isCvvRequired: Boolean = true,
) {
	/** Max CVV digits for the detected brand (4 for AMEX, otherwise 3). */
	val cvvMaxLength: Int get() = cvvLengthFor(detectedCardType)

	/** True when every entered card detail is valid; drives the Pay button. */
	val isNewCardValid: Boolean
		get() = (!isCardHolderNameRequired || newCard.name.isNotBlank()) &&
			ValidateNewCardUseCase().execute(
				newCard.number, newCard.expiry, newCard.cvv, detectedCardType, cvvRequired = isCvvRequired,
			).isValid
}

data class NewCardForm(
	val name: String = "",
	val number: String = "",
	val expiry: String = "",
	val cvv: String = "",
	val storeCard: Boolean = false,
	val nameInvalid: Boolean = false,
	val numberInvalid: Boolean = false,
	val expiryInvalid: Boolean = false,
	val cvvInvalid: Boolean = false,
)

class CardPaymentViewModel(
	private val apiConfig: PaymentApiConfig,
	private val addCardPaymentInfoUseCase: AddCardPaymentInfoUseCase,
	private val detectCardBrandUseCase: DetectCardBrandUseCase,
	private val sessionStore: PaymentSheetSessionStore,
) {
	private val _state = MutableStateFlow(CardPaymentState())
	val state: StateFlow<CardPaymentState> = _state.asStateFlow()
	private val validateNewCard = ValidateNewCardUseCase()

	fun resetNewCardForm() {
		if (!_state.value.isLoading) {
			_state.value = CardPaymentState(
				isCardHolderNameRequired = isCardHolderNameRequiredByOrder(),
				isCvvRequired = isCvvRequiredByOrder(),
			)
		}
	}

	fun updateNewCardName(value: String) = updateForm(_state.value.newCard.copy(name = value, nameInvalid = false))
	fun updateNewCardNumber(value: String) {
		if (_state.value.isLoading) return
		val digits = value.filter { it in '0'..'9' }.take(19)
		updateForm(_state.value.newCard.copy(number = digits.chunked(4).joinToString(" "), numberInvalid = false))
		updateCardNumber(digits)
	}
	fun updateNewCardExpiry(value: String) {
		val digits = value.filter { it in '0'..'9' }.take(4)
		val expiry = if (digits.length <= 2) digits else "${digits.take(2)}/${digits.drop(2)}"
		updateForm(_state.value.newCard.copy(expiry = expiry, expiryInvalid = false))
	}
	fun updateNewCardCvv(value: String) = updateForm(
		_state.value.newCard.copy(
			cvv = value.filter { it in '0'..'9' }.take(_state.value.cvvMaxLength),
			cvvInvalid = false,
		)
	)
	fun updateNewCardConsent(value: Boolean) = updateForm(_state.value.newCard.copy(storeCard = value))

	private fun updateForm(form: NewCardForm) {
		if (!_state.value.isLoading) _state.value = _state.value.copy(newCard = form, errorMessage = null)
	}

	fun reportNewCardFailure(message: String) {
		_state.value = _state.value.copy(isLoading = false, errorMessage = message)
		reportSdkValidationFailure(SCREEN_NAME, message, apiConfig.requestIdentifier)
	}

	suspend fun submitNewCardForm() {
		if (_state.value.isLoading) return
		val form = _state.value.newCard
		val nameRequired = _state.value.isCardHolderNameRequired
		val nameMissing = nameRequired && form.name.isBlank()
		val cvvRequired = _state.value.isCvvRequired
		val validation = validateNewCard.execute(
			form.number, form.expiry, form.cvv, _state.value.detectedCardType, cvvRequired = cvvRequired,
		)
		_state.value = _state.value.copy(
			resultCode = null, postUrl = null, resolvedOrderId = null,
			newCard = form.copy(
				nameInvalid = nameMissing,
				numberInvalid = validation.cardNumberInvalid,
				expiryInvalid = validation.expiryInvalid,
				cvvInvalid = validation.cvvInvalid,
			),
			errorMessage = null,
		)
		if (nameMissing || !validation.isValid) {
			val key = when {
				nameMissing -> StringKey.NameOnCardRequired
				validation.cardNumberInvalid -> StringKey.InvalidCardNumber
				validation.expiryInvalid -> StringKey.InvalidExpiry
				else -> StringKey.SavedCardInvalidCvv
			}
			reportSdkValidationFailure(SCREEN_NAME, key.localized(), apiConfig.requestIdentifier)
			return
		}
		try {
			submitNewCard(
				cvv = if (cvvRequired) form.cvv else "",
				cardNumber = form.number.replace(" ", ""),
				expiryMonth = form.expiry.take(2),
				expiryYear = "20${form.expiry.takeLast(2)}",
				nameOnCard = form.name.trim().takeIf { nameRequired && it.isNotEmpty() },
				payerConsentForToken = form.storeCard,
			)
		} finally {
			_state.value = _state.value.copy(isLoading = false)
		}
	}

	fun updateCardNumber(cardNumber: String) {
		val detectedCardType = detectCardBrandUseCase.execute(cardNumber)
		val current = _state.value
		_state.value = current.copy(
			detectedCardType = detectedCardType,
			newCard = current.newCard.copy(cvv = current.newCard.cvv.take(cvvLengthFor(detectedCardType))),
		)
	}

	suspend fun submitSavedCard(
		tokenIdentifier: String,
		cvv: String,
	) {
		val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
		if (portalOrderReference.isNullOrBlank()) {
			val reason = "Portal order reference is not available yet. Load order configuration first."
			_state.value = _state.value.copy(
				errorMessage = reason
			)
			reportSdkValidationFailure(SCREEN_NAME, reason, apiConfig.requestIdentifier)
			return
		}

		submit(
			CardPaymentInput(
				tokenIdentifier = tokenIdentifier,
				cvv = cvv,
				portalOrderReference = portalOrderReference,
			)
		)
	}

	suspend fun submitNewCard(
		cvv: String,
		cardNumber: String,
		expiryMonth: String,
		expiryYear: String,
		nameOnCard: String?,
		payerConsentForToken: Boolean,
	) {
		val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
		if (portalOrderReference.isNullOrBlank()) {
			val reason = "Portal order reference is not available yet. Load order configuration first."
			_state.value = _state.value.copy(
				errorMessage = reason
			)
			reportSdkValidationFailure(SCREEN_NAME, reason, apiConfig.requestIdentifier)
			return
		}

		val orderConfig = sessionStore.state.value.orderConfiguration
		val encryptedNumber = SignatureGenerator.encryptCardNumber(
			cardNumber = cardNumber,
			encryptionKeyPem = orderConfig?.encryptionKey
		)
		if (encryptedNumber == null) {
			val reason = "Failed to encrypt card number. Encryption key not available."
			_state.value = _state.value.copy(
				errorMessage = reason
			)
			reportSdkValidationFailure(SCREEN_NAME, reason, portalOrderReference)
			return
		}

		submit(
			CardPaymentInput(
				cvv = cvv,
				numberEncrypted = encryptedNumber,
				expiryMonth = expiryMonth,
				expiryYear = expiryYear,
				nameOnCard = nameOnCard,
				payerConsentForToken = payerConsentForToken,
				portalOrderReference = portalOrderReference,
			)
		)
	}

	private fun isCvvRequiredByOrder(): Boolean =
		sessionStore.state.value.orderConfiguration?.cvvRequired != false

	private fun isCardHolderNameRequiredByOrder(): Boolean =
		sessionStore.state.value.orderConfiguration?.requiredCardHolderName == true

	private fun validateOrderConfigurationForCardPayment(): Boolean {
		val orderConfig = sessionStore.state.value.orderConfiguration
		if (orderConfig == null) {
			val reason = "Order configuration not loaded yet. Please wait or go to SDK_ORDER_CONFIGURATION first."
			_state.value = _state.value.copy(
				errorMessage = reason
			)
			reportSdkValidationFailure(SCREEN_NAME, reason, apiConfig.requestIdentifier)
			return false
		}

		val missingFields = mutableListOf<String>()
		if (orderConfig.encryptionKey == null) missingFields.add("encryptionKey")

		if (missingFields.isNotEmpty()) {
			var reason = "Order config loaded but missing fields: ${missingFields.joinToString(", ")}."
			if (orderConfig.encryptionKey == null) {
				// encryptionKey is extracted from a "Card"-typed entry in paymentOptions[]. If no
				// such entry exists at all (common when the order/merchant only has ApplePay/GooglePay
				// enabled, even though saved paymentTokens may still be present), there is no RSA key
				// anywhere in the backend response — this is a backend/merchant configuration issue,
				// not an SDK parsing bug. Surface the available option types to make that actionable.
				val availableTypes = (orderConfig.paymentOptions as? JsonArray)
					?.mapNotNull { (it as? JsonObject)?.get("type")?.let { t -> (t as? JsonPrimitive)?.contentOrNull } }
				reason += " The merchant's order configuration does not expose a Card payment option" +
					" with an encryption key (available payment option types: ${availableTypes ?: "none"})." +
					" Card payments — including saved cards — require the merchant/backend to enable" +
					" Card as a payment option on this order."
			}
			_state.value = _state.value.copy(
				// Raw orderConfig payloads are intentionally excluded — they may contain sensitive data.
				errorMessage = reason
			)
			reportSdkValidationFailure(
				SCREEN_NAME,
				reason,
				orderConfig.portalOrderReference ?: apiConfig.requestIdentifier,
			)
			return false
		}

		return true
	}

	private suspend fun submit(input: CardPaymentInput) {
		if (!validateOrderConfigurationForCardPayment()) return
		_state.value = _state.value.copy(isLoading = true, errorMessage = null)

		when (val result = addCardPaymentInfoUseCase(apiConfig, input)) {
			is PaymentOperationResult.Success -> {
				val info = result.value
				if (info.isAuthenticationWithoutUrl) {
					// Backend demands 3DS but gave no URL: an error, never a silent success.
					val message = "Authentication is required but no 3DS URL was returned. Please try again."
					reportSdkValidationFailure(SCREEN_NAME, message, input.portalOrderReference ?: apiConfig.requestIdentifier)
					sessionStore.saveError(message)
					_state.value = _state.value.copy(isLoading = false, errorMessage = message)
					return
				}
				sessionStore.saveAddPaymentInfoResult(info)
				_state.value = CardPaymentState(
					isLoading = false,
					resultCode = info.resultCode,
					// The WebView is opened only when the backend says authentication is required.
					postUrl = info.postUrl.takeIf { info.requiresThreeDs },
					resolvedOrderId = info.orderId,
					isCardHolderNameRequired = _state.value.isCardHolderNameRequired,
					isCvvRequired = _state.value.isCvvRequired,
				)
			}

			is PaymentOperationResult.Failure -> {
				val message = result.failure.toDisplayMessage()
				val field = result.failure.apiErrorOrNull()?.invalidField
				reportSdkValidationFailure(
					SCREEN_NAME,
					message,
					input.portalOrderReference ?: apiConfig.requestIdentifier,
				)
				sessionStore.saveError(message)
				_state.value = _state.value.copy(
					isLoading = false,
					errorMessage = message,
					// Highlight the field the backend rejected (5106 "Field paymentData.data.<f> is not valid").
					newCard = _state.value.newCard.copy(
						cvvInvalid = field == "cvv",
						expiryInvalid = field == "expiryMonth" || field == "expiryYear",
					),
				)
			}
		}
	}

	private companion object {
		const val SCREEN_NAME = "CardPaymentViewModel"
	}
}
