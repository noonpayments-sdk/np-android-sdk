package com.noonpayments.npmobilesdk.features.common.domain

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/**
 * Display text for the order total shown inside the Pay CTA (e.g. `"AED 25.00"`),
 * or `null` when the order configuration carries no usable amount.
 *
 * Reads `order.amount`, which may be a primitive or an object (`{ "amount"/"value", "currency" }`);
 * the currency falls back to [OrderConfiguration.currency] / `order.currency`.
 */
fun OrderConfiguration.payAmountTextOrNull(): String? {
    val orderObject = order as? JsonObject
    val amountElement = orderObject?.get("amount")
    val amountObject = amountElement as? JsonObject

    val nestedAmount = (amountObject?.get("amount") ?: amountObject?.get("value") ?: amountElement)
        .primitiveContentOrNull()
        ?.takeIf { amountObject != null || amountElement is JsonPrimitive }
    val amount = (nestedAmount ?: this.amount)
        ?.trim()
        ?.takeIf { it.isNotEmpty() }
        ?: return null

    val currencyCode = currency?.takeIf { it.isNotBlank() }
        ?: amountObject?.get("currency").primitiveContentOrNull()
        ?: orderObject?.get("currency").primitiveContentOrNull()

    val formattedAmount = formatAmount(amount)
    return if (currencyCode.isNullOrBlank()) formattedAmount else "$currencyCode $formattedAmount"
}

/** Normalizes numeric amounts to two decimals (`25` → `25.00`); leaves non-numeric text unchanged. */
internal fun formatAmount(raw: String): String {
    val value = raw.toDoubleOrNull() ?: return raw
    val cents = kotlin.math.round(value * 100).toLong()
    val whole = cents / 100
    val fraction = kotlin.math.abs(cents % 100).toString().padStart(2, '0')
    return "$whole.$fraction"
}

private fun JsonElement?.primitiveContentOrNull(): String? = (this as? JsonPrimitive)?.contentOrNull

