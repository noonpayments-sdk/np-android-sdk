package com.noonpayments.npmobilesdk.core.designsystem

import kotlinx.serialization.json.Json

object ThemeTokenParser {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    /**
     * Parses customizable + foundation JSON files into a shared canonical model.
     * Fails fast when required data is missing or malformed.
     */
    fun parse(
        customizableJson: String,
        foundationJson: String,
        colorOverrides: ThemeTokenColorOverrides = ThemeTokenColorOverrides(),
    ): ThemeTokenCatalog {
        val customizable = json.decodeFromString<CustomizableTokensJson>(customizableJson)
        val foundation = json.decodeFromString<FoundationTokensJson>(foundationJson)
        validateSchemaVersions(customizable.schemaVersion, foundation.schemaVersion)

        // Flatten "category -> key -> hex" into "category/Key" -> hex so merchant color
        // overrides (string-keyed, e.g. "background/Primary") can be merged in before the
        // typed ColorTokens model is built.
        val mergedLight = flattenColorGroups(customizable.colors.light) + colorOverrides.light
        val mergedDark = flattenColorGroups(customizable.colors.dark) + colorOverrides.dark

        val colorTokens = buildColorTokens(mergedLight, mergedDark)

         // Merge typography from both customizable and foundation (customizable takes precedence)
         val custTypo = customizable.typography
         val foundTypo = foundation.typography
         val mergedFontFamily = (foundTypo.fontFamily + custTypo.fontFamily)
         val mergedFontSize = (foundTypo.fontSize + custTypo.fontSize)
         val mergedFontWeight = (foundTypo.fontWeight + custTypo.fontWeight)
         val mergedLineHeight = (foundTypo.lineHeight + custTypo.lineHeight)
         val semanticTypography = buildSemanticTypography(custTypo)

         return ThemeTokenCatalog(
             schemaVersion = customizable.schemaVersion,
             colors = colorTokens,
             typography = TypographyTokens(
                 fontFamily = mergedFontFamily,
                 fontSize = mergedFontSize.mapValues { (_, value) -> value.toFloat() },
                 fontWeight = mergedFontWeight,
                 lineHeight = mergedLineHeight.mapValues { (_, value) -> value.toFloat() },
             ),
             semanticTypography = semanticTypography,
             foundation = buildFoundationTokens(foundation),
             customization = buildCustomizationTokens(customizable),
        )
    }

    /**
     * Foundation/customization tokens are a stable, curated scale (see [FoundationTokens] /
     * [CustomizationTokens]). Remote token payloads are only expected to override colors and
     * typography, so a missing key here falls back to the documented canonical default rather
     * than failing the whole parse.
     */
    private fun Map<String, Double>.floatOf(key: String, default: Float): Float =
        this[key]?.toFloat() ?: default

    private fun buildFoundationTokens(foundation: FoundationTokensJson): FoundationTokens {
        val spacingJson = foundation.spacing
        val spacing = SpacingScale(
            none = spacingJson.floatOf("0", 0f),
            xs2 = spacingJson.floatOf("2XS", 2f),
            xs = spacingJson.floatOf("XS", 4f),
            s = spacingJson.floatOf("S", 8f),
            m = spacingJson.floatOf("M", 12f),
            l = spacingJson.floatOf("L", 16f),
            xl = spacingJson.floatOf("XL", 24f),
            xl2 = spacingJson.floatOf("2XL", 32f),
            xl3 = spacingJson.floatOf("3XL", 40f),
            xl4 = spacingJson.floatOf("4XL", 48f),
            xl5 = spacingJson.floatOf("5XL", 56f),
            xl6 = spacingJson.floatOf("6XL", 64f),
            xl7 = spacingJson.floatOf("7XL", 72f),
            xl8 = spacingJson.floatOf("8XL", 80f),
            xl9 = spacingJson.floatOf("9XL", 88f),
            xl10 = spacingJson.floatOf("10XL", 94f),
            xl11 = spacingJson.floatOf("11XL", 102f),
            xl12 = spacingJson.floatOf("12XL", 110f),
        )

        val borderRadiusJson = foundation.borderRadius
        val borderRadius = BorderRadiusScale(
            none = borderRadiusJson.floatOf("0", 0f),
            xs = borderRadiusJson.floatOf("XS", 4f),
            s = borderRadiusJson.floatOf("S", 8f),
            m = borderRadiusJson.floatOf("M", 12f),
            l = borderRadiusJson.floatOf("L", 16f),
            circle = borderRadiusJson.floatOf("Circle", 50f),
            pill = borderRadiusJson.floatOf("Pill", 999f),
        )

        val borderWidthJson = foundation.borderWidth
        val borderWidth = BorderWidthScale(
            none = borderWidthJson.floatOf("0", 0f),
            xs = borderWidthJson.floatOf("XS", 0.5f),
            s = borderWidthJson.floatOf("S", 1f),
            m = borderWidthJson.floatOf("M", 1.5f),
            l = borderWidthJson.floatOf("L", 2f),
            xl = borderWidthJson.floatOf("XL", 4f),
            inputBorderWidth = borderWidthJson.floatOf("InputBorderWidth", borderWidthJson.floatOf("S", 1f)),
            ctaBorderWidth = borderWidthJson.floatOf("CTABorderWidth", borderWidthJson.floatOf("S", 1f)),
        )

        return FoundationTokens(
            spacing = spacing,
            borderRadius = borderRadius,
            borderWidth = borderWidth,
        )
    }

    private fun buildCustomizationTokens(customizable: CustomizableTokensJson): CustomizationTokens {
        val paddingJson = customizable.padding
        val padding = PaddingTokens(
            inputPadding = paddingJson.floatOf("inputPadding", 12f),
            ctaPadding = paddingJson.floatOf("CTAPadding", 18f),
            separatorPadding = paddingJson.floatOf("SeparatorPadding", 20f),
            verticalPadding = paddingJson.floatOf("VerticalPadding", 12f),
            floatingSpace = paddingJson.floatOf("FloatingSpace", 12f),
            cardPaddingTop = paddingJson.floatOf("CardPaddingTop", 35f),
            cardPaddingBottom = paddingJson.floatOf("CardPaddingBottom", 35f),
            cardPadding = paddingJson.floatOf("CardPadding", 12f),
            componentPadding = paddingJson.floatOf("ComponentPadding", 16f),
        )

        val radiusJson = customizable.radius
        val radius = RadiusTokens(
            bottomSheetCornerRadius = radiusJson.floatOf("BottomSheetCornerRadius", 4f),
            inputCornerRadius = radiusJson.floatOf("InputCornerRadius", 4f),
            ctaCornerRadius = radiusJson.floatOf("CTACornerRadius", 4f),
            floatingCardCornerRadius = radiusJson.floatOf("FloatingCardCornerRadius", 4f),
        )

        return CustomizationTokens(
            padding = padding,
            radius = radius,
        )
    }

    private fun validateSchemaVersions(customizableSchemaVersion: String, foundationSchemaVersion: String) {
        require(customizableSchemaVersion.isNotBlank()) { "customizable.schemaVersion is required." }
        require(foundationSchemaVersion.isNotBlank()) { "foundation.schemaVersion is required." }
        require(customizableSchemaVersion == foundationSchemaVersion) {
            "Schema version mismatch. customizable=$customizableSchemaVersion foundation=$foundationSchemaVersion"
        }
    }

    private fun buildColorTokens(light: Map<String, String>, dark: Map<String, String>): ColorTokens {
        fun token(key: String, defaultHex: String): ModeAwareColorToken = ModeAwareColorToken(
            light = SdkColor.fromHex(light[key] ?: defaultHex),
            dark = SdkColor.fromHex(dark[key] ?: defaultHex),
        )

        return ColorTokens(
            content = ContentColorTokens(
                primary = token("content/Primary", "#000000"),
                secondary = token("content/Secondary", "#999999"),
                tertiary = token("content/Tertiary", "#CCCCCC"),
                disabled = token("content/Disabled", "#CFD5DC"),
                inverse = token("content/Inverse", "#FFFFFF"),
                negative = token("content/Negative", "#FF3B30"),
                link = token("content/Link", "#0A84FF"),
            ),
            background = BackgroundColorTokens(
                primary = token("background/Primary", "#FFFFFF"),
                inverse = token("background/Inverse", "#000000"),
                neutral = token("background/Neutral", "#CFD5DC"),
            ),
            border = BorderColorTokens(
                primary = token("border/Primary", "#CCCCCC"),
                disabled = token("border/Disabled", "#CFD5DC"),
                negative = token("border/Negative", "#FF3B30"),
                selected = token("border/Selected", "#000000"),
                inverse = token("border/Inverse", "#FFFFFF"),
            ),
            button = ButtonColorTokens(
                primary = token("button/Primary", "#000000"),
                disabled = token("button/Disabled", "#CFD5DC"),
                inverse = token("button/Inverse", "#FFFFFF"),
            ),
            icon = IconColorTokens(
                primary = token("icon/Primary", "#000000"),
                disabled = token("icon/Disabled", "#CFD5DC"),
                inverse = token("icon/Inverse", "#FFFFFF"),
                link = token("icon/Link", "#0A84FF"),
            ),
            selection = SelectionColorTokens(
                primary = token("selection/Primary", "#000000"),
                secondary = token("selection/Secondary", "#FFFFFF"),
                disabled = token("selection/Disabled", "#CFD5DC"),
            ),
        )
    }

    /** Flattens `{ category: { key: hex } }` into `{ "category/key": hex }`. */
    private fun flattenColorGroups(groups: Map<String, Map<String, String>>): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        for ((category, entries) in groups) {
            for ((key, hex) in entries) {
                result["$category/$key"] = hex
            }
        }
        return result
    }

    private fun buildSemanticTypography(typography: TypographyJson): SemanticTypographyTokens {
        val englishJson = typography.english ?: typography.latin
            ?: error("Missing typography.english (or typography.latin) in customizable tokens JSON.")
        val arabicJson = typography.arabic
            ?: error("Missing typography.arabic in customizable tokens JSON.")

        return SemanticTypographyTokens(
            english = englishJson.toSemanticLocaleTokens("english"),
            arabic = arabicJson.toSemanticLocaleTokens("arabic"),
        )
    }

    private fun LocaleTypographyJson.toSemanticLocaleTokens(localeName: String): SemanticLocaleTypographyTokens {
        return SemanticLocaleTypographyTokens(
            title = title.toSemanticFontTokens(localeName, "title"),
            primary = primary.toSemanticFontTokens(localeName, "primary"),
            secondary = secondary.toSemanticFontTokens(localeName, "secondary"),
            tertiary = tertiary.toSemanticFontTokens(localeName, "tertiary"),
        )
    }

    private fun SemanticFontJson.toSemanticFontTokens(localeName: String, categoryName: String): SemanticFontTokens {
        val resolvedFamily = family?.trim().orEmpty()
        require(resolvedFamily.isNotBlank()) {
            "Missing typography.$localeName.$categoryName.family in customizable tokens JSON."
        }
        val resolvedSize = (fontSize ?: error("Missing typography.$localeName.$categoryName.fontSize in customizable tokens JSON.")).toFloat()
        val resolvedWeight = fontWeight ?: error("Missing typography.$localeName.$categoryName.fontWeight in customizable tokens JSON.")
        val resolvedLineHeight = (lineHeight ?: error("Missing typography.$localeName.$categoryName.lineHeight in customizable tokens JSON.")).toFloat()
        return SemanticFontTokens(
            family = resolvedFamily,
            fontSize = resolvedSize,
            fontWeight = resolvedWeight,
            lineHeight = resolvedLineHeight,
            category = categoryName,
        )
    }
}
