package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Parses a merchant-supplied "entry" URL — the `postUrl` value returned by the
 * payment portal, e.g. `https://pay-qa.paygeex.com/en/default/index?info=...`
 * or `...?query=...` — into:
 *  - [Parsed.baseUrl]: the scheme + host (+ port, if any) only, used as the
 *    SDK's base URL for the portal-style `mobile/v1/order` APIs.
 *  - [Parsed.locale]: the first path segment (e.g. `"en"`/`"ar"`), required as
 *    a path prefix by the portal-style APIs (`{baseUrl}/{locale}/mobile/v1/order`).
 *    Defaults to `"en"` when the entry URL has no path segment to read it from.
 *  - [Parsed.info] / [Parsed.query]: the raw (still percent-encoded) value of
 *    the `info`/`query` query parameter, forwarded as-is in the
 *    order-configuration request body. These values must NOT be
 *    percent-decoded — the backend expects the exact encoded token.
 *
 * When either [Parsed.info] or [Parsed.query] is non-null, the caller should
 * switch to the portal-style config/addPaymentInfo flow, which requires no
 * `Authorization` header and no upfront order id.
 *
 * Public (not `internal`) so native host modules (e.g. `:androidApp`) can call
 * it directly instead of re-implementing the same parsing logic — iOS does
 * re-implement it locally in Swift (no Kotlin/Native interop needed there),
 * but Android's host layer is Kotlin too, so sharing this avoids divergence.
 */
object EntryUrlParser {
    private const val DEFAULT_LOCALE = "en"

    data class Parsed(
        val baseUrl: String,
        val locale: String,
        val info: String?,
        val query: String?
    )

    fun parse(entryUrl: String): Parsed {
        val trimmed = entryUrl.trim()
        val queryIndex = trimmed.indexOf('?')
        val withoutQuery = if (queryIndex >= 0) trimmed.substring(0, queryIndex) else trimmed
        val queryString = if (queryIndex >= 0) trimmed.substring(queryIndex + 1) else ""

        var info: String? = null
        var query: String? = null
        queryString.split("&").forEach { pair ->
            if (pair.isBlank()) return@forEach
            val eqIndex = pair.indexOf('=')
            val key = if (eqIndex >= 0) pair.substring(0, eqIndex) else pair
            val value = if (eqIndex >= 0) pair.substring(eqIndex + 1) else ""
            when (key) {
                "info" -> info = value
                "query" -> query = value
            }
        }

        return Parsed(
            baseUrl = withoutQuery.schemeAndHostOnly(),
            locale = withoutQuery.firstPathSegmentOrDefault(),
            info = info,
            query = query
        )
    }

    private fun String.schemeAndHostOnly(): String {
        val schemeSeparator = indexOf("://")
        if (schemeSeparator < 0) return trimEnd('/')
        val afterScheme = schemeSeparator + 3
        val pathIndex = indexOf('/', afterScheme)
        return if (pathIndex >= 0) substring(0, pathIndex) else this
    }

    private fun String.firstPathSegmentOrDefault(): String {
        val schemeSeparator = indexOf("://")
        val afterHostSearchStart = if (schemeSeparator >= 0) schemeSeparator + 3 else 0
        val pathStart = indexOf('/', afterHostSearchStart)
        if (pathStart < 0) return DEFAULT_LOCALE
        val pathOnly = substring(pathStart + 1).trimStart('/')
        val segment = pathOnly.substringBefore('/')
        return segment.ifBlank { DEFAULT_LOCALE }
    }
}

