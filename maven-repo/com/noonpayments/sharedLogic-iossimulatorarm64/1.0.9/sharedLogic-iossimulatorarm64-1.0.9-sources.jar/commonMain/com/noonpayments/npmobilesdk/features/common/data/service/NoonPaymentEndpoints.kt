package com.noonpayments.npmobilesdk.features.common.data.service

import com.noonpayments.npmobilesdk.core.network.Endpoint
import com.noonpayments.npmobilesdk.core.network.HttpMethod
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject

/**
 * Noon payment endpoints aligned with docs/API_CALLS.md.
 */
internal object NoonPaymentEndpoints {

    /**
     * Portal-style order-configuration call. Always POSTs to
     * `{baseUrl}/{entryLocale}/mobile/v1/order` with the raw `info`/`query`
     * token extracted from the merchant-supplied portal entry URL (see
     * [PaymentApiConfig.entryInfo]/[PaymentApiConfig.entryQuery]) — no
     * `orderId` and no `Authorization` header are used.
     */
    data class GetOrderConfiguration(
        private val config: PaymentApiConfig
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "${config.entryLocale}/mobile/v1/order"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = noAuthHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("info", config.entryInfo.orEmpty())
            put("query", config.entryQuery.orEmpty())
        }
    }

    /**
     * Portal-style add-payment-info call for cards (new or saved). Always
     * POSTs to `{baseUrl}/{entryLocale}/mobile/v1/order/addPaymentInfo` with
     * `portalOrderReference` (returned by [GetOrderConfiguration]'s response)
     * identifying the order — no `orderId` and no `Authorization` header are used.
     */
    data class AddCardPaymentInfo(
        private val config: PaymentApiConfig,
        private val input: CardPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "${config.entryLocale}/mobile/v1/order/addPaymentInfo"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = noAuthHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("portalOrderReference", input.portalOrderReference.orEmpty())
            put("type", "Card")
            putJsonObject("data") {
                if (!input.tokenIdentifier.isNullOrBlank()) {
                    put("tokenIdentifier", input.tokenIdentifier)
                    if (!input.cvv.isNullOrBlank()) put("cvv", input.cvv)
                } else {
                    if (!input.nameOnCard.isNullOrBlank()) {
                        put("nameOnCard", input.nameOnCard)
                    }
                    put("numberEncrypted", input.numberEncrypted.orEmpty())
                    if (!input.cvv.isNullOrBlank()) put("cvv", input.cvv)
                    put("expiryMonth", input.expiryMonth.orEmpty())
                    put("expiryYear", input.expiryYear.orEmpty())
                }
            }
        }
    }

    data class TokenizeApplePay(
        private val config: PaymentApiConfig,
        private val input: ApplePayPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "${config.entryLocale}/mobile/v1/order/addPaymentInfo"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = noAuthHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("portalOrderReference", input.portalOrderReference.orEmpty())
            put("type", "ApplePay")
            putJsonObject("data") {
                put("paymentToken", input.paymentToken)
            }
        }
    }

    /**
     * Portal-style add-payment-info call for Google Pay. Unlike [TokenizeApplePay], the
     * backend validates the Google Wallet gateway token at the JSON path
     * `data.paymentMethodData.tokenizationData.token` (confirmed by a `422
     * ProcessingError` — `"Parameter $.paymentMethodData.tokenizationData.token is
     * missing."` — when that nested shape isn't sent), so [GooglePayPaymentInput.paymentToken]
     * (the raw gateway token string extracted from the wallet response) is re-wrapped here
     * rather than sent flat.
     */
    data class TokenizeGooglePay(
        private val config: PaymentApiConfig,
        private val input: GooglePayPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "${config.entryLocale}/mobile/v1/order/addPaymentInfo"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = noAuthHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("portalOrderReference", input.portalOrderReference.orEmpty())
            put("type", "GooglePay")
            putJsonObject("data") {
                putJsonObject("paymentMethodData") {
                    putJsonObject("tokenizationData") {
                        put("token", input.paymentToken)
                    }
                }
            }
        }
    }

    data class CancelPayment(
        private val config: PaymentApiConfig,
        private val input: CancelPaymentInput
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "${config.entryLocale}/mobile/v1/order/cancel"
        override val method: HttpMethod = HttpMethod.POST
        override val commonHeaders: Map<String, String> = noAuthHeaders(config)
        override val body: JsonElement = buildJsonObject {
            put("portalOrderReference", input.portalOrderReference.orEmpty())
            put("cancellationReason", input.reason)
        }
    }

    /**
     * Portal-style order-status check. Originally implemented as
     * `GET {baseUrl}/{entryLocale}/mobile/v1/order/{portalOrderReference}` (the reference as a
     * URL path segment). That was observed in QA to intermittently fail with the backend
     * returning an HTML page instead of JSON: the backend's own `portalOrderReference` values
     * are themselves percent-encoded (e.g. containing a literal `%2F`/`%3D` — which is itself a
     * valid, unambiguous path segment), but the reverse proxy/CDN in front of the hosted-checkout
     * host normalizes/rejects percent-encoded path separators before the request ever reaches the
     * origin API, causing it to fall back to serving the hosted checkout SPA's HTML instead of
     * routing to the JSON API handler. Sending the reference as a query parameter instead avoids
     * that path-segment normalization entirely (query strings aren't subject to the same
     * "collapse `%2F`" behavior), while still hitting the same `mobile/v1/order` resource used by
     * [GetOrderConfiguration].
     */
    data class FetchOrderStatus(
        private val config: PaymentApiConfig,
        private val portalOrderReference: String
    ) : Endpoint {
        override val baseUrl: String = sanitizeBaseUrl(config.baseUrl)
        override val path: String = "${config.entryLocale}/mobile/v1/order"
        override val method: HttpMethod = HttpMethod.GET
        override val commonHeaders: Map<String, String> = noAuthHeaders(config)
        override val query: Map<String, String?> = mapOf("portalOrderReference" to portalOrderReference)
    }
}

internal fun sanitizeBaseUrl(url: String): String {
    val trimmed = url.trim().trimEnd('/')
    return if (trimmed.endsWith("/order")) {
        trimmed.removeSuffix("/order")
    } else {
        trimmed
    }
}


/**
 * Headers for the portal-style `mobile/v1/order` APIs — no `Authorization`
 * header is sent; the `info`/`query` token in the request body is the only
 * credential the backend needs.
 *
 * `Accept: application/json` and `X-Requested-With: XMLHttpRequest` are
 * required here (unlike [commonHeaders]): this backend shares its host with
 * the hosted checkout page (the one `postUrl` points at), and without these
 * the server's router/reverse-proxy treats the request as a normal page
 * navigation and falls back to serving that page's HTML (200 OK) instead of
 * routing it to the JSON API handler.
 */
private fun noAuthHeaders(config: PaymentApiConfig): Map<String, String> = mapOf(
    "Content-Type" to "application/json",
    "Accept" to "application/json",
    "X-Requested-With" to "XMLHttpRequest",
    "User-Agent" to "ios-sdk/v${config.sdkVersion}"
)


