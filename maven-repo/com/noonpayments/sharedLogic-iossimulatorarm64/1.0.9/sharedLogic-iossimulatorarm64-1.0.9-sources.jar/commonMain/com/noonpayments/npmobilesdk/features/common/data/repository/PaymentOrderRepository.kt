package com.noonpayments.npmobilesdk.features.common.data.repository

import com.noonpayments.npmobilesdk.core.network.NetworkError
import com.noonpayments.npmobilesdk.core.network.NetworkResult
import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.data.service.NoonPaymentService
import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentFailure
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull

class PaymentOrderRepository(
    private val service: NoonPaymentService
) : IPaymentOrderRepository {

    private val logger: SdkLogger = SdkLogger.default()

    override suspend fun getOrderConfiguration(config: PaymentApiConfig): PaymentOperationResult<OrderConfiguration> {
        return when (val result = service.getOrderConfiguration(config)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "getOrderConfiguration success: ${result.data}", config.requestIdentifier)

                val payload = result.data
                if (payload.containsKey("portalOrderReference")) {
                    mapPortalOrderConfiguration(payload, config)
                } else {
                    mapLegacyOrderConfiguration(payload, config)
                }
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "getOrderConfiguration failure: ${result.error}", config.requestIdentifier)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    /**
     * Maps the portal-style `mobile/v1/order` response — fields live at the
     * top level (no `result`/`order` wrapper), and payment options are named
     * `paymentMethods` rather than `paymentOptions`.
     */
    private fun mapPortalOrderConfiguration(
        payload: JsonObject,
        config: PaymentApiConfig
    ): PaymentOperationResult<OrderConfiguration> {
        val portalOrderReference = payload["portalOrderReference"].asStringOrNull()
        val currency = payload["currency"].asStringOrNull()
        val paymentMethods = payload["paymentMethods"]
        val encryptionKey = extractEncryptionKeyFromPaymentOptions(paymentMethods.asArrayOrNull())
        // Merchant-facing order id — distinct from `portalOrderReference` (SDK-internal,
        // required by subsequent ADD_PAYMENT_INFO/order-status/CANCEL calls). Falls back
        // to `orderId`/`merchantOrderReference` in case the backend names it differently.
        val merchantOrderId = payload["id"].asStringOrNull()
            ?: payload["orderId"].asStringOrNull()
            ?: payload["merchantOrderReference"].asStringOrNull()
        // Controls whether the "Name on card" field is shown (and required) in the add-card sheet.
        val requiredCardHolderName = payload["requiredCardHolderName"].asBooleanOrNull() ?: false
        // `paymentMethods[Card].data.cvvRequired` (e.g. "True"/"False"); defaults to true when absent.
        val cvvRequired =  extractCvvRequiredFromPaymentOptions(paymentMethods.asArrayOrNull())
        // Top-level order total (e.g. 100.00), shown in the Pay CTA.
        val amount = payload["amount"].asStringOrNull()

        if (encryptionKey == null) {
            val optionTypes = paymentMethods.asArrayOrNull()
                ?.mapNotNull { it.asObjectOrNull()?.get("type").asStringOrNull() }
            logger.log(
                LogLevel.WARN,
                TAG,
                "encryptionKey not found in paymentMethods. Available option types: $optionTypes",
                config.requestIdentifier
            )
        } else {
            logger.log(
                LogLevel.INFO,
                TAG,
                "getOrderConfiguration (portal) succeeded: status=${payload["status"].asStringOrNull()}, " +
                    "portalOrderReference=$portalOrderReference, currency=$currency, encryptionKeyFound=true",
                config.requestIdentifier
            )
        }

        return PaymentOperationResult.Success(
            OrderConfiguration(
                resultCode = payload["status"].asStringOrNull(),
                order = null,
                paymentOptions = paymentMethods,
                paymentTokens = payload["paymentTokens"],
                orderCategory = null,
                currency = currency,
                orderChannel = null,
                encryptionKey = encryptionKey,
                portalOrderReference = portalOrderReference,
                id = merchantOrderId,
                cvvRequired = cvvRequired,
                requiredCardHolderName = requiredCardHolderName,
                amount = amount
            )
        )
    }

    private fun mapLegacyOrderConfiguration(
        payload: JsonObject,
        config: PaymentApiConfig
    ): PaymentOperationResult<OrderConfiguration> {
        val resultObject = payload["result"].asObjectOrNull()
        val orderObject = resultObject?.get("order").asObjectOrNull()

        // Extract order metadata - try multiple possible field names
        val orderCategory = orderObject?.get("category").asStringOrNull()
            ?: orderObject?.get("orderCategory").asStringOrNull()
            ?: orderObject?.get("type").asStringOrNull()

        val currency = orderObject?.get("currency").asStringOrNull()
            ?: orderObject?.get("amount").asObjectOrNull()?.get("currency").asStringOrNull()

        val orderChannel = orderObject?.get("channel").asStringOrNull()
            ?: orderObject?.get("orderChannel").asStringOrNull()

        // Merchant-facing order id — surfaced to the merchant as
        // `NPMobileSDKPaymentResponse.orderId`. Distinct from `portalOrderReference`
        // (which this legacy response shape doesn't have anyway).
        val merchantOrderId = orderObject?.get("id").asStringOrNull()

        // Extract encryption key from known payload path.
        val encryptionKey = extractEncryptionKeyFromPaymentOptions(
            resultObject?.get("paymentOptions").asArrayOrNull()
        )
        val cvvRequired = extractCvvRequiredFromPaymentOptions(
            resultObject?.get("paymentOptions").asArrayOrNull()
        )
        if (encryptionKey == null) {
            val optionTypes = resultObject
                ?.get("paymentOptions")
                .asArrayOrNull()
                ?.mapNotNull { it.asObjectOrNull()?.get("type").asStringOrNull() }
            logger.log(
                LogLevel.WARN,
                TAG,
                "encryptionKey not found in paymentOptions. Available option types: $optionTypes",
                config.requestIdentifier
            )
        } else {
            logger.log(
                LogLevel.INFO,
                TAG,
                "getOrderConfiguration succeeded: resultCode=${payload["resultCode"].asStringOrNull()}, " +
                    "orderCategory=$orderCategory, currency=$currency, orderChannel=$orderChannel, " +
                    "encryptionKeyFound=true",
                config.requestIdentifier
            )
        }

        return PaymentOperationResult.Success(
            OrderConfiguration(
                resultCode = payload["resultCode"].asStringOrNull(),
                order = orderObject,
                paymentOptions = resultObject?.get("paymentOptions"),
                paymentTokens = resultObject?.get("paymentTokens"),
                orderCategory = orderCategory,
                currency = currency,
                orderChannel = orderChannel,
                encryptionKey = encryptionKey,
                id = merchantOrderId,
                cvvRequired = cvvRequired
            )
        )
    }

    override suspend fun addCardPaymentInfo(
        config: PaymentApiConfig,
        input: CardPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        val correlationId = input.portalOrderReference ?: config.requestIdentifier
        return when (val result = service.addCardPaymentInfo(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "addCardPaymentInfo success: ${result.data}", correlationId)
                val mapped = result.data.toAddPaymentInfoResult()
                logger.log(
                    LogLevel.INFO,
                    TAG,
                    "addCardPaymentInfo succeeded: resultCode=${mapped.resultCode}, " +
                        "isAuthenticationRequired=${mapped.isAuthenticationRequired}, " +
                        "hasPostUrl=${mapped.postUrl != null}, resolvedOrderId=${mapped.orderId}",
                    correlationId
                )
                PaymentOperationResult.Success(mapped)
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "addCardPaymentInfo failure: ${result.error}", correlationId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun tokenizeApplePay(
        config: PaymentApiConfig,
        input: ApplePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        val correlationId = input.portalOrderReference ?: config.requestIdentifier
        return when (val result = service.tokenizeApplePay(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "tokenizeApplePay success: ${result.data}", correlationId)
                val mapped = result.data.toAddPaymentInfoResult()
                logger.log(
                    LogLevel.INFO,
                    TAG,
                    "tokenizeApplePay succeeded: resultCode=${mapped.resultCode}, " +
                        "hasPostUrl=${mapped.postUrl != null}, resolvedOrderId=${mapped.orderId}",
                    correlationId
                )
                PaymentOperationResult.Success(mapped)
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "tokenizeApplePay failure: ${result.error}", correlationId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun tokenizeGooglePay(
        config: PaymentApiConfig,
        input: GooglePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        val correlationId = input.portalOrderReference ?: config.requestIdentifier
        return when (val result = service.tokenizeGooglePay(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "tokenizeGooglePay success: ${result.data}", correlationId)
                val mapped = result.data.toAddPaymentInfoResult()
                logger.log(
                    LogLevel.INFO,
                    TAG,
                    "tokenizeGooglePay succeeded: resultCode=${mapped.resultCode}, " +
                        "hasPostUrl=${mapped.postUrl != null}, resolvedOrderId=${mapped.orderId}",
                    correlationId
                )
                PaymentOperationResult.Success(mapped)
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "tokenizeGooglePay failure: ${result.error}", correlationId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun cancelPayment(
        config: PaymentApiConfig,
        input: CancelPaymentInput
    ): PaymentOperationResult<Unit> {
        val correlationId = input.portalOrderReference ?: config.requestIdentifier
        return when (val result = service.cancelPayment(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "cancelPayment success: ${result.data}", correlationId)
                logger.log(LogLevel.INFO, TAG, "cancelPayment succeeded", correlationId)
                PaymentOperationResult.Success(Unit)
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "cancelPayment failure: ${result.error}", correlationId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun fetchOrderStatus(
        config: PaymentApiConfig,
        orderId: String
    ): PaymentOperationResult<OrderStatusResult> {
        return when (val result = service.fetchOrderStatus(config, orderId)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "fetchOrderStatus success: ${result.data}", orderId)

                val payload = result.data
                if (payload.containsKey("status") && !payload.containsKey("resultCode")) {
                    return PaymentOperationResult.Success(
                        OrderStatusResult(
                            resultCode = payload["status"].asStringOrNull(),
                            orderStatus = payload["orderStatus"].asStringOrNull() ?: payload["status"].asStringOrNull(),
                            transactionStatus = payload["transactionStatus"].asStringOrNull(),
                            paymentDetails = payload["paymentDetails"]
                        )
                    ).also { success ->
                        logger.log(
                            LogLevel.INFO,
                            TAG,
                            "fetchOrderStatus (portal) succeeded: resultCode=${success.value.resultCode}, " +
                                "orderStatus=${success.value.orderStatus}, transactionStatus=${success.value.transactionStatus}",
                            orderId
                        )
                    }
                }

                val resultObject = payload["result"].asObjectOrNull()
                val firstTransaction = resultObject
                    ?.get("transactions")
                    .asArrayOrNull()
                    ?.firstOrNull()
                    .asObjectOrNull()

                PaymentOperationResult.Success(
                    OrderStatusResult(
                        resultCode = payload["resultCode"].asStringOrNull(),
                        orderStatus = resultObject
                            ?.get("order")
                            .asObjectOrNull()
                            ?.get("status")
                            .asStringOrNull(),
                        transactionStatus = firstTransaction
                            ?.get("status")
                            .asStringOrNull(),
                        paymentDetails = resultObject?.get("paymentDetails")
                    )
                ).also { success ->
                    logger.log(
                        LogLevel.INFO,
                        TAG,
                        "fetchOrderStatus succeeded: resultCode=${success.value.resultCode}, " +
                            "orderStatus=${success.value.orderStatus}, transactionStatus=${success.value.transactionStatus}",
                        orderId
                    )
                }
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "fetchOrderStatus failure: ${result.error}", orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    private companion object {
        const val TAG = "PaymentOrderRepository"
    }
}

private fun JsonObject.toAddPaymentInfoResult(): AddPaymentInfoResult {
    // Portal-style `mobile/v1/order/addPaymentInfo` response: fields live at the
    // top level (`status`, `postUrl`, `isAuthenticationRequired`), with no
    // `resultCode`/`result` wrapper.
    if (this.containsKey("status") && !this.containsKey("resultCode")) {
        return AddPaymentInfoResult(
            resultCode = this["status"].asStringOrNull(),
            postUrl = this["postUrl"].asStringOrNull(),
            orderId = null,
            isAuthenticationRequired = (this["isAuthenticationRequired"] as? JsonPrimitive)?.booleanOrNull
        )
    }

    val resultObject = this["result"].asObjectOrNull()
    return AddPaymentInfoResult(
        resultCode = this["resultCode"].asStringOrNull(),
        postUrl = resultObject
            ?.get("checkoutData")
            .asObjectOrNull()
            ?.get("postUrl")
            .asStringOrNull(),
        orderId = resultObject
            ?.get("order")
            .asObjectOrNull()
            ?.get("id")
            .asStringOrNull()
    )
}

private fun NetworkError.toPaymentFailure(): PaymentFailure = when (this) {
    is NetworkError.Http -> PaymentFailure.Http(statusCode, body)
    is NetworkError.Serialization -> PaymentFailure.Serialization(message)
    is NetworkError.Transport -> PaymentFailure.Transport(throwable.message ?: "Transport error")
}

private fun JsonElement?.asObjectOrNull(): JsonObject? = this as? JsonObject

private fun JsonElement?.asArrayOrNull(): JsonArray? = this as? JsonArray

private fun JsonElement?.asStringOrNull(): String? = (this as? JsonPrimitive)?.contentOrNull

private fun extractEncryptionKeyFromPaymentOptions(paymentOptions: JsonArray?): String? {
    val options = paymentOptions?.mapNotNull { it.asObjectOrNull() } ?: return null

    // Prefer the explicit "Card" option (case-insensitive — backends have been observed
    // sending "Card", "CARD", etc.), but fall back to scanning every payment option for
    // the encryption key path in case the card option is tagged differently or omitted
    // (e.g. saved-card-only orders where the merchant doesn't expose a "new card" option).
    val cardPaymentOption = options.firstOrNull { it.isCardPaymentOption() }
    val candidates = if (cardPaymentOption != null) {
        listOf(cardPaymentOption) + (options - cardPaymentOption)
    } else {
        options
    }

    for (option in candidates) {
        val key = option.extractPemFormatedKey()
        if (key != null) return key
    }
    return null
}

private fun JsonObject.extractPemFormatedKey(): String? {
    return this["data"]
        .asObjectOrNull()
        ?.get("encryptionSettings")
        .asObjectOrNull()
        ?.get("key")
        .asObjectOrNull()
        ?.get("pemFormatedKey")
        .asStringOrNull()
}

private fun JsonObject.isCardPaymentOption(): Boolean {
    return this["type"].asStringOrNull()?.equals("Card", ignoreCase = true) == true
}

/**
 * Reads the `Card` payment option's `data.cvvRequired` flag (e.g.
 * `"cvvRequired": "True"` — observed as a string, not a JSON boolean, on some
 * backends — handled case-insensitively either way). Defaults to `true`
 * (CVV required, matching the SDK's pre-existing behavior) when there is no
 * `Card` payment option or the flag is missing/unparseable, so backends that
 * don't send this field keep showing/requiring CVV for saved cards.
 */
private fun extractCvvRequiredFromPaymentOptions(paymentOptions: JsonArray?): Boolean {
    val cardOption = paymentOptions
        ?.mapNotNull { it.asObjectOrNull() }
        ?.firstOrNull { it.isCardPaymentOption() }
        ?: return true

    val rawValue = cardOption["data"].asObjectOrNull()?.get("cvvRequired")
    return rawValue.asBooleanOrNull() ?: true
}

private fun JsonElement?.asBooleanOrNull(): Boolean? {
    val primitive = this as? JsonPrimitive ?: return null
    primitive.booleanOrNull?.let { return it }
    return when (primitive.contentOrNull?.lowercase()) {
        "true" -> true
        "false" -> false
        else -> null
    }
}

