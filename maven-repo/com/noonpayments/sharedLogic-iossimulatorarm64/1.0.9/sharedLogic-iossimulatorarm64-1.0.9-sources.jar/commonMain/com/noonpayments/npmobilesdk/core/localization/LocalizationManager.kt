package com.noonpayments.npmobilesdk.core.localization

/**
 * Shared localization entry point for shared and native UI code.
 */
object LocalizationManager {
    private val repository: ILocalizationRepository = LocalizationRepository()

    fun string(key: StringKey): String = repository.resolve(
        key = key,
        language = LocalizationRuntimeOverrides.currentLanguage,
    )

    fun string(key: StringKey, arguments: Map<String, String>): String {
        val template = string(key)
        val placeholder = Regex("\\{([a-zA-Z][a-zA-Z0-9_]*)\\}")
        val names = placeholder.findAll(template).map { it.groupValues[1] }.toSet()
        require(arguments.keys == names) {
            "Localization arguments for '${key.resourceKey}' must match $names."
        }
        return placeholder.replace(template) { match ->
            val value = arguments.getValue(match.groupValues[1])
            // Isolate interpolated values so dates keep their order inside Arabic text.
            if (LocalizationRuntimeOverrides.isRtl) "\u2068$value\u2069" else value
        }
    }
}
