package com.noonpayments.npmobilesdk.features.common.presentation

import com.noonpayments.npmobilesdk.features.common.domain.PaymentFailure
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/**
 * Structured error body returned by the portal API, e.g.
 * `{"type":"ProcessingError","code":"5106","message":"Field paymentData.data.cvv is not valid.",...}`.
 * `traceId` is intentionally not surfaced to the UI.
 */
data class PaymentApiError(
    val code: String?,
    val message: String?,
) {
    /**
     * Name of the card field the backend rejected (`cvv`, `expiryMonth`, `expiryYear`,
     * `numberEncrypted`, ...), parsed from `Field paymentData.data.<field> is not valid.`.
     */
    val invalidField: String?
        get() = message?.let { INVALID_FIELD_REGEX.find(it)?.groupValues?.getOrNull(1) }

    private companion object {
        val INVALID_FIELD_REGEX = Regex("""paymentData\.data\.(\w+) is not valid""")
    }
}

/** Parses the API error body of an HTTP failure; `null` when the body is not a JSON error. */
fun PaymentFailure.apiErrorOrNull(): PaymentApiError? {
    if (this !is PaymentFailure.Http) return null
    val obj = runCatching { Json.parseToJsonElement(body) as? JsonObject }.getOrNull() ?: return null
    val code = (obj["code"] as? JsonPrimitive)?.contentOrNull
    val message = (obj["message"] as? JsonPrimitive)?.contentOrNull
    if (code == null && message == null) return null
    return PaymentApiError(code = code, message = message)
}

fun PaymentFailure.toDisplayMessage(): String = when (this) {
    // Only the backend's user-facing `message` is shown. The raw body is never displayed
    // or logged, since it may contain other sensitive API response data.
    is PaymentFailure.Http -> apiErrorOrNull()?.message ?: "HTTP $statusCode"
    is PaymentFailure.Serialization -> message
    is PaymentFailure.Transport -> message
}

