package com.noonpayments.npmobilesdk.core.localization

/**
 * Shared localization keys.
 *
 * Start small and add entries as texts are migrated out of the views.
 */
enum class StringKey(val resourceKey: String) {
    PaymentMethodsTitle("payment_methods_title"),
    PaymentMethodsApplePay("payment_methods_apple_pay"),
    PaymentMethodsGooglePay("payment_methods_google_pay"),
    PaymentMethodsAddNewCard("payment_methods_add_new_card"),
    SavedCardViewMore("saved_card_view_more"),
    SavedCardExpiresOn("saved_card_expires_on"),
    SavedCardCvvPlaceholder("saved_card_cvv_placeholder"),
    SavedCardInvalidCvv("saved_card_invalid_cvv"),
    SavedCardsTitle("saved_cards_title"),
    SavedCardsLabel("saved_cards_label"),
    SavedCardChange("saved_card_change"),
    Close("close"),
    AddCardTitle("add_card_title"),
    NameOnCard("name_on_card"),
    NameOnCardRequired("name_on_card_required"),
    CardInformation("card_information"),
    CardNumber("card_number"),
    StoreCard("store_card"),
    InvalidCardNumber("invalid_card_number"),
    InvalidExpiry("invalid_expiry"),
    ShowCvv("show_cvv"),
    HideCvv("hide_cvv"),
    Submitting("submitting"),
    SomethingWentWrongTitle("something_went_wrong_title"),
    SomethingWentWrongMessage("something_went_wrong_message"),

    Pay("pay")
}
