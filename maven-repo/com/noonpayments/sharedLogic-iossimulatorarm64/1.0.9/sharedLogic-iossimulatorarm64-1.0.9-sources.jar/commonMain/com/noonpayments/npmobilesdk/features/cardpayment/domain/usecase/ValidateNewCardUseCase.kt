package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

import kotlin.time.Clock

data class NewCardValidation(
    val cardNumberInvalid: Boolean,
    val expiryInvalid: Boolean,
    val cvvInvalid: Boolean,
) {
    val isValid: Boolean get() = !cardNumberInvalid && !expiryInvalid && !cvvInvalid
}

/** CVV length for a brand: 4 digits for AMEX, 3 for everything else. */
fun cvvLengthFor(cardType: CardType?): Int = if (cardType == CardType.AMEX) 4 else 3

class ValidateNewCardUseCase {
    fun execute(
        number: String,
        expiry: String,
        cvv: String,
        cardType: CardType?,
        currentYear: Int = Clock.System.now().toString().take(4).toInt(),
        currentMonth: Int = Clock.System.now().toString().substring(5, 7).toInt(),
        /** `false` when the order configuration disables CVV: the CVV is neither required nor validated. */
        cvvRequired: Boolean = true,
    ): NewCardValidation {
        val digits = number.filter { it in '0'..'9' }
        val checksum = digits.reversed().mapIndexed { index, char ->
            val value = char.digitToInt() * if (index % 2 == 1) 2 else 1
            if (value > 9) value - 9 else value
        }.sum()
        val month = expiry.take(2).toIntOrNull()
        val year = expiry.takeIf { it.length == 5 && it[2] == '/' }
            ?.takeLast(2)?.toIntOrNull()?.plus(2000)
        return NewCardValidation(
            cardNumberInvalid = digits.length !in 12..19 || digits.all { it == '0' } ||
                number.any { it !in '0'..'9' && it != ' ' } || checksum % 10 != 0,
            expiryInvalid = month == null || month !in 1..12 || year == null ||
                year < currentYear || (year == currentYear && month < currentMonth),
            cvvInvalid = cvvRequired && (cvv.length != cvvLengthFor(cardType) ||
                cvv.any { it !in '0'..'9' }),
        )
    }
}
