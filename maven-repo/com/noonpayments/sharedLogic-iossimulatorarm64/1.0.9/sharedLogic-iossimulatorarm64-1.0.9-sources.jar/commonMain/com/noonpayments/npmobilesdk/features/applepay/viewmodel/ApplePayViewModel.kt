package com.noonpayments.npmobilesdk.features.applepay.viewmodel
import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.normalizeApplePayTokenForTransport
import com.noonpayments.npmobilesdk.features.applepay.domain.usecase.TokenizeApplePayUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ApplePayState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val postUrl: String? = null,
    val resolvedOrderId: String? = null,
    val errorMessage: String? = null,
)

class ApplePayViewModel(
    private val apiConfig: PaymentApiConfig,
    private val tokenizeApplePayUseCase: TokenizeApplePayUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(ApplePayState())
    val state: StateFlow<ApplePayState> = _state.asStateFlow()

    suspend fun submit(paymentToken: String) {
        val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
        if (portalOrderReference.isNullOrBlank()) {
            val message = "Portal order reference is not available yet. Load order configuration first."
            sessionStore.saveError(message)
            _state.value = _state.value.copy(isLoading = false, errorMessage = message)
            return
        }
        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (
            val result = tokenizeApplePayUseCase(
                apiConfig,
                ApplePayPaymentInput(
                    paymentToken = normalizeApplePayTokenForTransport(paymentToken),
                    portalOrderReference = portalOrderReference,
                )
            )
        ) {
            is PaymentOperationResult.Success -> {
                sessionStore.saveAddPaymentInfoResult(result.value)
                _state.value = ApplePayState(
                    isLoading = false,
                    resultCode = result.value.resultCode,
                    postUrl = result.value.postUrl,
                    resolvedOrderId = result.value.orderId,
                )
            }

            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, portalOrderReference)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                )
            }
        }
    }

    private companion object {
        const val SCREEN_NAME = "ApplePayViewModel"
    }
}



