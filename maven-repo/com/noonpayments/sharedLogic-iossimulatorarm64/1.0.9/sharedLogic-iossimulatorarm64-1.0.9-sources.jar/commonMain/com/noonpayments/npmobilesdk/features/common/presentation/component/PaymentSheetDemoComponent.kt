package com.noonpayments.npmobilesdk.features.common.presentation.component

import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.presentation.PaymentUseCasesFactory
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import com.noonpayments.npmobilesdk.features.applepay.viewmodel.ApplePayViewModel
import com.noonpayments.npmobilesdk.features.cancelpayment.viewmodel.CancelPaymentViewModel
import com.noonpayments.npmobilesdk.features.cardpayment.viewmodel.CardPaymentViewModel
import com.noonpayments.npmobilesdk.features.orderstatus.viewmodel.FetchOrderStatusViewModel
import com.noonpayments.npmobilesdk.features.googlepay.viewmodel.GooglePayViewModel
import com.noonpayments.npmobilesdk.features.orderconfiguration.viewmodel.OrderConfigurationViewModel
import com.noonpayments.npmobilesdk.PaymentMethods.ViewModels.PaymentMethodViewModel

class PaymentSheetDemoComponent internal constructor(
    val sessionStore: PaymentSheetSessionStore,
    val orderConfigurationViewModel: OrderConfigurationViewModel,
    val paymentMethodViewModel: PaymentMethodViewModel,
    val cardPaymentViewModel: CardPaymentViewModel,
    val applePayViewModel: ApplePayViewModel,
    val googlePayViewModel: GooglePayViewModel,
    val fetchOrderStatusViewModel: FetchOrderStatusViewModel,
    val cancelPaymentViewModel: CancelPaymentViewModel,
)

object PaymentSheetDemoComponentFactory {
    fun create(apiConfig: PaymentApiConfig): PaymentSheetDemoComponent {
        val useCases = PaymentUseCasesFactory.default().createDefault()
        val sessionStore = PaymentSheetSessionStore()

        return PaymentSheetDemoComponent(
            sessionStore = sessionStore,
            orderConfigurationViewModel = OrderConfigurationViewModel(
                apiConfig = apiConfig,
                getOrderConfigurationUseCase = useCases.getOrderConfiguration,
                sessionStore = sessionStore,
            ),
            paymentMethodViewModel = PaymentMethodViewModel(
                apiConfig = apiConfig,
                getOrderConfigurationUseCase = useCases.getOrderConfiguration,
                tokenizeApplePayUseCase = useCases.tokenizeApplePay,
                tokenizeGooglePayUseCase = useCases.tokenizeGooglePay,
                sessionStore = sessionStore,
            ),
            cardPaymentViewModel = CardPaymentViewModel(
                apiConfig = apiConfig,
                addCardPaymentInfoUseCase = useCases.addCardPaymentInfo,
                detectCardBrandUseCase = useCases.detectCardBrand,
                sessionStore = sessionStore,
            ),
            applePayViewModel = ApplePayViewModel(
                apiConfig = apiConfig,
                tokenizeApplePayUseCase = useCases.tokenizeApplePay,
                sessionStore = sessionStore,
            ),
            googlePayViewModel = GooglePayViewModel(
                apiConfig = apiConfig,
                tokenizeGooglePayUseCase = useCases.tokenizeGooglePay,
                sessionStore = sessionStore,
            ),
            fetchOrderStatusViewModel = FetchOrderStatusViewModel(
                apiConfig = apiConfig,
                fetchOrderStatusUseCase = useCases.fetchOrderStatus,
                sessionStore = sessionStore,
            ),
            cancelPaymentViewModel = CancelPaymentViewModel(
                apiConfig = apiConfig,
                cancelPaymentUseCase = useCases.cancelPayment,
                sessionStore = sessionStore,
            ),
        )
    }
}

