package com.noonpayments.npmobilesdk.features.cardpayment.domain.usecase

/**
 * Maps the backend `paymentTokens[].brand` string to a [CardType].
 *
 * Normalizes case and strips non-letter characters so variants such as
 * `DINERS_CLUB`, `Diners Club` and `MASTER CARD` resolve to the same type.
 * Returns `null` for unknown brands (e.g. `JAYWAN`); callers render a generic
 * card icon in that case.
 */
object CardBrandResolver {
    fun fromBackendBrand(brand: String?): CardType? {
        val key = brand?.uppercase()?.filter { it in 'A'..'Z' }.orEmpty()
        return when (key) {
            "VISA" -> CardType.VISA
            "MASTERCARD", "MASTER" -> CardType.MASTERCARD
            "AMEX", "AMERICANEXPRESS" -> CardType.AMEX
            "MADA" -> CardType.MADA
            "JCB" -> CardType.JCB
            "UNIONPAY" -> CardType.UNIONPAY
            "DINERSCLUB", "DINERS" -> CardType.DINERSCLUB
            "DISCOVER" -> CardType.DISCOVER
            "MAESTRO" -> CardType.MAESTRO
            "MEEZA" -> CardType.MEEZA
            else -> null
        }
    }
}

