package com.noonpayments.npmobilesdk.PaymentMethods.ViewModels

import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.applepay.domain.usecase.TokenizeApplePayUseCase
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.applePayConfigurationOrNull
import com.noonpayments.npmobilesdk.features.common.domain.googlePayConfigurationOrNull
import com.noonpayments.npmobilesdk.features.common.domain.normalizeApplePayTokenForTransport
import com.noonpayments.npmobilesdk.features.common.domain.normalizeGooglePayTokenForTransport
import com.noonpayments.npmobilesdk.features.common.domain.payAmountTextOrNull
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage
import com.noonpayments.npmobilesdk.features.googlepay.domain.usecase.TokenizeGooglePayUseCase
import com.noonpayments.npmobilesdk.features.orderconfiguration.domain.usecase.GetOrderConfigurationUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Phase of the initial `PaymentApiConfig` (order configuration) request, exposed to native
 * UI so it can decide whether to render a skeleton, an error card, or the payment methods.
 */
enum class PaymentMethodLoadPhase {
    LOADING,
    SUCCEEDED,
    FAILED,
}

data class PaymentMethodState(
    val phase: PaymentMethodLoadPhase = PaymentMethodLoadPhase.LOADING,
    val resultCode: String? = null,
    val paymentOptionsJson: String? = null,
    val paymentTokensJson: String? = null,
    val errorMessage: String? = null,
    /**
     * Mirrors [OrderConfiguration.cvvRequired] (the `Card` payment option's
     * `data.cvvRequired` flag). Defaults to `true` so saved-card rows and the
     * Pay button require a CVV unless the loaded order configuration says
     * otherwise.
     */
    val cvvRequired: Boolean = true,
    /** Order total formatted for the Pay CTA (e.g. `AED 25.00`); `null` when unavailable. */
    val payAmountText: String? = null,
    // Apple Pay native configuration derived from `paymentOptions` (null when ApplePay
    // isn't offered by the backend for this order). Native UI reads this directly to
    // build a `PKPaymentRequest` — no parsing/validation needed on the native side.
    val applePayConfig: ApplePayConfiguration? = null,
    // Apple Pay tokenize/submit (ADD_PAYMENT_INFO) result, populated by [submitApplePay]
    // or [reportApplePayFailure] (used by native UI for device/user-level failures that
    // never reach the network, e.g. "Apple Pay unavailable on this device").
    val applePayIsSubmitting: Boolean = false,
    val applePayResultCode: String? = null,
    val applePayPostUrl: String? = null,
    val applePayResolvedOrderId: String? = null,
    val applePayErrorMessage: String? = null,
    // Google Pay native configuration derived from `paymentOptions` (null when GooglePay
    // isn't offered by the backend for this order). Native UI reads this directly to
    // build the `IsReadyToPayRequest` / `PaymentDataRequest` — no parsing/validation
    // needed on the native side.
    val googlePayConfig: GooglePayConfiguration? = null,
    // Google Pay tokenize/submit (ADD_PAYMENT_INFO) result, populated by [submitGooglePay]
    // or [reportGooglePayFailure] (used by native UI for device/user-level failures that
    // never reach the network, e.g. "Google Pay was cancelled").
    val googlePayIsSubmitting: Boolean = false,
    val googlePayResultCode: String? = null,
    val googlePayPostUrl: String? = null,
    val googlePayResolvedOrderId: String? = null,
    val googlePayErrorMessage: String? = null,
)

/**
 * ViewModel backing the PaymentMethod view. Owns the "load order configuration" call so
 * native UI (Compose / SwiftUI) does not have to invoke another ViewModel's `load()` directly.
 * Also owns Apple Pay and Google Pay tokenization (`ADD_PAYMENT_INFO`) so the screen can handle
 * every payment method (saved cards, Apple Pay, Google Pay, add new card) from a single ViewModel.
 *
 * Native UI only "launches and listens": it reads [PaymentMethodState.applePayConfig] /
 * [PaymentMethodState.googlePayConfig] to build the platform request (no validation, no
 * defaulting, no JSON/CSV parsing on the native side), presents the platform wallet sheet, then
 * forwards the raw token/paymentMethodData to [submitApplePay] / [submitGooglePay] and the
 * platform-level failures (unavailable device, user cancellation, resolution errors, ...) to
 * [reportApplePayFailure] / [reportGooglePayFailure]. All resulting state (submitting / result /
 * postUrl / resolvedOrderId / errorMessage) is observed via [state].
 *
 * The resulting [OrderConfiguration] is persisted in [PaymentSheetSessionStore] so other
 * screen-scoped ViewModels (ApplePay, GooglePay, CardPayment, ...) can read it via the shared session.
 */
class PaymentMethodViewModel(
    private val apiConfig: PaymentApiConfig,
    private val getOrderConfigurationUseCase: GetOrderConfigurationUseCase,
    private val tokenizeApplePayUseCase: TokenizeApplePayUseCase,
    private val tokenizeGooglePayUseCase: TokenizeGooglePayUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(PaymentMethodState())
    val state: StateFlow<PaymentMethodState> = _state.asStateFlow()

    suspend fun load() {
        if (!apiConfig.isBaseUrlValid) {
            val message = "Invalid payment request: missing or malformed checkout URL " +
                "(NPMobileSDKPaymentRequest.postUrl/url). Load order configuration skipped " +
                "to avoid an unsafe network request."
            SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, apiConfig.requestIdentifier)
            sessionStore.saveError(message)
            _state.value = _state.value.copy(
                phase = PaymentMethodLoadPhase.FAILED,
                errorMessage = message,
            )
            return
        }

        _state.value = _state.value.copy(
            phase = PaymentMethodLoadPhase.LOADING,
            errorMessage = null,
        )

        when (val result = getOrderConfigurationUseCase(apiConfig)) {
            is PaymentOperationResult.Success -> onSuccess(result.value)
            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, apiConfig.requestIdentifier)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    phase = PaymentMethodLoadPhase.FAILED,
                    errorMessage = message,
                )
            }
        }
    }

    /**
     * Submits the raw Apple Pay PassKit token (`payment.token.paymentData`, read as a UTF-8
     * string by native UI) as `ADD_PAYMENT_INFO`. On success, [PaymentMethodState.applePayPostUrl]
     * is non-null when 3DS is required; otherwise [PaymentMethodState.applePayResolvedOrderId]
     * can be used to finalize the order immediately.
     */
    suspend fun submitApplePay(paymentToken: String) {
        val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
        if (portalOrderReference.isNullOrBlank()) {
            reportApplePayFailure("Portal order reference is not available yet. Load order configuration first.")
            return
        }
        _state.value = _state.value.copy(applePayIsSubmitting = true, applePayErrorMessage = null)

        when (
            val result = tokenizeApplePayUseCase(
                apiConfig,
                ApplePayPaymentInput(
                    paymentToken = normalizeApplePayTokenForTransport(paymentToken),
                    portalOrderReference = portalOrderReference,
                )
            )
        ) {
            is PaymentOperationResult.Success -> {
                sessionStore.saveAddPaymentInfoResult(result.value)
                _state.value = _state.value.copy(
                    applePayIsSubmitting = false,
                    applePayResultCode = result.value.resultCode,
                    applePayPostUrl = result.value.postUrl,
                    applePayResolvedOrderId = result.value.orderId,
                )
            }

            is PaymentOperationResult.Failure -> {
                reportApplePayFailure(result.failure.toDisplayMessage())
            }
        }
    }

    /**
     * Submits the raw Google Pay wallet gateway token (extracted by native UI from the
     * wallet's `PaymentData` response, i.e. `paymentMethodData.tokenizationData.token`) as
     * `ADD_PAYMENT_INFO`. On success, [PaymentMethodState.googlePayPostUrl] is non-null when
     * 3DS is required; otherwise [PaymentMethodState.googlePayResolvedOrderId] can be used to
     * finalize the order immediately.
     */
    suspend fun submitGooglePay(paymentToken: String) {
        if (paymentToken.isBlank()) {
            reportGooglePayFailure("Google Pay payment token is required")
            return
        }

        val portalOrderReference = sessionStore.state.value.orderConfiguration?.portalOrderReference
        if (portalOrderReference.isNullOrBlank()) {
            reportGooglePayFailure("Portal order reference is not available yet. Load order configuration first.")
            return
        }

        _state.value = _state.value.copy(googlePayIsSubmitting = true, googlePayErrorMessage = null)

        when (
            val result = tokenizeGooglePayUseCase(
                apiConfig,
                GooglePayPaymentInput(
                    paymentToken = normalizeGooglePayTokenForTransport(paymentToken),
                    portalOrderReference = portalOrderReference,
                )
            )
        ) {
            is PaymentOperationResult.Success -> {
                if (result.value.isAuthenticationWithoutUrl) {
                    reportGooglePayFailure("Authentication is required but no 3DS URL was returned. Please try again.")
                    return
                }
                sessionStore.saveAddPaymentInfoResult(result.value)
                _state.value = _state.value.copy(
                    googlePayIsSubmitting = false,
                    googlePayResultCode = result.value.resultCode,
                    // Opened only when the backend says authentication is required.
                    googlePayPostUrl = result.value.postUrl.takeIf { result.value.requiresThreeDs },
                    googlePayResolvedOrderId = result.value.orderId,
                )
            }

            is PaymentOperationResult.Failure -> {
                reportGooglePayFailure(result.failure.toDisplayMessage())
            }
        }
    }

    /**
     * Records a platform-level Apple Pay failure that never reaches the network (device can't
     * make payments, user cancelled, PassKit sheet failed to present, token unreadable, ...).
     * Native UI should call this instead of rendering its own ad-hoc error strings, so every
     * Apple Pay failure — network or platform — flows through [PaymentMethodState.applePayErrorMessage].
     */
    fun reportApplePayFailure(message: String) {
        SdkLogger.default().log(
            LogLevel.ERROR,
            SCREEN_NAME,
            message,
            sessionStore.state.value.orderConfiguration?.portalOrderReference ?: apiConfig.requestIdentifier,
        )
        sessionStore.saveError(message)
        _state.value = _state.value.copy(
            applePayIsSubmitting = false,
            applePayErrorMessage = message,
        )
    }

    /**
     * Records a platform-level Google Pay failure that never reaches the network (wallet not
     * ready, user cancelled, resolution failed, paymentMethodData missing from the wallet
     * response, ...). See [reportApplePayFailure].
     */
    fun reportGooglePayFailure(message: String) {
        SdkLogger.default().log(
            LogLevel.ERROR,
            SCREEN_NAME,
            message,
            sessionStore.state.value.orderConfiguration?.portalOrderReference ?: apiConfig.requestIdentifier,
        )
        sessionStore.saveError(message)
        _state.value = _state.value.copy(
            googlePayIsSubmitting = false,
            googlePayErrorMessage = message,
        )
    }

    /** Clears a previously reported Apple Pay error, e.g. right before re-presenting the sheet. */
    fun clearApplePayError() {
        _state.value = _state.value.copy(applePayErrorMessage = null)
    }

    /** Clears a previously reported Google Pay error, e.g. right before re-launching the flow. */
    fun clearGooglePayError() {
        _state.value = _state.value.copy(googlePayErrorMessage = null)
    }

    private fun onSuccess(value: OrderConfiguration) {
        sessionStore.saveOrderConfiguration(value)
        _state.value = PaymentMethodState(
            phase = PaymentMethodLoadPhase.SUCCEEDED,
            resultCode = value.resultCode,
            paymentOptionsJson = value.paymentOptions?.toString(),
            paymentTokensJson = value.paymentTokens?.toString(),
            cvvRequired =  value.cvvRequired,
            payAmountText = value.payAmountTextOrNull(),
            applePayConfig = value.applePayConfigurationOrNull(),
            googlePayConfig = value.googlePayConfigurationOrNull(),
        )
    }

    private companion object {
        const val SCREEN_NAME = "PaymentMethodViewModel"
    }
}





