package com.noonpayments.npmobilesdk.features.orderconfiguration.viewmodel
import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.applePayConfigurationOrNull
import com.noonpayments.npmobilesdk.features.orderconfiguration.domain.usecase.GetOrderConfigurationUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class OrderConfigurationState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val orderJson: String? = null,
    val paymentOptionsJson: String? = null,
    val applePayMerchantIdentifier: String? = null,
    val applePayCountryCode: String? = null,
    val applePayCurrencyCode: String? = null,
    val applePaySummaryLabel: String? = null,
    val applePaySummaryAmount: String? = null,
    val applePaySupportedNetworksCsv: String? = null,
    val errorMessage: String? = null,
)

class OrderConfigurationViewModel(
    private val apiConfig: PaymentApiConfig,
    private val getOrderConfigurationUseCase: GetOrderConfigurationUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(OrderConfigurationState())
    val state: StateFlow<OrderConfigurationState> = _state.asStateFlow()

    suspend fun load() {
        if (!apiConfig.isBaseUrlValid) {
            val message = "Invalid payment request: missing or malformed checkout URL " +
                "(NPMobileSDKPaymentRequest.postUrl/url). Load order configuration skipped " +
                "to avoid an unsafe network request."
            SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, apiConfig.requestIdentifier)
            sessionStore.saveError(message)
            _state.value = _state.value.copy(isLoading = false, errorMessage = message)
            return
        }

        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (val result = getOrderConfigurationUseCase(apiConfig)) {
            is PaymentOperationResult.Success -> onSuccess(result.value)
            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, apiConfig.requestIdentifier)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                )
            }
        }
    }

    private fun onSuccess(value: OrderConfiguration) {
        sessionStore.saveOrderConfiguration(value)
        val applePayConfig = value.applePayConfigurationOrNull()
        _state.value = OrderConfigurationState(
            isLoading = false,
            resultCode = value.resultCode,
            orderJson = value.order?.toString(),
            paymentOptionsJson = value.paymentOptions?.toString(),
            applePayMerchantIdentifier = applePayConfig?.merchantIdentifier,
            applePayCountryCode = applePayConfig?.countryCode,
            applePayCurrencyCode = applePayConfig?.currencyCode,
            applePaySummaryLabel = applePayConfig?.summaryLabel,
            applePaySummaryAmount = applePayConfig?.summaryAmount,
            applePaySupportedNetworksCsv = applePayConfig?.supportedNetworks?.joinToString(","),
        )
    }

    private companion object {
        const val SCREEN_NAME = "OrderConfigurationViewModel"
    }
}


