package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Service that provides design tokens from a remote/backend source.
 *
 * The caller supplies raw JSON strings (fetched from the backend).
 * This service parses them through [ThemeTokenParser] — the same parser
 * used for local tokens — which acts as validation. Malformed JSON or
 * schema/type mismatches still throw and the caller handles fallback;
 * missing individual color keys are tolerated because predefined
 * [ColorTokens] entries fall back to canonical defaults.
 */
class RemoteThemeTokenService {

    /**
     * Parses remote JSON into a [ThemeTokenCatalog].
     *
     * @throws Exception if the JSON is malformed, missing required top-level fields,
     *         or has schema version mismatch / invalid value types.
     *         The caller should catch and fall back to local.
     */
    fun getTokens(
        customizableJson: String,
        foundationJson: String,
    ): ThemeTokenCatalog {
        return ThemeTokenParser.parse(
            customizableJson = customizableJson,
            foundationJson = foundationJson,
            colorOverrides = ThemeTokenRuntimeOverrides.currentColorOverrides,
        )
    }
}
