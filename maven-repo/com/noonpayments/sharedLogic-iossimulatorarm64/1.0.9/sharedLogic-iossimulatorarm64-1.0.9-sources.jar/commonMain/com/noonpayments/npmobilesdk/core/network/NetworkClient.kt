package com.noonpayments.npmobilesdk.core.network

import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.LogSanitizer
import com.noonpayments.npmobilesdk.core.logging.SdkFailureDelegate
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json

@PublishedApi
internal const val TAG = "NetworkClient"

class NetworkClient(
    @PublishedApi internal val transport: NetworkTransport,
    @PublishedApi internal val json: Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    },
    @PublishedApi internal val logger: SdkLogger = SdkLogger.default(),
    @PublishedApi internal val failureDelegate: SdkFailureDelegate = SdkFailureDelegate.default()
) {
    /**
     * Executes [endpoint] and returns a typed [NetworkResult].
     *
     * @param orderId Optional order identifier attached to every log line for traceability.
     *                Pass the active payment request order id at every call site.
     *                Defaults to "unknown" when not yet resolved (e.g. pre-3DS step).
     */
    suspend inline fun <reified T> request(
        endpoint: Endpoint,
        orderId: String? = null
    ): NetworkResult<T> {
        val resolvedOrderId = orderId ?: "unknown"

        val request = NetworkRequest(
            url = endpoint.resolvedUrl(),
            method = endpoint.method,
            headers = endpoint.resolvedHeaders(),
            body = endpoint.body?.toString()
        )
        val operation = "${request.method.name} ${endpoint.path}"

        logger.log(
            level = LogLevel.DEBUG,
            tag = TAG,
            message = "→ ${request.method.name} ${request.url} | " +
                "headers=${LogSanitizer.sanitizeHeaders(request.headers)} | " +
                "body=${LogSanitizer.sanitizeBody(request.body)}",
            orderId = resolvedOrderId
        )

        val response = try {
            transport.execute(request)
        } catch (cancellation: CancellationException) {
            // Never swallow cancellation (e.g. the hosting Compose/SwiftUI composition was
            // torn down mid-request, such as `key(sdkInitVersion)` remounting the embedded
            // payment view) — catching it here as a generic `Throwable` would both break
            // structured concurrency (the coroutine wouldn't actually finish cancelling) and
            // misreport a normal lifecycle event as a scary "Transport error"/merchant-facing
            // FAILED result via `failureDelegate.onTransportFailure(...)`. Rethrowing lets the
            // caller's coroutine cancel normally with no log spam and no bogus failure.
            throw cancellation
        } catch (throwable: Throwable) {
            val throwableName = throwable::class.simpleName ?: "Throwable"
            logger.log(
                level = LogLevel.ERROR,
                tag = TAG,
                message = "✗ Transport error: $throwableName — ${throwable.message}",
                orderId = resolvedOrderId
            )
            failureDelegate.onTransportFailure(operation, throwableName, throwable.message, resolvedOrderId)
            return NetworkResult.Failure(NetworkError.Transport(throwable))
        }

        if (response.statusCode !in 200..299) {
            logger.log(
                level = LogLevel.WARN,
                tag = TAG,
                message = "← HTTP ${response.statusCode} (failure)",
                orderId = resolvedOrderId
            )
            failureDelegate.onHttpFailure(operation, response.statusCode, resolvedOrderId)
            return NetworkResult.Failure(
                NetworkError.Http(statusCode = response.statusCode, body = response.body)
            )
        }

        logger.log(
            level = LogLevel.DEBUG,
            tag = TAG,
            message = "← HTTP ${response.statusCode} OK",
            orderId = resolvedOrderId
        )

        if (T::class == Unit::class) {
            @Suppress("UNCHECKED_CAST")
            return NetworkResult.Success(Unit as T, response.statusCode, response.headers)
        }

        if (response.body.isBlank()) {
            val serializationMessage = "Response body is empty for expected type ${T::class.simpleName}"
            logger.log(
                level = LogLevel.ERROR,
                tag = TAG,
                message = "✗ Serialization failure: $serializationMessage",
                orderId = resolvedOrderId
            )
            failureDelegate.onSerializationFailure(operation, serializationMessage, resolvedOrderId)
            return NetworkResult.Failure(
                NetworkError.Serialization(serializationMessage)
            )
        }

        if (response.body.trimStart().startsWith("<")) {
            // The backend returned an HTML page (e.g. the hosted checkout page's own SPA
            // fallback) instead of a JSON API response — this is almost always a routing or
            // content-negotiation issue (missing `Accept: application/json`, wrong path, or
            // wrong host) rather than a malformed JSON payload. Surface a message that points
            // directly at that instead of a generic "Expected start of the object" parse error.
            // A short, sanitized snippet of the actual HTML is included so engineers can tell
            // apart e.g. a generic SPA index page, a WAF block page, or a load-balancer error
            // page without needing to reproduce the request manually — this is especially
            // useful when the request path contains percent-encoded reserved characters (like
            // `%2F`), which some reverse proxies/CDNs reject or mis-route before it ever
            // reaches the origin API.
            val bodySnippet = response.body.trim().take(200)
            val serializationMessage = "Backend returned an HTML page instead of JSON for " +
                "${endpoint.method.name} ${request.url} — check the request path/headers " +
                "(e.g. a missing `Accept: application/json` header can cause this). " +
                "Response snippet: $bodySnippet"
            logger.log(
                level = LogLevel.ERROR,
                tag = TAG,
                message = "✗ Serialization failure: $serializationMessage",
                orderId = resolvedOrderId
            )
            failureDelegate.onSerializationFailure(operation, serializationMessage, resolvedOrderId)
            return NetworkResult.Failure(
                NetworkError.Serialization(serializationMessage)
            )
        }

        return try {
            val parsed = json.decodeFromString<T>(response.body)
            NetworkResult.Success(parsed, response.statusCode, response.headers)
        } catch (exception: SerializationException) {
            val serializationMessage = "Unable to parse response as ${T::class.simpleName}"
            logger.log(
                level = LogLevel.ERROR,
                tag = TAG,
                message = "✗ Serialization failure: $serializationMessage",
                orderId = resolvedOrderId
            )
            failureDelegate.onSerializationFailure(operation, serializationMessage, resolvedOrderId)
            NetworkResult.Failure(NetworkError.Serialization(exception.message ?: serializationMessage))
        }
    }
}


