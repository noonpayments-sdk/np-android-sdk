package com.noonpayments.npmobilesdk.features.common.domain

/**
 * Shared API configuration used by all payment operations.
 */
data class PaymentApiConfig(
    val baseUrl: String,
    val sdkVersion: String,
    /**
     * Raw (still percent-encoded) `info` query-param value extracted from a
     * merchant-supplied portal entry URL (see [EntryUrlParser]). Non-null here
     * (together with/instead of [entryQuery]) switches the order-configuration
     * and add-payment-info calls to the portal-style `mobile/v1/order` APIs,
     * which require no `Authorization` header.
     */
    val entryInfo: String? = null,
    /**
     * Raw (still percent-encoded) `query` query-param value extracted from a
     * merchant-supplied portal entry URL (see [EntryUrlParser]). See [entryInfo].
     */
    val entryQuery: String? = null,
    /**
     * Locale path segment (e.g. `"en"`/`"ar"`) extracted from the merchant-supplied
     * portal entry URL — e.g. `https://pay-qa.paygeex.com/en/default/index?info=...`
     * yields `"en"`. Required as a path prefix by the portal-style APIs
     * (`{baseUrl}/{entryLocale}/mobile/v1/order`). Defaults to `"en"`.
     */
    val entryLocale: String = "en"
) {
    /**
     * Best-effort correlation token for logs/failure delegates when no backend
     * order id exists yet. Prefer the raw portal entry token because it's what
     * uniquely identifies the active portal session before later APIs switch to
     * `portalOrderReference` from order configuration.
     */
    val requestIdentifier: String
        get() = sequenceOf(entryInfo, entryQuery)
            .mapNotNull { it?.trim()?.takeIf(String::isNotEmpty) }
            .firstOrNull()
            ?: "unknown"

    /**
     * `false` when [baseUrl] isn't a usable `http(s)://host` (blank, or missing a scheme —
     * e.g. derived from an empty/malformed [com.noonpayments.npmobilesdk.features.common.domain.EntryUrlParser]
     * input). Callers (`OrderConfigurationViewModel.load()` / `PaymentMethodViewModel.load()`)
     * must check this *before* issuing any network request: an invalid base URL like `""` gets
     * silently resolved by Ktor's URL parser to `http://localhost/...`, which crashes with a
     * cryptic "CLEARTEXT communication to localhost not permitted by network security policy"
     * on Android instead of surfacing a clear validation error.
     */
    val isBaseUrlValid: Boolean
        get() = baseUrl.trim().let { it.startsWith("http://") || it.startsWith("https://") }
}
