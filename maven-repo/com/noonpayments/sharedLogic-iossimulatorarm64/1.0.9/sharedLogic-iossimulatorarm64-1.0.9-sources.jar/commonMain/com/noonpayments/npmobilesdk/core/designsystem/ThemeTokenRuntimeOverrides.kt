package com.noonpayments.npmobilesdk.core.designsystem

import com.noonpayments.npmobilesdk.core.localization.LocalizationRuntimeOverrides

/**
 * Runtime holder for merchant-provided color overrides passed at SDK initialization.
 *
 * This lets all ThemeTokenManager instances use the same override source while still
 * falling back to bundled token JSON for any missing key.
 */
object ThemeTokenRuntimeOverrides {
    private var colorOverrides: ThemeTokenColorOverrides = ThemeTokenColorOverrides()
    private var fontScaleFactor: Float = 1f
    private var paddingOverrides: Map<String, Float> = emptyMap()
    private var radiusOverrides: Map<String, Float> = emptyMap()
    private var themeMode: ThemeMode = ThemeMode.LIGHT

    fun setColorOverrides(
        light: Map<String, String> = emptyMap(),
        dark: Map<String, String> = emptyMap(),
    ) {
        colorOverrides = ThemeTokenColorOverrides(
            light = light.filterValues { it.isNotBlank() },
            dark = dark.filterValues { it.isNotBlank() },
        )
    }

    fun clearColorOverrides() {
        colorOverrides = ThemeTokenColorOverrides()
    }

    val currentColorOverrides: ThemeTokenColorOverrides
        get() = colorOverrides

    fun setPaddingOverrides(overrides: Map<String, Float> = emptyMap()) {
        paddingOverrides = overrides
            .filterKeys { it.isNotBlank() }
            .filterValues { it.isFinite() }
    }

    fun clearPaddingOverrides() {
        paddingOverrides = emptyMap()
    }

    fun currentPaddingOverride(tokenId: String): Float? = paddingOverrides[tokenId]

    /** Merchant-provided corner-radius overrides (e.g. "InputCornerRadius" → 8f). */
    fun setRadiusOverrides(overrides: Map<String, Float> = emptyMap()) {
        radiusOverrides = overrides
            .filterKeys { it.isNotBlank() }
            .filterValues { it.isFinite() }
    }

    fun clearRadiusOverrides() {
        radiusOverrides = emptyMap()
    }

    fun currentRadiusOverride(tokenId: String): Float? = radiusOverrides[tokenId]

    fun setFontScaleFactor(value: Float) {
        fontScaleFactor = if (value > 0f) value else 1f
    }

    val currentFontScaleFactor: Float
        get() = fontScaleFactor

    /** Sets the active language (e.g. "english"/"arabic") used to resolve [ThemeTokenManager.fonts]. */
    fun setLanguage(tokenId: String) {
        LocalizationRuntimeOverrides.setLanguageTokenId(tokenId)
    }

    val currentLanguageTokenId: String
        get() = LocalizationRuntimeOverrides.currentLanguageTokenId

    /** Merchant-selected resolved color mode (LIGHT/DARK), set once per composition
     * from `NPAppearance.colorMode` (with SYSTEM already resolved to LIGHT/DARK by
     * the caller). All [ThemeTokenManager] instances — regardless of their local
     * `initialMode` constructor default — resolve color tokens from
     * this single global source of truth, so every component (native UI widgets
     * each creating their own manager) stays in sync with the merchant's choice.
     */
    fun setThemeMode(mode: ThemeMode) {
        themeMode = mode
    }

    val currentThemeMode: ThemeMode
        get() = themeMode
}
