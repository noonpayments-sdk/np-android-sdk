package com.noonpayments.npmobilesdk.core.localization

/**
 * Convenience helper for Kotlin call sites.
 */
fun StringKey.localized(): String = LocalizationManager.string(this)

fun StringKey.localized(arguments: Map<String, String>): String = LocalizationManager.string(this, arguments)
