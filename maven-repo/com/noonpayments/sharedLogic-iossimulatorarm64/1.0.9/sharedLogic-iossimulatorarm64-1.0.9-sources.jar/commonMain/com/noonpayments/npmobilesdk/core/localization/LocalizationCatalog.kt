package com.noonpayments.npmobilesdk.core.localization

/**
 * Parsed localization map for a single language.
 */
data class LocalizationCatalog(
    val strings: Map<String, String> = emptyMap(),
)

