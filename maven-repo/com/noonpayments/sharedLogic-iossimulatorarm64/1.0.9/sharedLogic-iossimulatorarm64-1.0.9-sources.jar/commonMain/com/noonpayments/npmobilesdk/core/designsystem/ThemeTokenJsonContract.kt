package com.noonpayments.npmobilesdk.core.designsystem

import kotlinx.serialization.Serializable

/**
 * JSON contract for customizable tokens.
 *
 * Expected top-level fields:
 * - schemaVersion
 * - colors (light + dark, each grouped by semantic category: content/background/border/button/icon/selection)
 * - typography (fontFamily, fontSize, fontWeight, lineHeight) - optional, may be in foundation.tokens.json
 * - padding (customizable spacing-like values) - optional
 * - radius (customizable corner-radius values) - optional
 */
@Serializable
data class CustomizableTokensJson(
     val schemaVersion: String,
     val colors: ColorModesJson,
     val typography: TypographyJson = TypographyJson(),
     val padding: Map<String, Double> = emptyMap(),
     val radius: Map<String, Double> = emptyMap(),
)

/**
 * Colors are grouped by semantic category (e.g. "background", "border"), each mapping to
 * its own key → hex table (e.g. "Primary" → "#FFFFFF"). Flattened into "category/Key" token
 * ids by [ThemeTokenParser] so the rest of the pipeline (enum generation, overrides, lookups)
 * stays unchanged. This also powers nested native accessors like
 * `themeTokenManager.colors.background.primary`.
 */
@Serializable
data class ColorModesJson(
    val light: Map<String, Map<String, String>>,
    val dark: Map<String, Map<String, String>>,
)

@Serializable
data class TypographyJson(
    val fontFamily: Map<String, String> = emptyMap(),
    val fontSize: Map<String, Double> = emptyMap(),
    val fontWeight: Map<String, Int> = emptyMap(),
    val lineHeight: Map<String, Double> = emptyMap(),
    val english: LocaleTypographyJson? = null,
    val arabic: LocaleTypographyJson? = null,
    // Backward-compatible alias: if merchants send `latin`, treat it as english defaults.
    val latin: LocaleTypographyJson? = null,
)

@Serializable
data class LocaleTypographyJson(
    val title: SemanticFontJson = SemanticFontJson(),
    val primary: SemanticFontJson = SemanticFontJson(),
    val secondary: SemanticFontJson = SemanticFontJson(),
    val tertiary: SemanticFontJson = SemanticFontJson(),
)

@Serializable
data class SemanticFontJson(
    val family: String? = null,
    val fontSize: Double? = null,
    val fontWeight: Int? = null,
    val lineHeight: Double? = null,
)

/**
 * JSON contract for non-customizable/foundation tokens.
 *
 * Expected top-level fields:
 * - schemaVersion
 * - spacing
 * - borderRadius
 * - borderWidth
 * - typography (optional)
 */
@Serializable
data class FoundationTokensJson(
     val schemaVersion: String,
     val spacing: Map<String, Double> = emptyMap(),
     val borderRadius: Map<String, Double> = emptyMap(),
     val borderWidth: Map<String, Double> = emptyMap(),
     val typography: TypographyJson = TypographyJson(),
)
