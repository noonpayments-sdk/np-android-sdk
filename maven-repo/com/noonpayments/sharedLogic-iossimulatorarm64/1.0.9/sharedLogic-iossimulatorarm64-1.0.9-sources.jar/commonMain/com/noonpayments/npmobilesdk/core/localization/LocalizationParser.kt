package com.noonpayments.npmobilesdk.core.localization

import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

internal object LocalizationParser {
    private val json = Json {
        ignoreUnknownKeys = true
    }

    fun parse(jsonText: String): LocalizationCatalog {
        return LocalizationCatalog(
            strings = json.decodeFromString<Map<String, String>>(jsonText),
        )
    }
}


