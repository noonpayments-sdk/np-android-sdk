package com.noonpayments.npmobilesdk.core.localization

/**
 * Runtime holder for the SDK language selected at init time.
 *
 * Native entry points set this once from the merchant-provided appearance.
 * All shared localization lookups read from this single source of truth.
 */
object LocalizationRuntimeOverrides {
	private var language: SdkLanguage = SdkLanguage.ENGLISH

	fun setLanguage(language: SdkLanguage) {
		this.language = language
	}

	fun setLanguageTokenId(tokenId: String) {
		setLanguage(SdkLanguage.fromTokenId(tokenId))
	}

	val currentLanguage: SdkLanguage
		get() = language

	val currentLanguageTokenId: String
		get() = language.tokenId

	val isRtl: Boolean
		get() = language.isRtl
}
