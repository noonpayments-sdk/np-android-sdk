package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Canonical in-memory token catalog used by shared logic and native UI adapters.
 *
 * Token ids are intentionally kept as-is from Figma export so naming stays 1:1.
 */
data class ThemeTokenCatalog(
    val schemaVersion: String,
    val colors: ColorTokens,
    val typography: TypographyTokens,
    val semanticTypography: SemanticTypographyTokens = SemanticTypographyTokens(),
    val foundation: FoundationTokens,
    val customization: CustomizationTokens,
)

/**
 * Non-customizable, structural tokens sourced from `foundation.tokens.json`.
 *
 * Modeled as fixed, named properties (instead of `Map<String, Float>`) because this token
 * set is a stable design scale that is not expected to change shape. Typed properties are
 * discoverable at compile time and safe to refactor, unlike free-form dictionary keys.
 */
data class FoundationTokens(
    val spacing: SpacingScale,
    val borderRadius: BorderRadiusScale,
    val borderWidth: BorderWidthScale,
)

/** Maps to `foundation.tokens.json > spacing`. */
data class SpacingScale(
    val none: Float,
    val xs2: Float,
    val xs: Float,
    val s: Float,
    val m: Float,
    val l: Float,
    val xl: Float,
    val xl2: Float,
    val xl3: Float,
    val xl4: Float,
    val xl5: Float,
    val xl6: Float,
    val xl7: Float,
    val xl8: Float,
    val xl9: Float,
    val xl10: Float,
    val xl11: Float,
    val xl12: Float,
)

/** Maps to `foundation.tokens.json > borderRadius`. */
data class BorderRadiusScale(
    val none: Float,
    val xs: Float,
    val s: Float,
    val m: Float,
    val l: Float,
    val circle: Float,
    val pill: Float,
)

/** Maps to `foundation.tokens.json > borderWidth`. */
data class BorderWidthScale(
    val none: Float,
    val xs: Float,
    val s: Float,
    val m: Float,
    val l: Float,
    val xl: Float,
    val inputBorderWidth: Float = s,
    val ctaBorderWidth: Float = s,
)

/**
 * Customizable, component-level tokens sourced from `customizable.tokens.json`.
 *
 * Like [FoundationTokens], modeled as fixed named properties rather than dictionaries,
 * since these token ids are a stable, curated set of component-scoped values.
 */
data class CustomizationTokens(
    val padding: PaddingTokens,
    val radius: RadiusTokens,
)

/** Maps to `customizable.tokens.json > padding`. */
data class PaddingTokens(
    val inputPadding: Float,
    val ctaPadding: Float,
    val separatorPadding: Float,
    val verticalPadding: Float,
    val floatingSpace: Float,
    val cardPaddingTop: Float,
    val cardPaddingBottom: Float,
    val cardPadding: Float,
    val componentPadding: Float,
)

/** Maps to `customizable.tokens.json > radius`. */
data class RadiusTokens(
    val bottomSheetCornerRadius: Float,
    val inputCornerRadius: Float,
    val ctaCornerRadius: Float,
    val floatingCardCornerRadius: Float,
)

data class ModeAwareColorToken(
    val light: SdkColor,
    val dark: SdkColor,
)

/**
 * Customizable color tokens, grouped by semantic category — mirrors
 * `customizable.tokens.json > colors.<mode>` 1:1.
 *
 * Like [FoundationTokens]/[CustomizationTokens], modeled as fixed, named properties
 * rather than a `Map<String, ModeAwareColorToken>`, since this is the same kind of stable,
 * curated token set. Kotlin property names start lowercase (e.g. `primary`/`disabled`),
 * while JSON keys and merchant override ids retain their original casing (e.g.
 * `background/Primary`). Each category/key is mode-aware ([ModeAwareColorToken]); use
 * `ThemeTokenManager.resolve(...)` to pick the active light/dark [SdkColor].
 */
data class ColorTokens(
    val content: ContentColorTokens,
    val background: BackgroundColorTokens,
    val border: BorderColorTokens,
    val button: ButtonColorTokens,
    val icon: IconColorTokens,
    val selection: SelectionColorTokens,
)

/** Maps to `customizable.tokens.json > colors.<mode>.content`. */
data class ContentColorTokens(
    val primary: ModeAwareColorToken,
    val secondary: ModeAwareColorToken,
    val tertiary: ModeAwareColorToken,
    val disabled: ModeAwareColorToken,
    val inverse: ModeAwareColorToken,
    val negative: ModeAwareColorToken,
    val link: ModeAwareColorToken,
)

/** Maps to `customizable.tokens.json > colors.<mode>.background`. */
data class BackgroundColorTokens(
    val primary: ModeAwareColorToken,
    val inverse: ModeAwareColorToken,
    val neutral: ModeAwareColorToken,
)

/** Maps to `customizable.tokens.json > colors.<mode>.border`. */
data class BorderColorTokens(
    val primary: ModeAwareColorToken,
    val disabled: ModeAwareColorToken,
    val negative: ModeAwareColorToken,
    val selected: ModeAwareColorToken,
    val inverse: ModeAwareColorToken,
)

/** Maps to `customizable.tokens.json > colors.<mode>.button`. */
data class ButtonColorTokens(
    val primary: ModeAwareColorToken,
    val disabled: ModeAwareColorToken,
    val inverse: ModeAwareColorToken,
)

/** Maps to `customizable.tokens.json > colors.<mode>.icon`. */
data class IconColorTokens(
    val primary: ModeAwareColorToken,
    val disabled: ModeAwareColorToken,
    val inverse: ModeAwareColorToken,
    val link: ModeAwareColorToken,
)

/** Maps to `customizable.tokens.json > colors.<mode>.selection`. */
data class SelectionColorTokens(
    val primary: ModeAwareColorToken,
    val secondary: ModeAwareColorToken,
    val disabled: ModeAwareColorToken,
)

data class TypographyTokens(
    val fontFamily: Map<String, String>,
    val fontSize: Map<String, Float>,
    val fontWeight: Map<String, Int>,
    val lineHeight: Map<String, Float>,
)

data class SemanticTypographyTokens(
    val english: SemanticLocaleTypographyTokens = SemanticLocaleTypographyTokens(),
    val arabic: SemanticLocaleTypographyTokens = SemanticLocaleTypographyTokens(),
)

data class SemanticLocaleTypographyTokens(
    val title: SemanticFontTokens = SemanticFontTokens(),
    val primary: SemanticFontTokens = SemanticFontTokens(),
    val secondary: SemanticFontTokens = SemanticFontTokens(),
    val tertiary: SemanticFontTokens = SemanticFontTokens(),
)

data class SemanticFontTokens(
    val family: String = "",
    val fontSize: Float = 0f,
    val fontWeight: Int = 400,
    val lineHeight: Float = 0f,
    /** Semantic category id ("title"/"primary"/"secondary"/"tertiary"), used by native .toNative() adapters to look up appearance overrides. */
    val category: String = "",
)

/**
 * Optional merchant-provided color overrides keyed by token id.
 *
 * Example key: "background/Primary" (category/Key, matching the flattened
 * `customizable.tokens.json > colors.<mode>.<category>.<Key>` structure).
 * Any missing key falls back to bundled JSON values.
 */
data class ThemeTokenColorOverrides(
    val light: Map<String, String> = emptyMap(),
    val dark: Map<String, String> = emptyMap(),
)

/**
 * Platform-neutral color primitive.
 */
data class SdkColor(
    val red: Int,
    val green: Int,
    val blue: Int,
    val alpha: Int = 255,
) {
    init {
        require(red in 0..255) { "Invalid red channel: $red" }
        require(green in 0..255) { "Invalid green channel: $green" }
        require(blue in 0..255) { "Invalid blue channel: $blue" }
        require(alpha in 0..255) { "Invalid alpha channel: $alpha" }
    }

    fun toArgbInt(): Int = (alpha shl 24) or (red shl 16) or (green shl 8) or blue

    companion object {
        fun fromHex(rawHex: String): SdkColor {
            val normalized = rawHex.trim().removePrefix("#")
            return when (normalized.length) {
                6 -> {
                    val red = normalized.substring(0, 2).toInt(16)
                    val green = normalized.substring(2, 4).toInt(16)
                    val blue = normalized.substring(4, 6).toInt(16)
                    SdkColor(red = red, green = green, blue = blue, alpha = 255)
                }

                8 -> {
                    val alpha = normalized.substring(0, 2).toInt(16)
                    val red = normalized.substring(2, 4).toInt(16)
                    val green = normalized.substring(4, 6).toInt(16)
                    val blue = normalized.substring(6, 8).toInt(16)
                    SdkColor(red = red, green = green, blue = blue, alpha = alpha)
                }

                else -> error("Unsupported hex color: '$rawHex'. Expected #RRGGBB or #AARRGGBB")
            }
        }
    }
}
