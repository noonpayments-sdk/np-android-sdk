package com.noonpayments.npmobilesdk.core.designsystem

import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSBundle
import platform.Foundation.NSString
import platform.Foundation.NSUTF8StringEncoding
import platform.Foundation.stringWithContentsOfFile

@OptIn(ExperimentalForeignApi::class)
internal actual fun readResourceText(name: String): String {
    val fileName = name.substringBeforeLast(".")
    val fileExtension = name.substringAfterLast(".", "")

    // Look in all known bundles: SharedLogic framework bundle first, then main app bundle.
    val path = findResourcePath(fileName, fileExtension)
        ?: error("Resource not found: $name")
    return NSString.stringWithContentsOfFile(path, NSUTF8StringEncoding, null)
        ?: error("Failed to read resource: $name")
}

private fun findResourcePath(name: String, ext: String): String? {
    // 1. Try all loaded framework bundles (covers SharedLogic.framework)
    for (bundle in NSBundle.allFrameworks.filterIsInstance<NSBundle>()) {
        bundle.pathForResource(name, ext)?.let { return it }
    }
    // 2. Fall back to main app bundle
    return NSBundle.mainBundle.pathForResource(name, ext)
}



