package com.noonpayments.npmobilesdk.features.common.presentation.session

import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PaymentSheetSessionState(
    val orderConfiguration: OrderConfiguration? = null,
    val addPaymentInfoResult: AddPaymentInfoResult? = null,
    val orderStatusResult: OrderStatusResult? = null,
    val lastErrorMessage: String? = null,
)

class PaymentSheetSessionStore {
    private val _state = MutableStateFlow(PaymentSheetSessionState())
    val state: StateFlow<PaymentSheetSessionState> = _state.asStateFlow()

    fun saveOrderConfiguration(value: OrderConfiguration) {
        // Preserve encryption key and order metadata from a previous successful load
        // if the new response doesn't contain them (e.g., order already in 3DS state)
        val previous = _state.value.orderConfiguration
        val merged = if (previous != null) {
            value.copy(
                encryptionKey = value.encryptionKey ?: previous.encryptionKey,
                orderCategory = value.orderCategory ?: previous.orderCategory,
                currency = value.currency ?: previous.currency,
                orderChannel = value.orderChannel ?: previous.orderChannel,
                paymentTokens = value.paymentTokens ?: previous.paymentTokens
            )
        } else {
            value
        }
        _state.value = _state.value.copy(orderConfiguration = merged, lastErrorMessage = null)
    }

    fun saveAddPaymentInfoResult(value: AddPaymentInfoResult) {
        _state.value = _state.value.copy(addPaymentInfoResult = value, lastErrorMessage = null)
    }

    fun saveOrderStatusResult(value: OrderStatusResult) {
        _state.value = _state.value.copy(orderStatusResult = value, lastErrorMessage = null)
    }

    fun saveError(message: String) {
        _state.value = _state.value.copy(lastErrorMessage = message)
    }
}

