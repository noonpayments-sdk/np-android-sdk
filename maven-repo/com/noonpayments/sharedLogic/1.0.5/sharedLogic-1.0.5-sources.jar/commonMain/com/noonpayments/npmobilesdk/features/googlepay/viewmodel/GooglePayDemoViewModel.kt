package com.noonpayments.npmobilesdk.features.googlepay.viewmodel
import com.noonpayments.npmobilesdk.core.logging.reportSdkValidationFailure
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage

import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.normalizeGooglePayPaymentMethodDataForTransport
import com.noonpayments.npmobilesdk.features.googlepay.domain.usecase.TokenizeGooglePayUseCase
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class GooglePayDemoState(
    val isLoading: Boolean = false,
    val resultCode: String? = null,
    val postUrl: String? = null,
    val resolvedOrderId: String? = null,
    val errorMessage: String? = null,
)

class GooglePayDemoViewModel(
    private val apiConfig: PaymentApiConfig,
    private val tokenizeGooglePayUseCase: TokenizeGooglePayUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(GooglePayDemoState())
    val state: StateFlow<GooglePayDemoState> = _state.asStateFlow()

    suspend fun submit(
        paymentMethodDataJson: String,
        apiVersion: Int = 2,
        apiVersionMinor: Int = 0,
        payerConsentForToken: Boolean = false,
    ) {
        if (paymentMethodDataJson.isBlank()) {
            val reason = "paymentMethodData JSON is required"
            _state.value = _state.value.copy(errorMessage = reason)
            reportSdkValidationFailure(SCREEN_NAME, reason, apiConfig.orderId)
            return
        }

        _state.value = _state.value.copy(isLoading = true, errorMessage = null)

        when (
            val result = tokenizeGooglePayUseCase(
                apiConfig,
                GooglePayPaymentInput(
                    paymentMethodDataJson = normalizeGooglePayPaymentMethodDataForTransport(paymentMethodDataJson),
                    apiVersion = apiVersion,
                    apiVersionMinor = apiVersionMinor,
                    payerConsentForToken = payerConsentForToken,
                )
            )
        ) {
            is PaymentOperationResult.Success -> {
                sessionStore.saveAddPaymentInfoResult(result.value)
                _state.value = GooglePayDemoState(
                    isLoading = false,
                    resultCode = result.value.resultCode,
                    postUrl = result.value.postUrl,
                    resolvedOrderId = result.value.orderId,
                )
            }

            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                reportSdkValidationFailure(SCREEN_NAME, message, apiConfig.orderId)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    isLoading = false,
                    errorMessage = message,
                )
            }
        }
    }

    private companion object {
        const val SCREEN_NAME = "GooglePayDemoViewModel"
    }
}


