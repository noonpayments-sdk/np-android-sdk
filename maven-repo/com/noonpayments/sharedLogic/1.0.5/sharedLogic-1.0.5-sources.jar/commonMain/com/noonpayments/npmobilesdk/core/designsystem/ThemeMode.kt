package com.noonpayments.npmobilesdk.core.designsystem

/**
 * UI mode selector used by the shared theme resolver.
 */
enum class ThemeMode {
    LIGHT,
    DARK,
}

