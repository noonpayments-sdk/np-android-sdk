package com.noonpayments.npmobilesdk.PaymentMethods.ViewModels

import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.presentation.session.PaymentSheetSessionStore
import com.noonpayments.npmobilesdk.features.common.presentation.toDisplayMessage
import com.noonpayments.npmobilesdk.features.orderconfiguration.domain.usecase.GetOrderConfigurationUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Phase of the initial `PaymentApiConfig` (order configuration) request, exposed to native
 * UI so it can decide whether to render a skeleton, an error card, or the payment methods.
 */
enum class PaymentMethodLoadPhase {
    LOADING,
    SUCCEEDED,
    FAILED,
}

data class PaymentMethodDemoState(
    val phase: PaymentMethodLoadPhase = PaymentMethodLoadPhase.LOADING,
    val resultCode: String? = null,
    val paymentOptionsJson: String? = null,
    val paymentTokensJson: String? = null,
    val errorMessage: String? = null,
)

/**
 * ViewModel backing the PaymentMethod view. Owns the "load order configuration" call so
 * native UI (Compose / SwiftUI) does not have to invoke another ViewModel's `load()` directly.
 *
 * The resulting [OrderConfiguration] is persisted in [PaymentSheetSessionStore] so other
 * screen-scoped ViewModels (ApplePay, CardPayment, ...) can read it via the shared session.
 */
class PaymentMethodDemoViewModel(
    private val apiConfig: PaymentApiConfig,
    private val getOrderConfigurationUseCase: GetOrderConfigurationUseCase,
    private val sessionStore: PaymentSheetSessionStore,
) {
    private val _state = MutableStateFlow(PaymentMethodDemoState())
    val state: StateFlow<PaymentMethodDemoState> = _state.asStateFlow()

    suspend fun load() {
        _state.value = _state.value.copy(
            phase = PaymentMethodLoadPhase.LOADING,
            errorMessage = null,
        )

        when (val result = getOrderConfigurationUseCase(apiConfig)) {
            is PaymentOperationResult.Success -> onSuccess(result.value)
            is PaymentOperationResult.Failure -> {
                val message = result.failure.toDisplayMessage()
                SdkLogger.default().log(LogLevel.ERROR, SCREEN_NAME, message, apiConfig.orderId)
                sessionStore.saveError(message)
                _state.value = _state.value.copy(
                    phase = PaymentMethodLoadPhase.FAILED,
                    errorMessage = message,
                )
            }
        }
    }

    private fun onSuccess(value: OrderConfiguration) {
        sessionStore.saveOrderConfiguration(value)
        _state.value = PaymentMethodDemoState(
            phase = PaymentMethodLoadPhase.SUCCEEDED,
            resultCode = value.resultCode,
            paymentOptionsJson = value.paymentOptions?.toString(),
            paymentTokensJson = value.paymentTokens?.toString(),
        )
    }

    private companion object {
        const val SCREEN_NAME = "PaymentMethodDemoViewModel"
    }
}



