// AUTO-GENERATED FILE. DO NOT EDIT MANUALLY.
// Source: customizable.tokens.json, foundation.tokens.json
// Generator: generateDesignTokens Gradle task

package com.noonpayments.npmobilesdk.core.designsystem

enum class ColorToken(val id: String) {
    BACKGROUND_PRIMARY("BackgroundPrimary"),
    SURFACE_SECONDARY("SurfaceSecondary"),
    BORDER("Border"),
    TEXT_PRIMARY_DISSABLED("TextPrimaryDissabled"),
    LINK_PRIMARY("LinkPrimary"),
    TEXT_PRIMARY("TextPrimary"),
    BACKGROUND_INVERSE("BackgroundInverse"),
    SURFACE_ACCENT_WARM("SurfaceAccentWarm"),
    PRIMARY_ACTION_HOVER("PrimaryActionHover"),
    SURFACE_SECONDARY_DARK("SurfaceSecondaryDark"),
    BACKGROUND_PRIMARY_DARK("BackgroundPrimaryDark"),
    BORDER_SUBTLE_DARK("BorderSubtleDark"),
    BORDER_DARK("BorderDark"),
    SURFACE_TERTIARY("SurfaceTertiary"),
    STATUS_WARNING("StatusWarning"),
    STATUS_ERROR("StatusError"),
    SURFACE_TERTIARY_LIGHT("SurfaceTertiaryLight"),
    SURFACE_SECONDARY_LIGHT("SurfaceSecondaryLight"),
    TEXT_SECONDARY("TextSecondary"),
    PRIMARY_ACTION_DARK("PrimaryActionDark"),
    PRIMARY_ACTION_ACTIVE_DARK("PrimaryActionActiveDark"),
}

enum class FontFamilyToken(val id: String) {
    NAME("name"),
}

enum class FontSizeToken(val id: String) {
    H1("h1"),
    H2("h2"),
    H3("h3"),
    SUBTITLE("subtitle"),
    BODY_LARGE("bodyLarge"),
    BODY_REGULAR("bodyRegular"),
    CAPTION("caption"),
    SMALL_CAPTION("smallCaption"),
    TINY("tiny"),
    NP_SDK_DEFAULT_TITLE_TEXT("npSdkDefaultTitleText"),
}

enum class FontWeightToken(val id: String) {
    REGULAR("regular"),
    MEDIUM("medium"),
    SEMI_BOLD("semiBold"),
    BOLD("bold"),
}

enum class LineHeightToken(val id: String) {
    H1("h1"),
    H2("h2"),
    H3("h3"),
    SUBTITLE("subtitle"),
    BODY_LARGE("bodyLarge"),
    BODY_REGULAR("bodyRegular"),
    CAPTION("caption"),
    SMALL_CAPTION("smallCaption"),
    TINY("tiny"),
}

enum class SpacingToken(val id: String) {
    _0("0"),
    _2_XS("2XS"),
    XS("XS"),
    S("S"),
    M("M"),
    L("L"),
    XL("XL"),
    _2_XL("2XL"),
    _3_XL("3XL"),
    _4_XL("4XL"),
    _5_XL("5XL"),
    _6_XL("6XL"),
    _7_XL("7XL"),
    _8_XL("8XL"),
    _9_XL("9XL"),
    _10_XL("10XL"),
    _11_XL("11XL"),
    _12_XL("12XL"),
}

enum class PaddingToken(val id: String) {
    INPUT_PADDING("inputPadding"),
    CTA_PADDING("CTAPadding"),
    SEPARATOR_PADDING("SeparatorPadding"),
    VERTICAL_PADDING("VerticalPadding"),
    FLOATING_SPACE("FloatingSpace"),
    CARD_PADDING_TOP("CardPaddingTop"),
    CARD_PADDING("CardPadding"),
}

enum class BorderRadiusToken(val id: String) {
    _0("0"),
    XS("XS"),
    S("S"),
    M("M"),
    L("L"),
    CIRCLE("Circle"),
    PILL("Pill"),
}

enum class BorderWidthToken(val id: String) {
    _0("0"),
    XS("XS"),
    S("S"),
    M("M"),
    L("L"),
    XL("XL"),
}

