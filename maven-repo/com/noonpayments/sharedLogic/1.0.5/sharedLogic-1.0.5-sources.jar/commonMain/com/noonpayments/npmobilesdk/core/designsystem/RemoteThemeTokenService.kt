package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Service that provides design tokens from a remote/backend source.
 *
 * The caller supplies raw JSON strings (fetched from the backend).
 * This service parses them through [ThemeTokenParser] — the same parser
 * used for local tokens — which acts as validation. If the JSON structure
 * doesn't match the expected schema, parsing throws and the caller handles fallback.
 */
class RemoteThemeTokenService {

    /**
     * Parses remote JSON into a [ThemeTokenCatalog].
     *
     * @throws Exception if the JSON is malformed, missing required fields,
     *         has schema version mismatch, or light/dark key mismatch.
     *         The caller should catch and fall back to local.
     */
    fun getTokens(
        customizableJson: String,
        foundationJson: String,
    ): ThemeTokenCatalog {
        return ThemeTokenParser.parse(
            customizableJson = customizableJson,
            foundationJson = foundationJson,
            colorOverrides = ThemeTokenRuntimeOverrides.currentColorOverrides(),
        )
    }
}

