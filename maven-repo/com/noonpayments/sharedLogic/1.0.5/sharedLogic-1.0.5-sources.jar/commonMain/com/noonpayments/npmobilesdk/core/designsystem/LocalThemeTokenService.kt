package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Service that reads design tokens from bundled JSON resources.
 * This is the default/fallback data source.
 */
class LocalThemeTokenService {

    /**
     * Reads and parses the bundled JSON files into a [ThemeTokenCatalog].
     * This always succeeds at runtime — the JSON files are embedded in the app bundle.
     */
    fun getTokens(): ThemeTokenCatalog {
        return ThemeTokenParser.parse(
            customizableJson = readResourceText("customizable.tokens.json"),
            foundationJson = readResourceText("foundation.tokens.json"),
            colorOverrides = ThemeTokenRuntimeOverrides.currentColorOverrides(),
        )
    }
}

