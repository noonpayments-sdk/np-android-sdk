package com.noonpayments.npmobilesdk.core.logging

/**
 * Merchant-overridable failure callbacks emitted by the SDK for all known failure scenarios.
 *
 * This protocol is intentionally lightweight so host apps can configure it directly from the
 * sheet entry point without any extra SDK initialization step.
 */
interface SdkFailureDelegate {
    fun onHttpFailure(operation: String, statusCode: Int, orderId: String)

    fun onTransportFailure(operation: String, throwableName: String, message: String?, orderId: String)

    fun onSerializationFailure(operation: String, message: String, orderId: String)

    fun onValidationFailure(screen: String, reason: String, orderId: String)

    companion object {
        fun default(): SdkFailureDelegate = SdkFailureDelegateConfig.activeDelegate
    }
}

object NoOpSdkFailureDelegate : SdkFailureDelegate {
    override fun onHttpFailure(operation: String, statusCode: Int, orderId: String) = Unit

    override fun onTransportFailure(operation: String, throwableName: String, message: String?, orderId: String) = Unit

    override fun onSerializationFailure(operation: String, message: String, orderId: String) = Unit

    override fun onValidationFailure(screen: String, reason: String, orderId: String) = Unit
}

object SdkFailureDelegateConfig {
    internal var activeDelegate: SdkFailureDelegate = NoOpSdkFailureDelegate

    fun configure(delegate: SdkFailureDelegate) {
        activeDelegate = delegate
    }
}

fun reportSdkValidationFailure(screen: String, reason: String, orderId: String? = null) {
    val resolvedOrderId = orderId?.takeIf { it.isNotBlank() } ?: "unknown"
    SdkLogger.default().log(
        level = LogLevel.ERROR,
        tag = screen,
        message = "✗ Validation failure: $reason",
        orderId = resolvedOrderId
    )
    SdkFailureDelegate.default().onValidationFailure(screen, reason, resolvedOrderId)
}
