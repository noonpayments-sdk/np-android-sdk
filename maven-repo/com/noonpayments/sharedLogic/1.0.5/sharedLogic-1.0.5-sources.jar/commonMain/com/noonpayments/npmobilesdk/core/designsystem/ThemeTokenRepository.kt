package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Repository implementation that switches between two data sources:
 *
 * 1. [localService] — reads tokens from bundled JSON (always available)
 * 2. [remoteService] — parses server-provided JSON (validated at runtime)
 *
 * Flow:
 * ```
 * applyRemoteTokens(json, json)
 *   └─► remoteService.getTokens(json, json)
 *       ├─ parsed OK  → activeCatalog = remote, flag = true
 *       └─ threw       → activeCatalog = local,  flag = false  (fallback)
 * ```
 */
class ThemeTokenRepository(
    private val localService: LocalThemeTokenService = LocalThemeTokenService(),
    private val remoteService: RemoteThemeTokenService = RemoteThemeTokenService(),
    localCatalogOverride: ThemeTokenCatalog? = null,
) : IThemeTokenRepository {

    private val localCatalog: ThemeTokenCatalog = localCatalogOverride ?: localService.getTokens()
    private var _activeCatalog: ThemeTokenCatalog = localCatalog
    private var _isRemoteActive: Boolean = false

    override val catalog: ThemeTokenCatalog
        get() = _activeCatalog

    override val isRemoteActive: Boolean
        get() = _isRemoteActive

    override fun applyRemoteTokens(
        customizableJson: String,
        foundationJson: String,
    ): RemoteTokenResult {
        return try {
            val remoteCatalog = remoteService.getTokens(
                customizableJson = customizableJson,
                foundationJson = foundationJson,
            )
            _activeCatalog = remoteCatalog
            _isRemoteActive = true
            RemoteTokenResult.Applied
        } catch (e: Exception) {
            // Remote JSON didn't pass validation — fall back to local.
            _activeCatalog = localCatalog
            _isRemoteActive = false
            RemoteTokenResult.Fallback(
                reason = e.message ?: "Unknown parsing error",
            )
        }
    }

    override fun resetToLocal() {
        _activeCatalog = localCatalog
        _isRemoteActive = false
    }
}

