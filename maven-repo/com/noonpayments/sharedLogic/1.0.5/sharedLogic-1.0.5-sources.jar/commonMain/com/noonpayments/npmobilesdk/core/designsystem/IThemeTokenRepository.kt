package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Repository interface for theme token catalog management.
 *
 * Abstracts the data source switching between local bundled tokens
 * and remote server tokens.
 */
interface IThemeTokenRepository {

    /** The currently active catalog (local or remote). */
    val catalog: ThemeTokenCatalog

    /** Whether the active catalog was loaded from the remote source. */
    val isRemoteActive: Boolean

    /**
     * Attempts to apply remote JSON as the active catalog.
     * If the remote JSON is valid, it becomes the active source.
     * If it fails validation, falls back to local automatically.
     */
    fun applyRemoteTokens(
        customizableJson: String,
        foundationJson: String,
    ): RemoteTokenResult

    /** Resets to the local bundled catalog, discarding any remote override. */
    fun resetToLocal()
}

/** Outcome of attempting to apply remote tokens. */
sealed interface RemoteTokenResult {
    /** Remote JSON parsed successfully and is now the active catalog. */
    data object Applied : RemoteTokenResult

    /** Remote JSON was rejected; local catalog remains active. */
    data class Fallback(val reason: String) : RemoteTokenResult
}

