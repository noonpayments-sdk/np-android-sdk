package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Reads a classpath/bundle resource file as a String.
 * Platform implementations use Java classloader (Android) or NSBundle (iOS).
 */
internal expect fun readResourceText(name: String): String

