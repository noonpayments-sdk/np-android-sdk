package com.noonpayments.npmobilesdk.core.designsystem

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ThemeTokenManager(
    private val repository: IThemeTokenRepository,
    initialMode: ThemeMode = ThemeMode.LIGHT,
) {
    // No-arg constructor: creates default repository (local + remote services).
    constructor(initialMode: ThemeMode = ThemeMode.LIGHT) : this(
        repository = ThemeTokenRepository(),
        initialMode = initialMode,
    )

    // Backward-compatible: accepts a pre-built catalog (used by tests / ThemeTokenBootstrap).
    constructor(
        catalog: ThemeTokenCatalog,
        initialMode: ThemeMode = ThemeMode.LIGHT,
    ) : this(
        repository = ThemeTokenRepository(localCatalogOverride = catalog),
        initialMode = initialMode,
    )

    private val _mode = MutableStateFlow(initialMode)
    val mode: StateFlow<ThemeMode> = _mode.asStateFlow()

    /** Whether a remote token override is currently active. */
    val isRemoteActive: Boolean get() = repository.isRemoteActive

    fun setMode(mode: ThemeMode) {
        _mode.value = mode
    }

    /**
     * Attempts to apply remote JSON tokens via the repository.
     * Remote service validates (parses) the JSON. If valid → switches to remote.
     * If invalid → falls back to local automatically.
     */
    fun applyRemoteTokens(
        customizableJson: String,
        foundationJson: String,
    ): RemoteTokenResult {
        return repository.applyRemoteTokens(customizableJson, foundationJson)
    }

    /** Resets to the local bundled catalog, discarding any remote override. */
    fun resetToLocal() {
        repository.resetToLocal()
    }

    // --- String-based lookups (delegate to repository.catalog) ---

    fun color(tokenId: String): SdkColor {
        val token = repository.catalog.colors[tokenId]
            ?: error("Missing color token '$tokenId'.")
        return when (mode.value) {
            ThemeMode.LIGHT -> token.light
            ThemeMode.DARK -> token.dark
        }
    }
    fun spacing(tokenId: String): Float =
        repository.catalog.spacing[tokenId] ?: error("Missing spacing token '$tokenId'.")
    fun padding(tokenId: String): Float =
        ThemeTokenRuntimeOverrides.currentPaddingOverride(tokenId)
            ?: repository.catalog.padding[tokenId]
            ?: error("Missing padding token '$tokenId'.")
    fun borderRadius(tokenId: String): Float =
        repository.catalog.borderRadius[tokenId] ?: error("Missing borderRadius token '$tokenId'.")
    fun borderWidth(tokenId: String): Float =
        repository.catalog.borderWidth[tokenId] ?: error("Missing borderWidth token '$tokenId'.")
    fun fontFamily(tokenId: String): String =
        repository.catalog.typography.fontFamily[tokenId] ?: error("Missing fontFamily token '$tokenId'.")
    fun fontSize(tokenId: String): Float {
        val baseSize = repository.catalog.typography.fontSize[tokenId]
            ?: error("Missing fontSize token '$tokenId'.")
        return baseSize * ThemeTokenRuntimeOverrides.currentFontScaleFactor()
    }
    fun fontWeight(tokenId: String): Int =
        repository.catalog.typography.fontWeight[tokenId] ?: error("Missing fontWeight token '$tokenId'.")
    fun lineHeight(tokenId: String): Float =
        repository.catalog.typography.lineHeight[tokenId] ?: error("Missing lineHeight token '$tokenId'.")

    fun semanticFontFamily(languageTokenId: String, categoryTokenId: String): String =
        semanticFont(languageTokenId, categoryTokenId).family

    fun semanticFontSize(languageTokenId: String, categoryTokenId: String): Float {
        val baseSize = semanticFont(languageTokenId, categoryTokenId).fontSize
        return baseSize * ThemeTokenRuntimeOverrides.currentFontScaleFactor()
    }

    fun semanticFontWeight(languageTokenId: String, categoryTokenId: String): Int =
        semanticFont(languageTokenId, categoryTokenId).fontWeight

    fun semanticLineHeight(languageTokenId: String, categoryTokenId: String): Float =
        semanticFont(languageTokenId, categoryTokenId).lineHeight

    private fun semanticLocale(languageTokenId: String): SemanticLocaleTypographyTokens {
        return when (languageTokenId.trim().lowercase()) {
            "arabic", "ar" -> repository.catalog.semanticTypography.arabic
            else -> repository.catalog.semanticTypography.english
        }
    }

    private fun semanticFont(languageTokenId: String, categoryTokenId: String): SemanticFontTokens {
        val locale = semanticLocale(languageTokenId)
        return when (categoryTokenId.trim().lowercase()) {
            "title" -> locale.title
            "primary" -> locale.primary
            "secondary" -> locale.secondary
            "tertiary" -> locale.tertiary
            else -> error("Unsupported semantic font category '$categoryTokenId'.")
        }
    }

    // --- Type-safe enum overloads ---

    fun color(token: ColorToken): SdkColor = color(token.id)
    fun spacing(token: SpacingToken): Float = spacing(token.id)
    fun padding(token: PaddingToken): Float = padding(token.id)
    fun borderRadius(token: BorderRadiusToken): Float = borderRadius(token.id)
    fun borderWidth(token: BorderWidthToken): Float = borderWidth(token.id)
    fun fontFamily(token: FontFamilyToken): String = fontFamily(token.id)
    fun fontSize(token: FontSizeToken): Float = fontSize(token.id)
    fun fontWeight(token: FontWeightToken): Int = fontWeight(token.id)
    fun lineHeight(token: LineHeightToken): Float = lineHeight(token.id)
}

object ThemeTokenBootstrap {
    fun fromJson(
        customizableJson: String,
        foundationJson: String,
        initialMode: ThemeMode = ThemeMode.LIGHT,
    ): ThemeTokenManager {
        val catalog = ThemeTokenParser.parse(
            customizableJson = customizableJson,
            foundationJson = foundationJson,
        )
        return ThemeTokenManager(
            catalog = catalog,
            initialMode = initialMode,
        )
    }
}
