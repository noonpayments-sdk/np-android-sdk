package com.noonpayments.npmobilesdk.core.designsystem

import kotlinx.serialization.json.Json

object ThemeTokenParser {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    /**
     * Parses customizable + foundation JSON files into a shared canonical model.
     * Fails fast when required data is missing or malformed.
     */
    fun parse(
        customizableJson: String,
        foundationJson: String,
        colorOverrides: ThemeTokenColorOverrides = ThemeTokenColorOverrides(),
    ): ThemeTokenCatalog {
        val customizable = json.decodeFromString<CustomizableTokensJson>(customizableJson)
        val foundation = json.decodeFromString<FoundationTokensJson>(foundationJson)
        validateSchemaVersions(customizable.schemaVersion, foundation.schemaVersion)

        val mergedColors = ColorModesJson(
            light = customizable.colors.light + colorOverrides.light,
            dark = customizable.colors.dark + colorOverrides.dark,
        )

        val colorTokens = buildColorTokens(mergedColors)
         require(colorTokens.isNotEmpty()) { "No color tokens found in customizable JSON." }

         // Merge typography from both customizable and foundation (customizable takes precedence)
         val custTypo = customizable.typography
         val foundTypo = foundation.typography
         val mergedFontFamily = (foundTypo.fontFamily + custTypo.fontFamily)
         val mergedFontSize = (foundTypo.fontSize + custTypo.fontSize)
         val mergedFontWeight = (foundTypo.fontWeight + custTypo.fontWeight)
         val mergedLineHeight = (foundTypo.lineHeight + custTypo.lineHeight)
         val semanticTypography = buildSemanticTypography(custTypo)

         return ThemeTokenCatalog(
             schemaVersion = customizable.schemaVersion,
             colors = colorTokens,
             typography = TypographyTokens(
                 fontFamily = mergedFontFamily,
                 fontSize = mergedFontSize.mapValues { (_, value) -> value.toFloat() },
                 fontWeight = mergedFontWeight,
                 lineHeight = mergedLineHeight.mapValues { (_, value) -> value.toFloat() },
             ),
             semanticTypography = semanticTypography,
            spacing = foundation.spacing.mapValues { (_, value) -> value.toFloat() },
             padding = customizable.padding.mapValues { (_, value) -> value.toFloat() },
            borderRadius = foundation.borderRadius.mapValues { (_, value) -> value.toFloat() },
            borderWidth = foundation.borderWidth.mapValues { (_, value) -> value.toFloat() },
        )
    }

    private fun validateSchemaVersions(customizableSchemaVersion: String, foundationSchemaVersion: String) {
        require(customizableSchemaVersion.isNotBlank()) { "customizable.schemaVersion is required." }
        require(foundationSchemaVersion.isNotBlank()) { "foundation.schemaVersion is required." }
        require(customizableSchemaVersion == foundationSchemaVersion) {
            "Schema version mismatch. customizable=$customizableSchemaVersion foundation=$foundationSchemaVersion"
        }
    }

    private fun buildColorTokens(colors: ColorModesJson): Map<String, ModeAwareColorToken> {
        val keys = colors.light.keys + colors.dark.keys
        require(keys.isNotEmpty()) { "No color keys found in light/dark mode maps." }

        return keys.associateWith { tokenId ->
            val light = colors.light[tokenId]
                ?: error("Missing light color token '$tokenId'.")
            val dark = colors.dark[tokenId]
                ?: error("Missing dark color token '$tokenId'.")
            ModeAwareColorToken(
                light = SdkColor.fromHex(light),
                dark = SdkColor.fromHex(dark),
            )
        }
    }

    private fun buildSemanticTypography(typography: TypographyJson): SemanticTypographyTokens {
        val englishJson = typography.english ?: typography.latin
            ?: error("Missing typography.english (or typography.latin) in customizable tokens JSON.")
        val arabicJson = typography.arabic
            ?: error("Missing typography.arabic in customizable tokens JSON.")

        return SemanticTypographyTokens(
            english = englishJson.toSemanticLocaleTokens("english"),
            arabic = arabicJson.toSemanticLocaleTokens("arabic"),
        )
    }

    private fun LocaleTypographyJson.toSemanticLocaleTokens(localeName: String): SemanticLocaleTypographyTokens {
        return SemanticLocaleTypographyTokens(
            title = title.toSemanticFontTokens(localeName, "title"),
            primary = primary.toSemanticFontTokens(localeName, "primary"),
            secondary = secondary.toSemanticFontTokens(localeName, "secondary"),
            tertiary = tertiary.toSemanticFontTokens(localeName, "tertiary"),
        )
    }

    private fun SemanticFontJson.toSemanticFontTokens(localeName: String, categoryName: String): SemanticFontTokens {
        val resolvedFamily = family?.trim().orEmpty()
        require(resolvedFamily.isNotBlank()) {
            "Missing typography.$localeName.$categoryName.family in customizable tokens JSON."
        }
        val resolvedSize = (fontSize ?: error("Missing typography.$localeName.$categoryName.fontSize in customizable tokens JSON.")).toFloat()
        val resolvedWeight = fontWeight ?: error("Missing typography.$localeName.$categoryName.fontWeight in customizable tokens JSON.")
        val resolvedLineHeight = (lineHeight ?: error("Missing typography.$localeName.$categoryName.lineHeight in customizable tokens JSON.")).toFloat()
        return SemanticFontTokens(
            family = resolvedFamily,
            fontSize = resolvedSize,
            fontWeight = resolvedWeight,
            lineHeight = resolvedLineHeight,
        )
    }
}
