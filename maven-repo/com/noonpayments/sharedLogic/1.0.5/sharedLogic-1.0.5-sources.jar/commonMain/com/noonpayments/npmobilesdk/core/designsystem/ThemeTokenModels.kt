package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Canonical in-memory token catalog used by shared logic and native UI adapters.
 *
 * Token ids are intentionally kept as-is from Figma export so naming stays 1:1.
 */
data class ThemeTokenCatalog(
    val schemaVersion: String,
    val colors: Map<String, ModeAwareColorToken>,
    val typography: TypographyTokens,
    val semanticTypography: SemanticTypographyTokens = SemanticTypographyTokens(),
    val spacing: Map<String, Float>,
    val padding: Map<String, Float>,
    val borderRadius: Map<String, Float>,
    val borderWidth: Map<String, Float>,
)

data class ModeAwareColorToken(
    val light: SdkColor,
    val dark: SdkColor,
)

data class TypographyTokens(
    val fontFamily: Map<String, String>,
    val fontSize: Map<String, Float>,
    val fontWeight: Map<String, Int>,
    val lineHeight: Map<String, Float>,
)

data class SemanticTypographyTokens(
    val english: SemanticLocaleTypographyTokens = SemanticLocaleTypographyTokens(),
    val arabic: SemanticLocaleTypographyTokens = SemanticLocaleTypographyTokens(),
)

data class SemanticLocaleTypographyTokens(
    val title: SemanticFontTokens = SemanticFontTokens(),
    val primary: SemanticFontTokens = SemanticFontTokens(),
    val secondary: SemanticFontTokens = SemanticFontTokens(),
    val tertiary: SemanticFontTokens = SemanticFontTokens(),
)

data class SemanticFontTokens(
    val family: String = "",
    val fontSize: Float = 0f,
    val fontWeight: Int = 400,
    val lineHeight: Float = 0f,
)

/**
 * Optional merchant-provided color overrides keyed by token id.
 *
 * Example key: "BackgroundPrimary".
 * Any missing key falls back to bundled JSON values.
 */
data class ThemeTokenColorOverrides(
    val light: Map<String, String> = emptyMap(),
    val dark: Map<String, String> = emptyMap(),
)

/**
 * Platform-neutral color primitive.
 */
data class SdkColor(
    val red: Int,
    val green: Int,
    val blue: Int,
    val alpha: Int = 255,
) {
    init {
        require(red in 0..255) { "Invalid red channel: $red" }
        require(green in 0..255) { "Invalid green channel: $green" }
        require(blue in 0..255) { "Invalid blue channel: $blue" }
        require(alpha in 0..255) { "Invalid alpha channel: $alpha" }
    }

    fun toArgbInt(): Int = (alpha shl 24) or (red shl 16) or (green shl 8) or blue

    companion object {
        fun fromHex(rawHex: String): SdkColor {
            val normalized = rawHex.trim().removePrefix("#")
            return when (normalized.length) {
                6 -> {
                    val red = normalized.substring(0, 2).toInt(16)
                    val green = normalized.substring(2, 4).toInt(16)
                    val blue = normalized.substring(4, 6).toInt(16)
                    SdkColor(red = red, green = green, blue = blue, alpha = 255)
                }

                8 -> {
                    val alpha = normalized.substring(0, 2).toInt(16)
                    val red = normalized.substring(2, 4).toInt(16)
                    val green = normalized.substring(4, 6).toInt(16)
                    val blue = normalized.substring(6, 8).toInt(16)
                    SdkColor(red = red, green = green, blue = blue, alpha = alpha)
                }

                else -> error("Unsupported hex color: '$rawHex'. Expected #RRGGBB or #AARRGGBB")
            }
        }
    }
}
