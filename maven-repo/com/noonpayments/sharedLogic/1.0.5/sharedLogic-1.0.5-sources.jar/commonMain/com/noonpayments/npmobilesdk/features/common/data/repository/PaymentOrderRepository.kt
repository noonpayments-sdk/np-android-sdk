package com.noonpayments.npmobilesdk.features.common.data.repository

import com.noonpayments.npmobilesdk.core.network.NetworkError
import com.noonpayments.npmobilesdk.core.network.NetworkResult
import com.noonpayments.npmobilesdk.core.logging.LogLevel
import com.noonpayments.npmobilesdk.core.logging.SdkLogger
import com.noonpayments.npmobilesdk.features.common.data.service.NoonPaymentService
import com.noonpayments.npmobilesdk.features.common.domain.AddPaymentInfoResult
import com.noonpayments.npmobilesdk.features.common.domain.ApplePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CancelPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.CardPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.GooglePayPaymentInput
import com.noonpayments.npmobilesdk.features.common.domain.OrderConfiguration
import com.noonpayments.npmobilesdk.features.common.domain.OrderStatusResult
import com.noonpayments.npmobilesdk.features.common.domain.PaymentApiConfig
import com.noonpayments.npmobilesdk.features.common.domain.PaymentFailure
import com.noonpayments.npmobilesdk.features.common.domain.PaymentOperationResult
import com.noonpayments.npmobilesdk.features.common.domain.repository.IPaymentOrderRepository
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

class PaymentOrderRepository(
    private val service: NoonPaymentService
) : IPaymentOrderRepository {

    private val logger: SdkLogger = SdkLogger.default()

    override suspend fun getOrderConfiguration(config: PaymentApiConfig): PaymentOperationResult<OrderConfiguration> {
        return when (val result = service.getOrderConfiguration(config)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "getOrderConfiguration success: ${result.data}", config.orderId)

                val payload = result.data
                val resultObject = payload["result"].asObjectOrNull()
                val orderObject = resultObject?.get("order").asObjectOrNull()

                // Extract order metadata - try multiple possible field names
                val orderCategory = orderObject?.get("category").asStringOrNull()
                    ?: orderObject?.get("orderCategory").asStringOrNull()
                    ?: orderObject?.get("type").asStringOrNull()

                val currency = orderObject?.get("currency").asStringOrNull()
                    ?: orderObject?.get("amount").asObjectOrNull()?.get("currency").asStringOrNull()

                val orderChannel = orderObject?.get("channel").asStringOrNull()
                    ?: orderObject?.get("orderChannel").asStringOrNull()

                // Extract encryption key from known payload path.
                val encryptionKey = extractEncryptionKeyFromPaymentOptions(resultObject)

                PaymentOperationResult.Success(
                    OrderConfiguration(
                        resultCode = payload["resultCode"].asStringOrNull(),
                        order = orderObject,
                        paymentOptions = resultObject?.get("paymentOptions"),
                        paymentTokens = resultObject?.get("paymentTokens"),
                        orderCategory = orderCategory,
                        currency = currency,
                        orderChannel = orderChannel,
                        encryptionKey = encryptionKey
                    )
                )
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "getOrderConfiguration failure: ${result.error}", config.orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun addCardPaymentInfo(
        config: PaymentApiConfig,
        input: CardPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        return when (val result = service.addCardPaymentInfo(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "addCardPaymentInfo success: ${result.data}", config.orderId)
                PaymentOperationResult.Success(result.data.toAddPaymentInfoResult())
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "addCardPaymentInfo failure: ${result.error}", config.orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun tokenizeApplePay(
        config: PaymentApiConfig,
        input: ApplePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        return when (val result = service.tokenizeApplePay(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "tokenizeApplePay success: ${result.data}", config.orderId)
                PaymentOperationResult.Success(result.data.toAddPaymentInfoResult())
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "tokenizeApplePay failure: ${result.error}", config.orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun tokenizeGooglePay(
        config: PaymentApiConfig,
        input: GooglePayPaymentInput
    ): PaymentOperationResult<AddPaymentInfoResult> {
        return when (val result = service.tokenizeGooglePay(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "tokenizeGooglePay success: ${result.data}", config.orderId)
                PaymentOperationResult.Success(result.data.toAddPaymentInfoResult())
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "tokenizeGooglePay failure: ${result.error}", config.orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun cancelPayment(
        config: PaymentApiConfig,
        input: CancelPaymentInput
    ): PaymentOperationResult<Unit> {
        return when (val result = service.cancelPayment(config, input)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "cancelPayment success: ${result.data}", config.orderId)
                PaymentOperationResult.Success(Unit)
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "cancelPayment failure: ${result.error}", config.orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    override suspend fun fetchOrderStatus(
        config: PaymentApiConfig,
        orderId: String
    ): PaymentOperationResult<OrderStatusResult> {
        return when (val result = service.fetchOrderStatus(config, orderId)) {
            is NetworkResult.Success -> {
                logger.log(LogLevel.DEBUG, TAG, "fetchOrderStatus success: ${result.data}", orderId)

                val payload = result.data
                val resultObject = payload["result"].asObjectOrNull()
                val firstTransaction = resultObject
                    ?.get("transactions")
                    .asArrayOrNull()
                    ?.firstOrNull()
                    .asObjectOrNull()

                PaymentOperationResult.Success(
                    OrderStatusResult(
                        resultCode = payload["resultCode"].asStringOrNull(),
                        orderStatus = resultObject
                            ?.get("order")
                            .asObjectOrNull()
                            ?.get("status")
                            .asStringOrNull(),
                        transactionStatus = firstTransaction
                            ?.get("status")
                            .asStringOrNull(),
                        paymentDetails = resultObject?.get("paymentDetails")
                    )
                )
            }

            is NetworkResult.Failure -> {
                logger.log(LogLevel.ERROR, TAG, "fetchOrderStatus failure: ${result.error}", orderId)
                PaymentOperationResult.Failure(result.error.toPaymentFailure())
            }
        }
    }

    private companion object {
        const val TAG = "PaymentOrderRepository"
    }
}

private fun JsonObject.toAddPaymentInfoResult(): AddPaymentInfoResult {
    val resultObject = this["result"].asObjectOrNull()
    return AddPaymentInfoResult(
        resultCode = this["resultCode"].asStringOrNull(),
        postUrl = resultObject
            ?.get("checkoutData")
            .asObjectOrNull()
            ?.get("postUrl")
            .asStringOrNull(),
        orderId = resultObject
            ?.get("order")
            .asObjectOrNull()
            ?.get("id")
            .asStringOrNull()
    )
}

private fun NetworkError.toPaymentFailure(): PaymentFailure = when (this) {
    is NetworkError.Http -> PaymentFailure.Http(statusCode, body)
    is NetworkError.Serialization -> PaymentFailure.Serialization(message)
    is NetworkError.Transport -> PaymentFailure.Transport(throwable.message ?: "Transport error")
}

private fun JsonElement?.asObjectOrNull(): JsonObject? = this as? JsonObject

private fun JsonElement?.asArrayOrNull(): JsonArray? = this as? JsonArray

private fun JsonElement?.asStringOrNull(): String? = (this as? JsonPrimitive)?.contentOrNull

private fun extractEncryptionKeyFromPaymentOptions(resultObject: JsonObject?): String? {
    val cardPaymentOption = resultObject
        ?.get("paymentOptions")
        .asArrayOrNull()
        ?.mapNotNull { it.asObjectOrNull() }
        ?.firstOrNull { paymentOption -> paymentOption.isCardPaymentOption() }

    val keyObject = cardPaymentOption
        ?.get("data")
        .asObjectOrNull()
        ?.get("encryptionSettings")
        .asObjectOrNull()
        ?.get("key")
        .asObjectOrNull()

    return keyObject?.get("pemFormatedKey").asStringOrNull()
}

private fun JsonObject.isCardPaymentOption(): Boolean {
    return this["type"].asStringOrNull() == "Card"
}
