package com.noonpayments.npmobilesdk.core.designsystem

/**
 * Runtime holder for merchant-provided color overrides passed at SDK initialization.
 *
 * This lets all ThemeTokenManager instances use the same override source while still
 * falling back to bundled token JSON for any missing key.
 */
object ThemeTokenRuntimeOverrides {
    private var colorOverrides: ThemeTokenColorOverrides = ThemeTokenColorOverrides()
    private var fontScaleFactor: Float = 1f
    private var paddingOverrides: Map<String, Float> = emptyMap()

    fun setColorOverrides(
        light: Map<String, String> = emptyMap(),
        dark: Map<String, String> = emptyMap(),
    ) {
        colorOverrides = ThemeTokenColorOverrides(
            light = light.filterValues { it.isNotBlank() },
            dark = dark.filterValues { it.isNotBlank() },
        )
    }

    fun clearColorOverrides() {
        colorOverrides = ThemeTokenColorOverrides()
    }

    fun currentColorOverrides(): ThemeTokenColorOverrides = colorOverrides

    fun setPaddingOverrides(overrides: Map<String, Float> = emptyMap()) {
        paddingOverrides = overrides
            .filterKeys { it.isNotBlank() }
            .filterValues { it.isFinite() }
    }

    fun clearPaddingOverrides() {
        paddingOverrides = emptyMap()
    }

    fun currentPaddingOverride(tokenId: String): Float? = paddingOverrides[tokenId]

    fun setFontScaleFactor(value: Float) {
        fontScaleFactor = if (value > 0f) value else 1f
    }

    fun currentFontScaleFactor(): Float = fontScaleFactor
}

