package com.noonpayments.npmobilesdk.core.network

import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.engine.darwin.Darwin

internal actual fun platformEngineFactory(): HttpClientEngineFactory<*> = Darwin

