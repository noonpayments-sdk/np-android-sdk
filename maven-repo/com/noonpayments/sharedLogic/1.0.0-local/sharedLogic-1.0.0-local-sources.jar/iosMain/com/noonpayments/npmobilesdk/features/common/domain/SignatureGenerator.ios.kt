package com.noonpayments.npmobilesdk.features.common.domain

import kotlinx.cinterop.*
import platform.CoreCrypto.CC_SHA512
import platform.CoreCrypto.CC_SHA512_DIGEST_LENGTH
import platform.CoreFoundation.*
import platform.Foundation.*
import platform.Security.*
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

private val HEX_CHARS = "0123456789abcdef".toCharArray()

private fun ByteArray.toHexString(): String {
    val result = CharArray(size * 2)
    for (i in indices) {
        val v = this[i].toInt() and 0xFF
        result[i * 2] = HEX_CHARS[v ushr 4]
        result[i * 2 + 1] = HEX_CHARS[v and 0x0F]
    }
    return result.concatToString()
}

/**
 * iOS actual: SHA-512 via Apple's CommonCrypto CC_SHA512.
 * Hardware-accelerated, zero dependencies.
 */
@OptIn(ExperimentalForeignApi::class)
internal actual fun platformComputeSha512(input: String): String {
    val bytes = input.encodeToByteArray()
    val digest = ByteArray(CC_SHA512_DIGEST_LENGTH)

    bytes.usePinned { pinnedInput ->
        digest.usePinned { pinnedDigest ->
            CC_SHA512(
                pinnedInput.addressOf(0),
                bytes.size.toUInt(),
                pinnedDigest.addressOf(0).reinterpret()
            )
        }
    }

    return digest.toHexString()
}

/**
 * iOS actual: RSA/PKCS1 v1.5 encryption via Apple's Security.framework.
 * Uses SecKeyCreateWithData + SecKeyCreateEncryptedData.
 */
@OptIn(ExperimentalForeignApi::class, ExperimentalEncodingApi::class)
internal actual fun platformEncryptRsaPkcs1(data: String, pemKey: String): String {
    // Normalize PEM: replace escaped newlines with actual newlines
    val normalizedPem = pemKey.replace("\\n", "\n")

    // Extract DER from PEM (shared utility from commonMain)
    val derBytes = extractDerFromPem(normalizedPem)

    // Create SecKey from DER data
    val secKey = createSecKeyFromDer(derBytes)
        ?: throw IllegalStateException("Failed to create SecKey from PEM key")

    // Encrypt data with RSA PKCS1
    val dataBytes = data.encodeToByteArray()
    val encryptedBytes = encryptWithSecKey(secKey, dataBytes)
        ?: throw IllegalStateException("RSA encryption failed")

    // Base64 encode for backend transmission
    return Base64.encode(encryptedBytes)
}

/**
 * Creates a SecKey (RSA public key) from DER-encoded bytes.
 */
@OptIn(ExperimentalForeignApi::class)
private fun createSecKeyFromDer(derBytes: ByteArray): SecKeyRef? {
    // Create CFData from raw bytes directly (avoids NSData → CFDataRef cast issue)
    val cfData = derBytes.usePinned { pinned ->
        CFDataCreate(
            kCFAllocatorDefault,
            pinned.addressOf(0).reinterpret(),
            derBytes.size.toLong()
        )
    } ?: return null

    // Build attributes dictionary using CoreFoundation APIs
    val keys = arrayOf(kSecAttrKeyType, kSecAttrKeyClass, kSecAttrKeySizeInBits)
    val keySizeNumber = CFNumberCreate(kCFAllocatorDefault, kCFNumberIntType, cValuesOf(2048))
    val values = arrayOf(kSecAttrKeyTypeRSA, kSecAttrKeyClassPublic, keySizeNumber)

    memScoped {
        val cfKeys = allocArrayOf(*keys)
        val cfValues = allocArrayOf(*values)

        val attributes = CFDictionaryCreate(
            kCFAllocatorDefault,
            cfKeys.reinterpret(),
            cfValues.reinterpret(),
            keys.size.toLong(),
            null,
            null
        )

        val secKey = SecKeyCreateWithData(cfData, attributes, null)

        // Release CF objects
        CFRelease(cfData)
        CFRelease(attributes)
        CFRelease(keySizeNumber)

        return secKey
    }
}

/**
 * Encrypts data using RSA/PKCS1 v1.5 with a SecKey.
 */
@OptIn(ExperimentalForeignApi::class)
private fun encryptWithSecKey(publicKey: SecKeyRef, data: ByteArray): ByteArray? {
    // Create CFData from raw bytes directly
    val plainCfData = data.usePinned { pinned ->
        CFDataCreate(
            kCFAllocatorDefault,
            pinned.addressOf(0).reinterpret(),
            data.size.toLong()
        )
    } ?: return null

    val encryptedCfData = SecKeyCreateEncryptedData(
        publicKey,
        kSecKeyAlgorithmRSAEncryptionPKCS1,
        plainCfData,
        null
    )

    // Release input CFData
    CFRelease(plainCfData)

    if (encryptedCfData == null) return null

    // Extract bytes from encrypted CFData
    val length = CFDataGetLength(encryptedCfData).toInt()
    if (length == 0) {
        CFRelease(encryptedCfData)
        return null
    }

    val bytePtr = CFDataGetBytePtr(encryptedCfData)
    if (bytePtr == null) {
        CFRelease(encryptedCfData)
        return null
    }

    val result = ByteArray(length)
    result.usePinned { pinned ->
        platform.posix.memcpy(pinned.addressOf(0), bytePtr, length.toULong())
    }

    CFRelease(encryptedCfData)
    return result
}
